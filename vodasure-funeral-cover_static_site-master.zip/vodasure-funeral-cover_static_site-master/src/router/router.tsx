import React, { useMemo, useState } from 'react';
import {
  Route,
  Navigate,
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
} from 'react-router-dom';
import { AppContextProvider } from '@/context';
import { routes } from '@/router';
import { Environment } from '@/utils';
import { Cache } from '@/services';
import { CoverOutlet, RootOutlet } from '@/outlets';
import {
  CoverDetails,
  Quote,
  PersonalDetails,
  Beneficiary,
  PaymentDetails,
  DebitOrder,
  ErrorScreen,
  Confirmation,
  PaymentSummary,
  ErrorBoundary,
  FuneralAssistance,
  MedicalAssistance,
  FamilyDetails,
  QuoteCancelled,
  RetailPartners,
  ErrorElement,
} from '@/pages';
import { DevTools } from '@/components';
import { DataRewardBenefit } from '@/pages/static-pages/data-reward-benefit/data-reward-benefit';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<RootOutlet />} errorElement={<ErrorElement />}>
      <Route path='' element={<CoverOutlet />}>
        <Route path='' element={<Navigate to={routes.coverDetails} />} />
        <Route path={routes.coverDetails} element={<CoverDetails />} />
      </Route>

      <Route path={routes.quote} element={<Quote />} />
      <Route path={routes.personalDetails} element={<PersonalDetails />} />
      <Route path={routes.beneficiary} element={<Beneficiary />} />
      <Route path={routes.paymentDetails} element={<PaymentDetails />} />
      <Route path={routes.debitOrderDetails} element={<DebitOrder />} />
      <Route path={routes.error} element={<ErrorScreen />} />
      <Route path={routes.confirmation} element={<Confirmation />} />
      <Route path={routes.paymentSummary} element={<PaymentSummary />} />
      <Route path={routes.funeral} element={<FuneralAssistance />} />
      <Route path={routes.medical} element={<MedicalAssistance />} />
      <Route path={routes.dataReward} element={<DataRewardBenefit />} />
      <Route path={routes.familyDetails} element={<FamilyDetails />} />
      <Route path={routes.quoteCancelled} element={<QuoteCancelled />} />
      <Route path={routes.retailPartners} element={<RetailPartners />} />
      <Route path='*' element={<CoverDetails />} />
    </Route>
  ),
  { basename: '/funeral-cover' }
);

export const Router = () => {
  const [showDebug, setShowDebug] = useState(false);

  useMemo(() => {
    const debugKey = Cache.fetch('debugKey');
    if (debugKey) {
      setShowDebug(
        (Environment.current.allowDebug &&
          Environment.current?.debugKey &&
          Environment.current.debugKey === debugKey) ||
          false
      );
    }
  }, []);

  return (
    <ErrorBoundary>
      <AppContextProvider>
        <RouterProvider router={router} />
        {showDebug && <DevTools />}
      </AppContextProvider>
    </ErrorBoundary>
  );
};

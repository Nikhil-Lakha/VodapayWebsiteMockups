export const routes = {
  coverDetails: '/cover-details',
  quote: '/quote',
  quoteCancelled: '/quote/cancelled',
  personalDetails: '/personal-details',
  familyDetails: '/family-details',
  beneficiary: '/beneficiary',
  paymentDetails: '/payment/details',
  debitOrderDetails: '/payment/debit-order',
  paymentSummary: '/payment/summary',
  confirmation: '/confirmation',
  error: '/error',
  funeral: '/funeral-assistance',
  medical: '/medical-assistance',
  dataReward: '/data-reward-benefit',
  retailPartners: '/retailpartners'
};

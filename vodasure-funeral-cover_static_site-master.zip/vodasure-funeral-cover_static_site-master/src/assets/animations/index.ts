export { default as RedLoader } from './red-loader.json';

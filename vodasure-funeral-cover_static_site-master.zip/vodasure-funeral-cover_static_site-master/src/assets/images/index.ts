export { default as RedBackground } from './red-background.svg';
export { default as QRCode } from './qr-code.svg';

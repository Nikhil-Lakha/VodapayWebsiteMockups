import { BeneficiaryRelationships } from '@/types';
import { isExtendedFamily } from '@/utils/helpers';

interface IExtendedFamilyCases {
  input: BeneficiaryRelationships | undefined;
  output: boolean;
}

const extendedFamilyCases: IExtendedFamilyCases[] = [
  {
    input: BeneficiaryRelationships.wife,
    output: false,
  },
  {
    input: BeneficiaryRelationships.son,
    output: false,
  },
  {
    input: BeneficiaryRelationships.mother,
    output: false,
  },
  {
    input: BeneficiaryRelationships.femaleCousin,
    output: true,
  },
  {
    input: BeneficiaryRelationships.uncle,
    output: true,
  },
  {
    input: BeneficiaryRelationships.other,
    output: true,
  },
  {
    input: undefined,
    output: false,
  },
];

describe('isExtendedFamily', () => {
  it('it should return $expectedOutput when input is $input', () => {
    extendedFamilyCases.forEach(({ input, output }) => {
      expect(isExtendedFamily(input)).toBe(output);
    });
  });
});

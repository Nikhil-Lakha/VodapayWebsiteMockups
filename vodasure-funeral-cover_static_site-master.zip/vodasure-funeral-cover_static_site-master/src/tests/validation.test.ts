import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../utils/constants', () => ({
    validAge: {
      adult: { type: 'adult', max: 74, min: 18 },
      child: { type: 'child', max: 17, min: 0 },
    },
    applicationDefaults: {
      benefitRequirements: {
        dataReward: {
          minCoverAmount: 20000
        }
      },
    }
  }));

import {
  isValidMobileNumber,
  idCheckSum,
  isValidAlphabetical,
  isValidAge,
  isValidAlphaCharacters,
} from '@/utils/validation';

describe('isValidMobileNumber', () => {
  const testCases = it.each`
    input                 | expectedOutput
    ${'+2711994330'}      | ${false}
    ${'+27822321456'}     | ${true}
    ${'+271234567'}       | ${false}
    ${'+27123456789012'}  | ${false}
    ${'+27123456'}        | ${false}
    ${'+271234567890123'} | ${false}
    ${'27213562345'}      | ${false}
    ${'+91213562345'}     | ${false}
    ${'+27 119 943 30'}   | ${false}
    ${'+2711$94&3@'}      | ${false}
    ${''}                 | ${false}
  `;

  testCases(
    'it returns $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(isValidMobileNumber(input)).toBe(expectedOutput);
    }
  );
});

describe('isValidAlphaCharacters', () => {
  const testCases = it.each`
    input                | expectedOutput
    ${'ABC1'}            | ${true}
    ${' '}               | ${false}
    ${'ABC123456789123'} | ${true}
    ${'ABC1b 3456d89a2'} | ${false}
    ${'ABC1B3456D89A23'} | ${true}
    ${'ABC1B34@6D89A23'} | ${true}
    ${'abc1#$34@6D89a2'} | ${false}
    ${'ABC1#$34@6D89a2'} | ${true}
    ${'1231B34@6D89A23'} | ${false}
  `;

  testCases(
    'it returns $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(isValidAlphaCharacters(input)).toBe(expectedOutput);
    }
  );
});

describe('isValidID', () => {
  const testCases = it.each`
    input               | expectedOutput
    ${'4907073226187'}  | ${true}
    ${'9504125015083'}  | ${true}
    ${'8805025125083'}  | ${true}
    ${'8611105046086'}  | ${true}
    ${'8001015009087'}  | ${true}
    ${'8332120551081'}  | ${false}
    ${'7304400555072'}  | ${false}
    ${'92110943040857'} | ${false}
    ${'850322501a082'}  | ${false}
    ${'@503225015082'}  | ${false}
    ${'850322501508'}   | ${false}
    ${'6012120212181'}  | ${false}
    ${'8805025125082'}  | ${false}
    ${''}               | ${false}
  `;

  testCases(
    'it returns $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(idCheckSum(input)).toBe(expectedOutput);
    }
  );
});

describe('isValidAlphabetical', () => {
  const testCases = it.each`
    input          | expectedOutput
    ${'Bob'}       | ${true}
    ${'bob'}       | ${true}
    ${'Bob Dylan'} | ${true}
    ${'J@kob'}     | ${false}
    ${''}          | ${false}
  `;

  testCases(
    'it returns $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(isValidAlphabetical(input)).toBe(expectedOutput);
    }
  );
});

interface isValidAgeCases {
  input: [date: Date, coverStart: string];
  output: boolean;
}

const isValidAgeCases: isValidAgeCases[] = [
  {
    input: [new Date(1995, 11, 17), 'adult'],
    output: true,
  },
  {
    input: [new Date(2020, 11, 17), 'adult'],
    output: false,
  },
  {
    input: [new Date(2026, 11, 17), 'adult'],
    output: false,
  },
  {
    input: [new Date(1900, 11, 17), 'adult'],
    output: false,
  },
  {
    input: [new Date(1995, 11, 17), 'child'],
    output: false,
  },
  {
    input: [new Date(2020, 11, 17), 'child'],
    output: true,
  },
  {
    input: [new Date(2026, 11, 17), 'child'],
    output: false,
  },
  {
    input: [new Date(1900, 11, 17), 'child'],
    output: false,
  },
];

describe('isValidAge', () => {
  beforeEach(() => {
    // tell vitest we use mocked time
    vi.useFakeTimers();
  });

  afterEach(() => {
    // restoring date after each test run
    vi.useRealTimers();
  });

  it('it should validate dob depending on type(child|adult)', () => {
    isValidAgeCases.forEach(({ input, output }) => {
      const date = new Date(2023, 1, 1);
      vi.setSystemTime(date);
      expect(isValidAge(input[0], input[1])).toBe(output);
    });
  });
});

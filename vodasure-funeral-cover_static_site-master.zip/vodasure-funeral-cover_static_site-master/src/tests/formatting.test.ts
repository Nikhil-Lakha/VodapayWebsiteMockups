import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  stringFormat,
  removeNonNumericCharacters,
  formatCurrency,
  determineCoverStartOption,
  calcAge,
  determineCoverStartDate,
  filterObject,
} from '@/utils/formatting';
import { CoverStartOption } from '@/types';

describe('stripWhiteSpace', () => {
  const testCases = test.each`
    input                   | expectedOutput
    ${'string '}            | ${'string'}
    ${' string'}            | ${'string'}
    ${'string with spaces'} | ${'stringwithspaces'}
    ${' more spaces '}      | ${'morespaces'}
    ${'s p a c e s'}        | ${'spaces'}
    ${'string'}             | ${'string'}
    ${'str! ng '}           | ${'str!ng'}
    ${'sp@ c3s'}            | ${'sp@c3s'}
    ${'+27 119 943 30'}     | ${'+2711994330'}
    ${' +27119 94340 '}     | ${'+2711994340'}
  `;

  testCases(
    'it should return $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(stringFormat.stripWhitespace(input)).toBe(expectedOutput);
    }
  );
});

describe('removeNonNumericCharacters', () => {
  const testCases = test.each`
    input            | expectedOutput
    ${'t3xt'}        | ${'3'}
    ${'t3xt!'}       | ${'3'}
    ${'+2711994330'} | ${'2711994330'}
    ${'+27ii994330'} | ${'27994330'}
  `;

  testCases(
    'it should return $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(removeNonNumericCharacters(input)).toBe(expectedOutput);
    }
  );
});

describe('calculateAge', () => {
  beforeEach(() => {
    // tell vitest we use mocked time
    vi.useFakeTimers();
  });

  afterEach(() => {
    // restoring date after each test run
    vi.useRealTimers();
  });

  const validDates = test.each`
    input           | expectedOutput
    ${'2020-01-01'} | ${3}
    ${'20200101'}   | ${3}
    ${'2022-01-01'} | ${1}
    ${'2023-01-01'} | ${0}
    ${'2023-02-01'} | ${0}
    ${'2023-03-01'} | ${-1}
    ${'2026-03-01'} | ${-1}
  `;

  validDates(
    'it should return $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 1);
      vi.setSystemTime(date);
      expect(calcAge(input)).toBe(expectedOutput);
    }
  );

  const invalidDates = test.each`
    input           | expectedOutput
    ${'2020/01/01'} | ${'Date not valid ISO string'}
    ${'not-a-date'} | ${'Date not valid ISO string'}
  `;

  invalidDates(
    'it should throw $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 1);
      vi.setSystemTime(date);
      expect(() => calcAge(input)).toThrow(expectedOutput);
    }
  );
});

describe('formatCurrency', () => {
  const testCases = test.each`
    input                    | expectedOutput
    ${1023213123123.3423}    | ${'R\xa01\xa0023\xa0213\xa0123\xa0123.34'}
    ${'1023213123123.34234'} | ${'R\xa01\xa0023\xa0213\xa0123\xa0123.34'}
    ${50.5}                  | ${'R\xa050.50'}
    ${'50.5'}                | ${'R\xa050.50'}
    ${50.0}                  | ${'R\xa050.00'}
    ${'50.0'}                | ${'R\xa050.00'}
    ${50.01}                 | ${'R\xa050.01'}
    ${'50.00'}               | ${'R\xa050.00'}
    ${50}                    | ${'R\xa050.00'}
    ${'50'}                  | ${'R\xa050.00'}
    ${0}                     | ${'R\xa00.00'}
    ${'0'}                   | ${'R\xa00.00'}
    ${''}                    | ${'R 0.00'}
    ${' '}                   | ${'R 0.00'}
    ${null}                  | ${'R\xa00.00'}
    ${undefined}             | ${'R 0.00'}
    ${'-'}                   | ${'R 0.00'}
    ${'text'}                | ${'R 0.00'}
  `;

  testCases(
    'it should return $expectedOutput when input is $input',
    ({ input, expectedOutput }) => {
      expect(formatCurrency(input)).toBe(expectedOutput);
    }
  );
});

describe('determineCoverStartOption', () => {
  beforeEach(() => {
    // tell vitest we use mocked time
    vi.useFakeTimers();
  });

  afterEach(() => {
    // restoring date after each test run
    vi.useRealTimers();
  });

  const testCasesOne = test.each`
    input   | expectedOutput
    ${'1'}  | ${'nextMonth'}
    ${'5'}  | ${'nextMonth'}
    ${'6'}  | ${'nextMonth'}
    ${'7'}  | ${'proceed'}
    ${'15'} | ${'proceed'}
    ${'20'} | ${'proceed'}
    ${'30'} | ${'proceed'}
  `;

  testCasesOne(
    'it should return $expectedOutput when input is $input (beginningOfMonth)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 1);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );

  const testCasesTwo = test.each`
    input   | expectedOutput
    ${'1'}  | ${'nextMonth'}
    ${'5'}  | ${'nextMonth'}
    ${'15'} | ${'nextMonth'}
    ${'13'} | ${'nextMonth'}
    ${'20'} | ${'nextMonth'}
    ${'21'} | ${'proceed'}
    ${'30'} | ${'proceed'}
  `;

  testCasesTwo(
    'it should return $expectedOutput when debit order day is $input (middleOfMonth)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 15);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );

  const testCasesThree = test.each`
    input   | expectedOutput
    ${'1'}  | ${'nextMonth'}
    ${'5'}  | ${'nextMonth'}
    ${'15'} | ${'nextMonth'}
    ${'13'} | ${'nextMonth'}
    ${'20'} | ${'nextMonth'}
    ${'21'} | ${'nextMonth'}
    ${'27'} | ${'proceed'}
    ${'30'} | ${'proceed'}
  `;

  testCasesThree(
    'it should return $expectedOutput when debit order day is $input (Close to end of month)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 21);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );

  const testCasesFour = test.each`
    input   | expectedOutput
    ${'1'}  | ${'twoMonths'}
    ${'5'}  | ${'twoMonths'}
    ${'6'}  | ${'nextMonth'}
    ${'15'} | ${'nextMonth'}
    ${'20'} | ${'nextMonth'}
    ${'30'} | ${'proceed'}
  `;

  testCasesFour(
    'it should return $expectedOutput when debit order day is $input (endOfMonth - 28 days)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 1, 28);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );

  const testCasesFive = test.each`
    input   | expectedOutput
    ${'1'}  | ${'twoMonths'}
    ${'3'}  | ${'twoMonths'}
    ${'4'}  | ${'nextMonth'}
    ${'5'}  | ${'nextMonth'}
    ${'6'}  | ${'nextMonth'}
    ${'15'} | ${'nextMonth'}
    ${'20'} | ${'nextMonth'}
    ${'30'} | ${'nextMonth'}
  `;

  testCasesFive(
    'it should return $expectedOutput when debit order day is $input (endOfMonth - 30 days)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 3, 28);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );

  const testCasesSix = test.each`
    input   | expectedOutput
    ${'1'}  | ${'twoMonths'}
    ${'5'}  | ${'nextMonth'}
    ${'6'}  | ${'nextMonth'}
    ${'15'} | ${'nextMonth'}
    ${'20'} | ${'nextMonth'}
    ${'30'} | ${'nextMonth'}
  `;

  testCasesSix(
    'it should return $expectedOutput when debit order day is $input (endOfMonth - 31 days)',
    ({ input, expectedOutput }) => {
      const date = new Date(2023, 2, 28);
      vi.setSystemTime(date);
      expect(determineCoverStartOption(input)).toBe(expectedOutput);
    }
  );
});

interface ICoverStartDateCases {
  input: [date: string, coverStart: CoverStartOption];
  output: string;
}

const determineCoverStartDateCases: ICoverStartDateCases[] = [
  {
    input: ['1', CoverStartOption.proceed],
    output: '01 February 2023',
  },
  {
    input: ['15', CoverStartOption.proceed],
    output: '15 February 2023',
  },
  {
    input: ['31', CoverStartOption.proceed],
    output: '28 February 2023',
  },
  {
    input: ['1', CoverStartOption.nextMonth],
    output: '01 March 2023',
  },
  {
    input: ['15', CoverStartOption.nextMonth],
    output: '15 March 2023',
  },
  {
    input: ['31', CoverStartOption.nextMonth],
    output: '31 March 2023',
  },
  {
    input: ['1', CoverStartOption.twoMonths],
    output: '01 April 2023',
  },
  {
    input: ['15', CoverStartOption.twoMonths],
    output: '15 April 2023',
  },
];

const invalidDetermineCoverStartDateCases: ICoverStartDateCases[] = [
  {
    input: ['31', CoverStartOption.twoMonths],
    output: 'Invalid DateTime',
  },
];
describe('determineCoverStartDate', () => {
  beforeEach(() => {
    // tell vitest we use mocked time
    vi.useFakeTimers();
  });

  afterEach(() => {
    // restoring date after each test run
    vi.useRealTimers();
  });

  it('it should return $expectedOutput when input is $input', () => {
    determineCoverStartDateCases.forEach(({ input, output }) => {
      const date = new Date(2023, 1, 21);
      vi.setSystemTime(date);
      expect(determineCoverStartDate(input[0], input[1])).toBe(output);
    });
  });

  it('it should return $expectedOutput when input is $input', () => {
    invalidDetermineCoverStartDateCases.forEach(({ input, output }) => {
      const date = new Date(2023, 1, 21);
      vi.setSystemTime(date);
      expect(() => determineCoverStartDate(input[0], input[1])).toThrow(output);
    });
  });
});

type IObjectCaseInput = [key: string, value: string];

const objectsCases: {
  input: [object, ([key, value]: IObjectCaseInput) => boolean];
  output: object;
}[] = [
  {
    input: [
      { name: 'name', surname: 'surname' },
      ([key, value]: IObjectCaseInput) => key !== 'surname',
    ],
    output: { name: 'name' },
  },
  {
    input: [
      { name: 'name', surname: 'surname', gender: 'gender' },
      ([key, value]: IObjectCaseInput) => key !== 'surname' && key !== 'gender',
    ],
    output: { name: 'name' },
  },
  {
    input: [{}, ([key, value]: IObjectCaseInput) => key !== 'surname'],
    output: {},
  },
  {
    input: [
      { name: 'name', surname: 'surname', gender: 'gender' },
      ([key, value]: [key: string, value: string]) => key !== 'dateOfBirth',
    ],
    output: { name: 'name', surname: 'surname', gender: 'gender' },
  },
];

describe('filterObject', () => {
  it('it should return $output when input is $input', () => {
    objectsCases.forEach(({ input, output }) =>
      expect(filterObject(input[0], input[1])).toMatchObject(output)
    );
  });
});

/* eslint-disable @typescript-eslint/no-non-null-assertion */
import React from 'react';
import { act, renderHook } from '@testing-library/react';
import { describe, beforeEach, it, expect, vi, afterAll } from 'vitest';
import { rules } from '../../hooks/use-benefit-qualification/rules';
import { useBenefitQualification } from '../../hooks/use-benefit-qualification/use-benefit-qualification';
import { AppContextProvider } from '@/context';

vi.mock('../../hooks/use-benefit-qualification/rules', () => ({
  rules: {
    dataReward: [vi.fn().mockReturnValue(true), vi.fn().mockReturnValue(true)]
  }
}));

const useContextSpy = vi.spyOn(React, 'useContext');
useContextSpy.mockImplementation(() => ({}));

// import { AppContextProvider } from '../../context/app-context';

describe('Use Benefit Qualification', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterAll(() => {
    vi.restoreAllMocks();
  });

  it('should return true for dataReward if has min cover amount and is a vodacom customer', () => {
    const {
      result: {
        current: { qualifies },
      },
    } = renderHook(() => useBenefitQualification('dataReward'));
    expect(qualifies).toEqual(true);
  });

  it.each([rules.dataReward!])(
    'should return false for dataReward if any of the checks return false',
    check => {
      vi.mocked(check).mockReturnValueOnce(false);
      const {
        result: {
          current: { qualifies },
        },
      } = renderHook(() => useBenefitQualification('dataReward'));
      expect(qualifies).toEqual(false);
    }
  );

  it('should return true if there are no checks', () => {
    const {
      result: {
        current: { qualifies },
      },
    } = renderHook(() => useBenefitQualification('funeral'));
    expect(vi.mocked(rules.dataReward![0])).not.toHaveBeenCalled();
    expect(vi.mocked(rules.dataReward![1])).not.toHaveBeenCalled();
    expect(qualifies).toEqual(true);
  });

  it('should return a different result if the qualification fails after a change in the app context', () => {
    const {
      result: {
        current: { qualifies },
      },
      rerender,
    } = renderHook(() => useBenefitQualification('funeral'), {
      wrapper: AppContextProvider,
    });
    expect(qualifies).toEqual(true);
    vi.mocked(rules.dataReward![0]).mockReturnValueOnce(false);
    act(() => {
      rerender();
    });
    expect(qualifies).toEqual(true);
  });
});

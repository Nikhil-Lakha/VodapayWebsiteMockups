import React, { Dispatch, SetStateAction, useEffect, useMemo } from 'react';
import { useFormik, FormikProps } from 'formik';
import { DevToolSettings } from '@/types';
import { Environments, devToolsFormSchema } from '@/utils';
import { CustomSelect, RadioButtonGroup } from '@/components';
import './dev-tools-form.scss';

interface Props {
  initialValues: DevToolSettings;
  formValid: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<DevToolSettings>>;
  radioOptions: { label: string; value: string }[];
}

export const DevToolsForm = ({
  initialValues,
  formValid,
  formValues,
  radioOptions,
}: Props) => {
  const formik: FormikProps<DevToolSettings> = useFormik<DevToolSettings>({
    initialValues,
    validationSchema: devToolsFormSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    formValues(formik.values);
  }, [formik.values]);

  useEffect(() => {
    formValid(Object.entries(formik.errors).length === 0);
  }, [formik.errors]);

  const apiHostOptions = useMemo(
    () =>
      Object.values(Environments).reduce(
        (acc: { label: string; value: string }[], value) => {
          if (value.name === 'Local') {
            return [...acc, { label: 'local', value: 'http://localhost:80' }];
          }
          return [...acc, { label: value.env, value: value.apiHost }];
        },
        []
      ),
    []
  );

  return (
    <form className='dev-tools-form'>
      <div className='form-section'>
        <p>API host:</p>
        <CustomSelect
          name='apiHost'
          label=''
          placeholder='API host'
          formik={formik}
          options={apiHostOptions}
        />
      </div>
      <section className='radio-section'>
        <label className='radio-label'>Make API requests?</label>
        <RadioButtonGroup
          buttonArray={radioOptions}
          name='apiRequests'
          formik={formik}
        />
      </section>
      <section className='radio-section'>
        <label className='radio-label'>Disable analytics?</label>
        <RadioButtonGroup
          buttonArray={radioOptions}
          name='disableAnalytics'
          formik={formik}
        />
      </section>
      <section className='radio-section'>
        <label className='radio-label'>Debug analytics?</label>
        <RadioButtonGroup
          buttonArray={radioOptions}
          name='debugAnalytics'
          formik={formik}
        />
      </section>
    </form>
  );
};

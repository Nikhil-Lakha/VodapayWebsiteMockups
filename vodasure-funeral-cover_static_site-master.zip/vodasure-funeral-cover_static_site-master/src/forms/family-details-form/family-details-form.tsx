import React, { useEffect, useContext, Dispatch, SetStateAction } from 'react';
import { useFormik, FieldArray, FormikProvider, FormikProps } from 'formik';
import {
  applicationDefaults,
  familyDetailsFormSchema,
  isMobile,
} from '@/utils';
import { FamilyDetails } from '@/types';
import { AppContext } from '@/context';
import {
  InputField,
  RadioButtonGroup,
  FamilyMemberAccordion,
} from '@/components';
import './family-details-form.scss';

interface Props {
  validForm: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<FamilyDetails>>;
  initialValues: FamilyDetails;
  addedValues: Dispatch<SetStateAction<boolean>>;
}

export const FamilyDetailsForm = ({
  validForm,
  formValues,
  initialValues,
  addedValues,
}: Props) => {
  const { familyDetails } = useContext(AppContext);
  const validationSchema = familyDetailsFormSchema;
  const { gender } = applicationDefaults;

  const formik: FormikProps<FamilyDetails> = useFormik<FamilyDetails>({
    initialValues,
    validationSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    formValues(formik.values);
    addedValues(Object.values(formik.values).some(elem => elem.length > 0));
  }, [addedValues, formValues, formik.values]);

  useEffect(() => {
    validForm(Object.entries(formik.errors).length === 0);
  }, [formik.errors, validForm]);

  return (
    <form className='custom-form'>
      {Object.keys(familyDetails).map((memberType, memberTypeIndex) => (
        <section
          className='family-details-accordion-wrapper'
          key={memberTypeIndex}
        >
          {familyDetails[memberType as keyof FamilyDetails].map(
            (member, memberIndex) => (
              <FamilyMemberAccordion
                key={memberIndex}
                index={memberIndex}
                coverType={memberType}
              >
                <FormikProvider value={formik}>
                  <FieldArray
                    name={memberType}
                    render={arrayHelpers => (
                      <>
                        <InputField
                          name={`${memberType}.${memberIndex}.firstName`}
                          label='First name'
                          placeholder='First name'
                          type='text'
                          inputmode='text'
                          formik={formik}
                          minLength='2'
                          maxLength='50'
                          autoFocus
                          required
                        />
                        <InputField
                          name={`${memberType}.${memberIndex}.surname`}
                          label='Surname'
                          placeholder='Surname'
                          type='text'
                          inputmode='text'
                          formik={formik}
                          minLength='2'
                          maxLength='50'
                          required
                        />
                        {isMobile() ? (
                          <InputField
                            name={`${memberType}.${memberIndex}.dateOfBirth`}
                            label='Date of birth'
                            type='date'
                            inputmode='text'
                            autocomplete='bday'
                            formik={formik}
                            required
                          />
                        ) : (
                          <InputField
                            name={`${memberType}.${memberIndex}.dateOfBirth`}
                            label='Date of birth'
                            type='text'
                            inputmode='numeric'
                            fieldType='date'
                            formik={formik}
                            required
                          />
                        )}

                        <section className='section-radio'>
                          <section>
                            <p className='radio-label'>Gender</p>
                          </section>
                          <RadioButtonGroup
                            buttonArray={gender}
                            name={`${memberType}.${memberIndex}.gender`}
                            formik={formik}
                          />
                        </section>
                      </>
                    )}
                  />
                </FormikProvider>
              </FamilyMemberAccordion>
            )
          )}
        </section>
      ))}
    </form>
  );
};

import React, { useEffect, useContext } from 'react';
import { useFormik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { CheckBox } from '@/components';
import { AppContext } from '@/context';

const validationSchema = Yup.object().shape({
  agreeToTerms: Yup.string().required('Required'),
});

interface Props {
  id: string;
  name: string;
  initialValues: { agreeToTerms: boolean };
}

export const PaymentSummaryForm = ({ id, name, initialValues }: Props) => {
  const { setPaymentDetails } = useContext(AppContext);

  const formik: FormikProps<{ agreeToTerms: boolean }> = useFormik<{
    agreeToTerms: boolean;
  }>({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    setPaymentDetails(prev => ({
      ...prev,
      agreeToTerms: formik.values?.agreeToTerms,
    }));
  }, [formik.values, setPaymentDetails]);

  return (
    <form>
      <CheckBox
        id={id}
        name={name}
        label='I agree to the VodaSure | Funeral Cover '
        handleChange={formik.handleChange}
        formik={formik}
      />
    </form>
  );
};

import React, { useEffect, Dispatch, SetStateAction } from 'react';
import { useFormik, FormikProps } from 'formik';
import { cancellationFormSchema } from '@/utils';
import { RadioButtonGroup } from '@/components';

interface Props {
  initialValues: { reason: string };
  reasons: { label: string; value: string }[];
  formValid: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<{ reason: string }>>;
}

export const CancellationForm = ({
  initialValues,
  reasons,
  formValid,
  formValues,
}: Props) => {
  const formik: FormikProps<any> = useFormik<any>({
    initialValues,
    validationSchema: cancellationFormSchema,
    validateOnMount: true,
    enableReinitialize: true,
    onSubmit: () => {},
  });

  useEffect(() => {
    formValues(formik.values);
  }, [formik.values]);

  useEffect(() => {
    formValid(Object.entries(formik.errors).length === 0);
  }, [formik.errors]);

  return (
    <form className='cancellation-form'>
      <RadioButtonGroup
        buttonArray={reasons}
        name='reason'
        formik={formik}
        type='column'
      />
    </form>
  );
};

import React, { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { useFormik, FormikProps } from 'formik';
import { CoverStartOption, PaymentDetails } from '@/types';
import {
  applicationDefaults,
  determineCoverStartOption,
  debitOrderFormSchema,
} from '@/utils';
import { CustomSelect, InputField, RadioButtonGroup } from '@/components';
import './debit-order-form.scss';

interface Props {
  validForm: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<PaymentDetails>>;
  initialValues: PaymentDetails;
  setCoverStartOption: Dispatch<SetStateAction<CoverStartOption>>;
}

export const DebitOrderForm = ({
  validForm,
  formValues,
  initialValues,
  setCoverStartOption,
}: Props) => {
  const { banks, accountType, debitOrderDates, coverStart } =
    applicationDefaults;
  const [showBranchCode, setShowBranchCode] = useState(false);
  const [validationSchema, setValidationSchema] = useState(
    debitOrderFormSchema(false)
  );
  const [coverStartOptions, setCoverStartOptions] = useState<
    {
      label: string;
      value: string;
      disabled?: boolean;
    }[]
  >(coverStart);

  const formik: FormikProps<PaymentDetails> = useFormik<PaymentDetails>({
    initialValues,
    validationSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    validForm(Object.values(formik.errors).length === 0);
  }, [formik.errors, validForm]);

  useEffect(() => {
    formik.validateForm();
  }, [validationSchema]);

  useEffect(() => {
    const values: PaymentDetails = {
      ...formik.values,
      branchCode: banks.find(bank => bank.value === formik.values.bankName)
        ?.universalBranchCode,
      coverStartOption: determineCoverStartOption(
        formik.values.debitOrderDate || '1'
      ),
    };
    formValues(values);
  }, [formValues, formik.values]);

  useEffect(() => {
    if (formik?.values?.bankName) {
      setShowBranchCode(
        !banks.find(bank => bank.value === formik.values.bankName)
          ?.universalBranchCode
      );
      setValidationSchema(debitOrderFormSchema(false));
    }
  }, [banks, formik.values.bankName]);

  useEffect(() => {
    if (!formik.values.debitOrderDate) {
      return;
    }
    const coverStartOption = determineCoverStartOption(
      formik.values.debitOrderDate
    );
    setCoverStartOption(coverStartOption || CoverStartOption.proceed);
    formik.setFieldValue('coverStart', null);

    const newCoverStartOptions = coverStartOptions.slice();
    newCoverStartOptions[0].disabled =
      coverStartOption === CoverStartOption.nextMonth ||
      coverStartOption === CoverStartOption.twoMonths;
    setCoverStartOptions(newCoverStartOptions);
  }, [formik.values.debitOrderDate]);

  useEffect(() => {
    if (showBranchCode) {
      setValidationSchema(debitOrderFormSchema(true));
    }
  }, [showBranchCode]);

  return (
    <form className='debit-order-form'>
      <InputField
        name='accountHolderName'
        label='Account holder name'
        placeholder='Account holder name'
        type='text'
        inputmode='text'
        formik={formik}
        minLength='2'
        maxLength='50'
        autoFocus
        required
      />
      <CustomSelect
        name='bankName'
        label='Select Bank'
        placeholder='Select Bank'
        formik={formik}
        options={banks}
      />
      <InputField
        name='accountNumber'
        label='Account number'
        placeholder='Account number'
        type='text'
        inputmode='numeric'
        formik={formik}
        minLength='6'
        maxLength='15'
        required
      />
      <CustomSelect
        name='accountType'
        label='Account type'
        placeholder='Account type'
        formik={formik}
        options={accountType}
        required
      />
      {showBranchCode && (
        <InputField
          name='branchCode'
          label='Branch code'
          placeholder='Branch code'
          type='text'
          inputmode='numeric'
          formik={formik}
          minLength='2'
          maxLength='6'
        />
      )}
      <CustomSelect
        name='debitOrderDate'
        label='Preferred debit order date'
        placeholder='Preferred debit order date'
        formik={formik}
        options={debitOrderDates}
        required
      />
      <section className='radio-section'>
        <label className='radio-label'>
          When would you like your cover to start?
        </label>
        <RadioButtonGroup
          buttonArray={coverStartOptions}
          name='coverStart'
          formik={formik}
        />
      </section>
    </form>
  );
};

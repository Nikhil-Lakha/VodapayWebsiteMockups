import React, { useEffect, Dispatch, SetStateAction } from 'react';
import { useFormik, FormikProps } from 'formik';
import { referralCodeFormSchema } from '@/utils';
import { ReferralCode } from '@/types';
import { InputField } from '@/components';
import { TealiumService } from '@/services';
import './referral-code-form.scss';
import get from 'lodash.get';

interface Props {
  validForm: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<ReferralCode>>;
  initialValues: ReferralCode;
}

export const ReferralCodeForm = ({
  validForm,
  formValues,
  initialValues,
}: Props) => {
  const validationSchema = referralCodeFormSchema();

  const formik: FormikProps<ReferralCode> = useFormik<ReferralCode>({
    initialValues,
    validationSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    validForm(Object.entries(formik.errors).length === 0);
  }, [formik.errors, validForm]);

  useEffect(() => {
    Object.entries(formik.errors).forEach(([field, error]) => {
      if (get(formik, `touched.[${field}]`, false)) {
      TealiumService.onErrorOnReferralPage(error);
      }
    });
  }, [formik.touched, formik.errors]);

  useEffect(() => {
    formValues(formik.values);
  }, [formValues, formik.values]);

  return (
    <form className='custom-form-referral-code'>
      <InputField
        name='referralCode'
        label='Enter referral code'
        placeholder='eg: SMO073134634687'
        type='text'
        inputmode='text'
        tip='Referral code field must not be empty'
        formik={formik}
        minLength='4'
        maxLength='15'
        required
        showCharacterLimit
        onFocus={() => formik.setFieldTouched('referralCode')}
      />
    </form>
  );
};

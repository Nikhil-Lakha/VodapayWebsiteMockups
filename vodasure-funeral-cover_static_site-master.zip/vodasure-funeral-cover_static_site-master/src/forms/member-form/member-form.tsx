import React, {
  useEffect,
  useContext,
  useState,
  Dispatch,
  SetStateAction,
} from 'react';
import {
  useFormik,
  FieldArray,
  FormikProvider,
  FormikProps,
  FieldArrayRenderProps,
} from 'formik';
import { AppContext, CoverContext } from '@/context';
import { FamilyDetails, ProductDetails } from '@/types';
import {
  applicationDefaults,
  formatCurrency,
  familyMembersFormSchema,
  isMobile,
} from '@/utils';
import { TealiumService } from '@/services';
import { InputField, FamilyCard, Button, CustomSelect } from '@/components';
import { ButtonAdd, DeleteIcon } from '@/assets';
import './member-form.scss';

interface IRenderInput<T> {
  name: string;
  index: number;
  coverAmounts: { label: string; value: string }[];
  formik: FormikProps<T>;
  productDetails: ProductDetails;
  showCoverAmountModal: Dispatch<SetStateAction<boolean>>;
}

const RenderInput = <T extends object>({
  name,
  index,
  coverAmounts,
  formik,
  productDetails,
  showCoverAmountModal,
}: IRenderInput<T>) => {
  switch (name) {
    case 'child':
      return (
        <Button
          onClick={() => {
            showCoverAmountModal(true);
          }}
          quaternary
          matchInput
        >
          Click for more
        </Button>
      );
    case 'extended':
      return (
        <CustomSelect
          label=''
          name={`${name}.${index}.coverAmount`}
          formik={formik}
          options={coverAmounts}
          placeholder='R10 000'
          required
        />
      );
    default:
      return (
        <InputField
          name={`${name}.${index}.coverAmount`}
          type='text'
          inputmode='numeric'
          formik={formik}
          value={formatCurrency(productDetails?.coverAmount)}
          required
          disabled
        />
      );
  }
};

interface IMemberForm {
  validForm: Dispatch<SetStateAction<boolean>>;
  initialValues: FamilyDetails;
  showCoverAmountModal: Dispatch<SetStateAction<boolean>>;
}

export const MemberForm = ({
  validForm,
  initialValues,
  showCoverAmountModal,
}: IMemberForm) => {
  const { productDetails, setFamilyDetails } = useContext(AppContext);
  const { setNoFamilyMembers, setSomeFamilyMembers, setAddedOneFamilyMember } =
    useContext(CoverContext);
  const [removeMember, setRemoveMember] = useState(false);
  const { familyCover, coverAmounts } = applicationDefaults;

  const formik: FormikProps<FamilyDetails> = useFormik<FamilyDetails>({
    initialValues,
    validationSchema: familyMembersFormSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    validForm(Object.entries(formik.errors).length === 0);
  }, [formik.errors, validForm]);

  useEffect(() => {
    setFamilyDetails(formik.values);
    setAddedOneFamilyMember(
      Object.values(formik.values).some(elem => elem.length > 0)
    );
    if (
      removeMember &&
      Object.values(formik.values).some(elem => elem.length > 0)
    ) {
      setSomeFamilyMembers(true);
    }

    if (
      removeMember &&
      Object.values(formik.values).every(elem => elem.length === 0)
    ) {
      setNoFamilyMembers(true);
    }

    return () => setRemoveMember(false);
  }, [
    formik.values,
    removeMember,
    setNoFamilyMembers,
    setSomeFamilyMembers,
    setRemoveMember,
    setAddedOneFamilyMember,
    setFamilyDetails,
  ]);

  function handleRemoveMember(
    name: string,
    arrayHelpers: FieldArrayRenderProps,
    index: number
  ) {
    TealiumService.onFamilyCoverRemoveMember(name);
    setRemoveMember(true);
    arrayHelpers.remove(index);
  }

  function handleAddMember(
    memberInfo: { name: string; index: number; maxMembers: number },
    arrayHelpers: FieldArrayRenderProps
  ) {
    TealiumService.onFamilyCoverAddMember(memberInfo.name);
    if (
      Object.values(formik.values)[memberInfo.index].length <
      memberInfo.maxMembers
    ) {
      arrayHelpers.push(
        memberInfo.name === 'spouse'
          ? { coverAmount: productDetails?.coverAmount }
          : {}
      );
    }
  }

  return (
    <form className='add-member-form'>
      {familyCover.map(({ name, cover, label, maxMembers }, familyIndex) => (
        <FamilyCard key={familyIndex} memberType={name} label={label}>
          <FormikProvider value={formik}>
            <FieldArray
              name={name}
              render={arrayHelpers => (
                <>
                  {Object.values(formik.values)[familyIndex].map(
                    (_: unknown, index: number) => (
                      <section
                        className={`member-section ${
                          Object.values(formik.values)[familyIndex].length ===
                            index + 1 && 'last-child'
                        }`}
                        key={index}
                      >
                        {isMobile() ? (
                          <InputField
                            name={`${name}.${index}.dateOfBirth`}
                            label={`${cover} ${
                              cover === 'Spouse' ? '' : index + 1
                            }`}
                            type='date'
                            inputmode='numeric'
                            autocomplete='bday'
                            formik={formik}
                            autoFocus
                            required
                          />
                        ) : (
                          <InputField
                            name={`${name}.${index}.dateOfBirth`}
                            label={`${cover} ${
                              cover === 'Spouse' ? '' : index + 1
                            }`}
                            type='text'
                            inputmode='numeric'
                            fieldType='date'
                            formik={formik}
                            autoFocus
                            required
                          />
                        )}
                        <RenderInput
                          name={name}
                          index={index}
                          coverAmounts={coverAmounts}
                          formik={formik}
                          productDetails={productDetails}
                          showCoverAmountModal={showCoverAmountModal}
                        />
                        <p className='remove-member-btn'>
                          <img
                            src={DeleteIcon}
                            alt='remove'
                            onClick={() =>
                              handleRemoveMember(name, arrayHelpers, index)
                            }
                          />
                          <span>Remove</span>
                        </p>
                      </section>
                    )
                  )}
                  <img
                    className={`add-member-btn ${
                      Object.values(formik.values)[familyIndex].length ===
                        maxMembers && 'hidden'
                    }`}
                    src={ButtonAdd}
                    alt='add icon'
                    onClick={() =>
                      handleAddMember(
                        { name, index: familyIndex, maxMembers },
                        arrayHelpers
                      )
                    }
                  />
                </>
              )}
            />
          </FormikProvider>
        </FamilyCard>
      ))}
    </form>
  );
};

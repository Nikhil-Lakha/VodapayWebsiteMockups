import React, {
  useState,
  useEffect,
  useContext,
  Dispatch,
  SetStateAction,
  useMemo,
} from 'react';
import { useFormik, FormikProps } from 'formik';
import get from 'lodash.get';
import {
  applicationDefaults,
  masks,
  beneficiaryFormSchema,
  isMobile,
  spouseMap,
  ChildMap,
} from '@/utils';
import {
  BeneficiaryDetails,
  BeneficiaryRelationships,
  FamilyMember,
} from '@/types';
import { AppContext } from '@/context';
import { CustomSelect, InputField, RadioButtonGroup, Tip } from '@/components';
import './beneficiary-details-form.scss';

interface Props {
  formValid: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<BeneficiaryDetails>>;
  formTouched?: Dispatch<SetStateAction<boolean>>;
  initialValues: BeneficiaryDetails;
  isFamilyCover: boolean;
}

export const BeneficiaryDetailsForm = ({
  formValid,
  formValues,
  formTouched,
  initialValues,
  isFamilyCover,
}: Props) => {
  const { familyDetails } = useContext(AppContext);
  const validationSchema = beneficiaryFormSchema(isFamilyCover);

  const { gender, relationships } = applicationDefaults;

  const [beneficiaryList, setBeneficiaryList] = useState<
    { label: string; value: string }[]
  >([]);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [isFamilyMemberBeneficiary, setIsFamilyMemberBeneficiary] =
    useState<boolean>(false);
  const [isExtended, setIsExtended] = useState<boolean>(false);
  const [genderOptions, setGenderOptions] = useState<
    {
      label: string;
      value: string;
      disabled?: boolean;
    }[]
  >(gender);

  const formik: FormikProps<BeneficiaryDetails> = useFormik<BeneficiaryDetails>(
    {
      initialValues,
      validationSchema,
      validateOnMount: true,
      enableReinitialize: true,
      // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
      onSubmit: () => {},
    }
  );

  function getRelationship(
    selectBeneficiary: string,
    beneficiaryGender: string | undefined
  ) {
    if (selectBeneficiary.startsWith('spouse') && beneficiaryGender) {
      setIsExtended(false);
      return spouseMap[beneficiaryGender];
    }
    if (selectBeneficiary.startsWith('child') && beneficiaryGender) {
      setIsExtended(false);
      return ChildMap[beneficiaryGender];
    }
    setIsExtended(true);
    return BeneficiaryRelationships.other;
  }

  useMemo(() => {
    const list: { label: string; value: string }[] = Object.entries(
      familyDetails
    ).reduce(
      (acc: { label: string; value: string }[], [memberType, members]) => {
        if (members.length > 0) {
          acc.push(
            ...members.map(
              (
                value: { firstName: string; surname: string },
                index: number
              ) => ({
                label: `${value.firstName} ${value.surname} (${memberType})`,
                value: `${memberType}.${index}`,
              })
            )
          );
          return acc;
        }
        return acc;
      },
      []
    );
    list.push({ label: 'Other', value: 'Other' });
    setBeneficiaryList(list);
  }, [familyDetails]);

  useEffect(() => {
    formValid(Object.entries(formik.errors).length === 0);
  }, [formik.errors, formValid]);

  useEffect(() => {
    formValues(formik.values);
  }, [formValues, formik.values]);

  useEffect(() => {
    if (formTouched) {
      formTouched(Object.values(formik.touched).length > 0);
    }
  }, [formTouched, formik.touched]);

  useEffect(() => {
    if (formik.values.selectBeneficiary) {
      setShowForm(true);
    }
  }, [formik.values.selectBeneficiary]);

  useEffect(() => {
    if (
      formik.values.selectBeneficiary &&
      formik.values.selectBeneficiary !== 'Other'
    ) {
      setIsFamilyMemberBeneficiary(true);
      const familyData: FamilyMember = get(
        familyDetails,
        formik.values.selectBeneficiary
      );
      formik.setValues({
        selectBeneficiary: formik.values.selectBeneficiary,
        firstName: familyData.firstName || '',
        surname: familyData.surname || '',
        dateOfBirth: familyData.dateOfBirth || '',
        cellphoneNumber: formik.values?.cellphoneNumber || '',
        relationship:
          getRelationship(formik.values.selectBeneficiary, familyData.gender) ||
          formik.values.relationship,
        gender: familyData.gender || undefined,
      });
      const newGenderOptions = Array.from(genderOptions);
      setGenderOptions(
        newGenderOptions.map(item => ({ ...item, disabled: true }))
      );
    }

    if (
      formik.values.selectBeneficiary &&
      formik.values.selectBeneficiary === 'Other'
    ) {
      setIsFamilyMemberBeneficiary(false);
      formik.setValues({ ...initialValues, selectBeneficiary: 'Other' });
      setGenderOptions(gender);
      setIsExtended(true);
    }
  }, [formik.values.selectBeneficiary]);

  return (
    <form className='custom-form'>
      {isFamilyCover && (
        <CustomSelect
          name='selectBeneficiary'
          label=''
          placeholder='Select a beneficiary'
          formik={formik}
          options={beneficiaryList}
          required
        />
      )}
      {(!isFamilyCover || showForm) && (
        <>
          <InputField
            name='firstName'
            label='First name'
            placeholder='First name'
            type='text'
            inputmode='text'
            formik={formik}
            minLength='2'
            maxLength='50'
            autoFocus={!isFamilyCover}
            required
            disabled={isFamilyMemberBeneficiary}
          />
          <InputField
            name='surname'
            label='Surname'
            placeholder='Surname'
            type='text'
            inputmode='text'
            formik={formik}
            minLength='2'
            maxLength='50'
            required
            disabled={isFamilyMemberBeneficiary}
          />
          {isMobile() ? (
            <InputField
              name='dateOfBirth'
              label='Date of birth'
              type='date'
              inputmode='text'
              autocomplete='bday'
              formik={formik}
              required
              disabled={isFamilyMemberBeneficiary}
            />
          ) : (
            <InputField
              name='dateOfBirth'
              label='Date of birth'
              fieldType='date'
              type='text'
              inputmode='text'
              formik={formik}
              required
              disabled={isFamilyMemberBeneficiary}
            />
          )}

          <InputField
            name='cellphoneNumber'
            label='Cellphone number'
            placeholder='Cellphone number'
            type='tel'
            inputmode='tel'
            fieldType='masked'
            mask={masks.phoneNumberSpaced}
            formik={formik}
            required
          />
          <CustomSelect
            name='relationship'
            label='Relationship'
            placeholder='Relationship'
            formik={formik}
            options={relationships}
            disabled={!isExtended && isFamilyCover}
            required
          />
          <section className='section-radio'>
            <section>
              <p className='radio-label'>Gender</p>
            </section>
            <RadioButtonGroup
              buttonArray={genderOptions}
              name='gender'
              formik={formik}
            />
          </section>
        </>
      )}
      <Tip
        text='You are required to choose a beneficiary so they can receive your funds in the event of your passing.'
        type='custom'
      />
    </form>
  );
};

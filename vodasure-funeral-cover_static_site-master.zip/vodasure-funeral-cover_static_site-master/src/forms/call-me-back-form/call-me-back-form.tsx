import React, { useEffect, Dispatch, SetStateAction } from 'react';
import { useFormik, FormikProps } from 'formik';
import { masks, callMeBackSchema } from '@/utils';
import { InputField } from '@/components';
import './call-me-back-form.scss';
import { PersonalDetails } from '@/types';

interface Props {
  initialValues: PersonalDetails;
  formValid: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<PersonalDetails>>;
}

export const CallMeBackForm = ({
  initialValues,
  formValid,
  formValues,
}: Props) => {
  const formik: FormikProps<PersonalDetails> = useFormik<PersonalDetails>({
    initialValues,
    validationSchema: callMeBackSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    formValues(formik.values);
  }, [formValues, formik.values]);

  useEffect(() => {
    formValid(Object.entries(formik.errors).length === 0);
  }, [formValid, formik.errors]);

  return (
    <form className='call-me-back-form'>
      <InputField
        name='firstName'
        label='First name'
        placeholder='Name'
        type='text'
        inputmode='text'
        formik={formik}
        minLength='2'
        maxLength='50'
        autoFocus
        required
      />
      <InputField
        name='surname'
        label='Surname'
        placeholder='Surname'
        type='text'
        inputmode='text'
        formik={formik}
        minLength='2'
        maxLength='50'
        required
      />
      <InputField
        name='cellphoneNumber'
        label='Cellphone number'
        placeholder='Cellphone number'
        type='tel'
        inputmode='tel'
        autocomplete='tel'
        fieldType='masked'
        mask={masks.phoneNumberSpaced}
        formik={formik}
        required
      />
    </form>
  );
};

export default CallMeBackForm;

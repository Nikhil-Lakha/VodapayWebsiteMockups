import React, { useEffect, Dispatch, SetStateAction } from 'react';
import { useFormik, FormikProps } from 'formik';
import classNames from 'classnames';
import { isMobile, masks, personalFormSchema } from '@/utils';
import { PersonalDetails } from '@/types';
import { InputField } from '@/components';
import './personal-details-form.scss';

interface Props {
  small?: boolean;
  validForm: Dispatch<SetStateAction<boolean>>;
  formValues: Dispatch<SetStateAction<PersonalDetails>>;
  initialValues: PersonalDetails;
}

export const PersonalDetailsForm = ({
  small = false,
  validForm,
  formValues,
  initialValues,
}: Props) => {
  const formClass = classNames('custom-form', { 'is-small': small });
  const validationSchema = personalFormSchema(small);

  const formik: FormikProps<PersonalDetails> = useFormik<PersonalDetails>({
    initialValues,
    validationSchema,
    validateOnMount: true,
    enableReinitialize: true,
    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    onSubmit: () => {},
  });

  useEffect(() => {
    validForm(Object.entries(formik.errors).length === 0);
  }, [formik.errors, validForm]);

  useEffect(() => {
    formValues(formik.values);
  }, [formValues, formik.values]);

  return (
    <form className={formClass}>
      <InputField
        name='firstName'
        label='First name'
        placeholder='First name'
        type='text'
        inputmode='text'
        formik={formik}
        minLength='2'
        maxLength='50'
        autoFocus={small}
        required
        disabled={!small}
      />
      <InputField
        name='surname'
        label='Surname'
        placeholder='Surname'
        type='text'
        inputmode='text'
        formik={formik}
        minLength='2'
        maxLength='50'
        required
        disabled={!small}
      />
      {small && (
        <div>
          {isMobile() ? (
            <InputField
              name='dateOfBirth'
              label='Date of birth'
              type='date'
              inputmode='text'
              autocomplete='bday'
              tip='Minimum age of 18 - Maximum 74'
              formik={formik}
              pattern='\d{4}-\d{2}-\d{2}'
              required
            />
          ) : (
            <InputField
              name='dateOfBirth'
              label='Date of birth'
              type='text'
              inputmode='numeric'
              fieldType='date'
              tip='Minimum age of 18 - Maximum 74'
              formik={formik}
              required
            />
          )}
        </div>
      )}
      <InputField
        name='cellphoneNumber'
        label='Cellphone number'
        placeholder='Cellphone number'
        type='tel'
        inputmode='tel'
        autocomplete='tel'
        fieldType='masked'
        mask={masks.phoneNumberSpaced}
        formik={formik}
        required
        disabled={!small}
      />
      {!small && (
        <>
          <InputField
            name='email'
            label='Email address'
            placeholder='Email address'
            type='email'
            inputmode='email'
            autocomplete='email'
            formik={formik}
            minLength='6'
            maxLength='320'
            autoFocus={!small}
            required
          />
          <InputField
            name='idNumber'
            label='ID number'
            placeholder='ID number'
            type='text'
            inputmode='numeric'
            fieldType='masked'
            mask={masks.rsaId}
            tip='Your ID number is protected'
            formik={formik}
          />
        </>
      )}
    </form>
  );
};

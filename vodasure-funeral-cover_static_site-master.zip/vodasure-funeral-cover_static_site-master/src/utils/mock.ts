import { DateTime } from 'luxon';

export const dynamicQuotesMock = () =>
  new Promise((resolve, reject) => {
    setTimeout(
      () =>
        resolve({
          messages: [],
          result: {
            premiumOptions: [
              {
                planName: 'Basic',
                amount: '150',
                vasBenefit: {
                  included: false,
                  amount: '',
                },
                loyaltyBenefit: {
                  included: false,
                  amount: '',
                },
                medicalBenefit: {
                  included: false,
                  amount: '',
                },
              },
            ],
            selectedPremium: {
              amount: 150,
              vasBenefit: { amount: '25' },
              medicalBenefit: { amount: '18' },
            },
          },
          successful: true,
          code: 200,
        }),
      1000
    );
  });

export const vodacomCustomerCheckMock = () => new Promise(resolve => {
  setTimeout(() => resolve({
    messages: [],
    result: {
      mah: false,
      arrears: false,
      customerType: 'CONSUMER',
      subscriberType: 'CONTRACT',
      clientStatus: 'CURRENT',
      c3d: true,
      corporate: false,
      productAccountQualification: false,
      childNumbers: null,
      accountId: '1234'
    },
    successful: false,
    code: 0
  }), 1500);
});

export const eligibilityCheckMock = () =>
  new Promise((resolve, reject) => {
    setTimeout(
      () =>
        resolve({
          messages: [],
          result: {
            haveFuneralCoverPolicy: false,
            individualDetails: '',
            addToBill: true,
            individualDeceased: false,
          },
          successful: true,
          code: 200,
        }),
      1500
    );
  });

export const callMeBackMock = () =>
  new Promise((resolve, reject) => {
    setTimeout(
      () =>
        resolve({
          result: {
            name: '',
            status: 'accepted',
          },
        }),
      1500
    );
  });

export const validateBankAccountMock = () =>
  new Promise((resolve, reject) => {
    setTimeout(
      () =>
        resolve({
          messages: [],
          result: {
            accountExists: 'Y',
            identificationNumberMatched: 'Y',
            canDebitAccount: 'Y',
          },
          successful: true,
          code: 200,
        }),
      1500
    );
  });

export const funeralPolicyOrderMock = () =>
  new Promise((resolve, reject) => {
    setTimeout(
      () =>
        resolve({
          messages: [],
          result: {
            header: {
              date: DateTime.now().toSQL(),
            },
            body: {
              transactionResult: {
                resultCode: 'SUCCESS',
                resultInfo: {
                  policyNumber: '',
                  description: '',
                  referenceNo: '',
                },
              },
            },
          },
          successful: true,
          code: 200,
        }),
      1500
    );
  });

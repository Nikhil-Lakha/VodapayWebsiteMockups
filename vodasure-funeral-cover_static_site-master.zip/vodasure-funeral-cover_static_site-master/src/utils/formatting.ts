import { DateTime } from 'luxon';
import { CoverStartOption } from '@/types';

export const masks = {
  phoneNumber: [
    '+',
    '2',
    '7',
    /[1-9]/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
  ],
  phoneNumberSpaced: [
    '+',
    '2',
    '7',
    ' ',
    /[1-9]/,
    /\d/,
    ' ',
    /\d/,
    /\d/,
    /\d/,
    ' ',
    /\d/,
    /\d/,
    /\d/,
    /\d/,
  ],
  rsaId: [
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    ' ',
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    ' ',
    /\d/,
    /\d/,
    /\d/,
  ],
  date: [/\d/, /\d/, /\d/, /\d/, '/', /[0-1]/, /\d/, '/', /[0-3]/, /\d/],
};

export const stringFormat = {
  stripWhitespace(value: string) {
    if (value && typeof value === 'string' && value !== '') {
      return value.replace(/ /g, '');
    }
    return value;
  },
};

export const removeNonNumericCharacters = (text: string) =>
  text.replace(/[^0-9]/g, '');

export const calcAge = (dateOfBirth: string) => {
  const now: DateTime = DateTime.now();
  const dateOfBirthISO: DateTime = DateTime.fromISO(dateOfBirth);
  if (!dateOfBirthISO.isValid) throw new Error('Date not valid ISO string');
  const years = Number(now.diff(dateOfBirthISO, ['year']).toObject().years);
  if (years < 0) return -1;
  return Math.floor(years || 0);
};

export const formatCurrency = (number: any, formattingOptions: any = {}) => {
  if (number === '' || number === ' ' || !isFinite(Number(number))) {
    return 'R 0.00';
  }
  const formatter = new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
    currencyDisplay: 'symbol',
    ...formattingOptions
  });
  return formatter.formatToParts(number).map(({ type, value }) => {
    switch (type) {
      case 'group': return '\xa0';
      case 'decimal': return '.';
      default: return value;
    }
  }).join('');
};

export const determineCoverStartOption = (debitOrderDay: string) => {
  const now = DateTime.now();
  const fiveDaysFromNow = now.plus({ days: 5 });
  const endOfMonth = now.endOf('month');

  if (
    !DateTime.local(now.year, now.month, Number(debitOrderDay)).isValid &&
    endOfMonth.day > fiveDaysFromNow.day
  ) {
    return CoverStartOption.proceed;
  }

  if (
    fiveDaysFromNow.month === now.month &&
    Number(debitOrderDay) <= fiveDaysFromNow.day
  ) {
    return CoverStartOption.nextMonth;
  }
  if (
    fiveDaysFromNow.month === now.month &&
    Number(debitOrderDay) > fiveDaysFromNow.day
  ) {
    return CoverStartOption.proceed;
  }

  if (
    fiveDaysFromNow.month > now.month &&
    Number(debitOrderDay) > fiveDaysFromNow.day
  ) {
    return CoverStartOption.nextMonth;
  }

  if (
    fiveDaysFromNow.month > now.month &&
    Number(debitOrderDay) <= fiveDaysFromNow.day
  ) {
    return CoverStartOption.twoMonths;
  }

  return '';
};

export const determineCoverStartDate = (
  debitOrderDate: string,
  coverStartOption: CoverStartOption
) => {
  const now = DateTime.now();
  const endOfMonth = now.endOf('month');

  switch (coverStartOption) {
    case CoverStartOption.nextMonth: {
      const finalDate = DateTime.local(
        now.plus({ months: 1 }).year,
        now.plus({ months: 1 }).month,
        Number(debitOrderDate)
      );
      if (!finalDate.isValid) throw new Error('Invalid DateTime');
      return finalDate.toFormat('dd MMMM yyyy');
    }
    case CoverStartOption.twoMonths: {
      const finalDate = DateTime.local(
        now.plus({ months: 2 }).year,
        now.plus({ months: 2 }).month,
        Number(debitOrderDate)
      );
      if (!finalDate.isValid) throw new Error('Invalid DateTime');
      return finalDate.toFormat('dd MMMM yyyy');
    }
    default: {
      let finalDate;
      if (endOfMonth.day < Number(debitOrderDate)) {
        finalDate = DateTime.local(now.year, now.month, endOfMonth.day);
      } else {
        finalDate = DateTime.local(now.year, now.month, Number(debitOrderDate));
      }
      if (!finalDate.isValid) throw new Error('Invalid DateTime');
      return finalDate.toFormat('dd MMMM yyyy');
    }
  }
};

export const filterObject = (
  object: object,
  condition: ([key, value]: [key: string, value: string]) => boolean
) => Object.fromEntries(Object.entries(object || {}).filter(condition));

import { Cache } from '@/services';
import { DevToolSettings, IEnvironment } from '@/types';

export const Environments: { [key: string]: IEnvironment } = {
  Local: {
    name: 'Local',
    env: 'dev',
    uiHost: 'http://localhost:3000',
    apiHost: 'https://apidev.vodacom.co.za/cloud',
    callMeBackApi:
      'https://wwwdev.vodacom.co.za/cloud/rest/sales-lead/v1/sales-lead?sync=true',
    apiBase: '/',
    tealium: 'dev',
    allowDebug: true,
    debugKey: '4acbe7a6-e6f5-43bf-a343-24d2fb333785'
  },
  Dev: {
    name: 'Dev',
    env: 'dev',
    uiHost: 'http://internal-vfs-vodasure-fe-alb-1674241843.eu-west-1.elb.amazonaws.com/funeral-cover',
    apiHost: 'https://apidev.vodacom.co.za/cloud',
    callMeBackApi:
      'https://wwwdev.vodacom.co.za/cloud/rest/sales-lead/v1/sales-lead?sync=true',
    apiBase: '/',
    tealium: 'dev',
    allowDebug: true,
    debugKey: '1af366f0-c8b5-11ed-afa1-0242ac120002'
  },
  QA: {
    name: 'QA',
    env: 'qa',
    uiHost: 'http://internal-vfs-fargate-vodasure-lb-477860667.eu-west-1.elb.amazonaws.com/funeral-cover',
    apiHost: 'https://apiqa.vodacom.co.za/cloud',
    callMeBackApi:
      'https://wwwqa.vodacom.co.za/cloud/rest/sales-lead/v1/sales-lead?sync=true',
    apiBase: '/',
    tealium: 'dev',
    allowDebug: true,
    debugKey: '01600ad0-2052-4833-bf57-0bcc7ad27432'
  },
  Prod: {
    name: 'Production',
    env: 'prod',
    uiHost: 'https://vodasure.vodacom.co.za/funeral-cover',
    apiHost: 'https://api.vodacom.co.za/cloud',
    callMeBackApi:
      'https://www.vodacom.co.za/cloud/rest/sales-lead/v1/sales-lead?sync=true',
    apiBase: '/',
    tealium: 'prod',
    allowDebug: false
  },
};

export const Environment = {
  current: Environments.Prod,
};

// eslint-disable-next-line no-shadow
enum ENVS {
  local = 'local',
  dev = 'dev',
  qa = 'qa',
  prod = 'prod',
}

const envIds: { [key: string]: string[] } = {
  [ENVS.local]: ['127.0.0.1', 'localhost'],
  [ENVS.dev]: ['internal-vfs-vodasure-fe-alb-1674241843.eu-west-1.elb.amazonaws.com', 'dfn1tygy72bja.cloudfront.net'],
  [ENVS.qa]: ['internal-vfs-fargate-vodasure-lb-477860667.eu-west-1.elb.amazonaws.com', 'd1fyhu4paovx7h.cloudfront.net'],
  [ENVS.prod]: ['vodasure.vodacom.co.za'],
};

const findEnv = (host: string, environment: ENVS) => {
  const matchEnvs = envIds[environment];

  return matchEnvs.find(match => host.includes(match)) !== undefined;
};

const initEnv = (host: string, debugConfig?: DevToolSettings) => {
  if (findEnv(host, ENVS.local)) {
    Environment.current = {
      ...debugConfig,
      ...Environments.Local,
      apiHost: debugConfig?.apiHost || Environments.Local.apiHost,
    };
    return ENVS.local;
  }

  if (findEnv(host, ENVS.dev)) {
    Environment.current = {
      ...debugConfig,
      ...Environments.Dev,
      apiHost: debugConfig?.apiHost || Environments.Dev.apiHost,
    };
    return ENVS.dev;
  }

  if (findEnv(host, ENVS.qa)) {
    Environment.current = {
      ...debugConfig,
      ...Environments.QA,
      apiHost: debugConfig?.apiHost || Environments.QA.apiHost
    };
    return ENVS.qa;
  }

  Environment.current = Environments.Prod;
  return ENVS.prod;
};

export const reloadEnvironmentConfig = () => {
  const debugKey = Cache.fetch('debugKey');
  if (debugKey) {
    const debugConfig = Cache.fetch('debugConfig');
    return initEnv(window.location.host, debugConfig);
  }
  return initEnv(window.location.host);
};
reloadEnvironmentConfig();

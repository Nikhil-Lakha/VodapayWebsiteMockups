import { routes } from '@/router';
import range from 'lodash.range';
import { ordinal } from './helpers';
import { PaymentDebitOrder } from '@/assets';
import {
  BeneficiaryRelationships,
  ErrorActions,
  ErrorContent,
  IAssistanceRoutes,
  JourneyStep,
  StepGroups,
  ValidAge,
} from '@/types';
import { TealiumService } from '@/services';

export const applicationDefaults = Object.freeze({
  coverAmounts: [
    { label: 'R 10 000', value: '10000' },
    { label: 'R 20 000', value: '20000' },
    { label: 'R 30 000', value: '30000' },
    { label: 'R 40 000', value: '40000' },
    { label: 'R 50 000', value: '50000' },
  ],
  funeralBenefits: [
    'Body Repatriation',
    'Vouchers for catering, clothing and electricity to assist with funeral expenses',
    "Emergency Helpline and counseling for the deceased's family",
  ],
  dataRewardBenefits: [
    'Flexible discounted monthly data benefit',
    'Exclusive to Vodacom customers',
    'Principal member cover of minimum R20\xa0000 is required to qualify',
  ],
  benefitRequirements: {
    dataReward: {
      minCoverAmount: 20000
    }
  },
  sendPolicyDocumentVia: [
    { label: 'Email', value: 'EMAIL' },
    { label: 'SMS', value: 'SMS' },
  ],
  gender: [
    { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },
  ],
  relationships: [
    { label: 'Wife', value: 'Wife' },
    { label: 'Husband', value: 'Husband' },
    { label: 'Daughter', value: 'Daughter' },
    { label: 'Son', value: 'Son' },
    { label: 'Adult Child', value: 'AdultChild' },
    { label: 'Sister', value: 'Sister' },
    { label: 'Brother', value: 'Brother' },
    { label: 'Mother', value: 'Mother' },
    { label: 'Father', value: 'Father' },
    { label: 'Aunt', value: 'Aunt' },
    { label: 'Uncle', value: 'Uncle' },
    { label: 'Female Cousin', value: 'FemaleCousin' },
    { label: 'Male Cousin', value: 'MaleCousin' },
    { label: 'Niece', value: 'Niece' },
    { label: 'Nephew', value: 'Nephew' },
    { label: 'Grandmother', value: 'Grandmother' },
    { label: 'Grandfather', value: 'Grandfather' },
    { label: 'Granddaughter', value: 'Granddaughter' },
    { label: 'Grandson', value: 'Grandson' },
    { label: 'Other', value: 'Other' },
  ],
  banks: [
    {
      label: 'Absa Bank Limited',
      value: 'ABSA BANK',
      universalBranchCode: '632005',
    },
    {
      label: 'African Bank Limited',
      value: 'AFRICAN BANK',
      universalBranchCode: '430000',
    },
    {
      label: 'Bidvest Bank Limited',
      value: 'BIDVEST BANK',
      universalBranchCode: '462005',
    },
    {
      label: 'Capitec Bank Limited',
      value: 'CAPITEC BANK',
      universalBranchCode: '470010',
    },
    {
      label: 'Discovery Bank Limited',
      value: 'DISCOVERY BANK LTD',
      universalBranchCode: '679000',
    },
    {
      label: 'First National Bank (FNB)',
      value: 'FIRST NATIONAL BANK',
      universalBranchCode: '250655',
    },
    {
      label: 'Investec Bank Limited',
      value: 'INVESTEC BANK',
      universalBranchCode: '580105',
    },
    {
      label: 'Mercantile Bank Limited',
      value: 'MERCANTILE BANK',
      universalBranchCode: '450105',
    },
    {
      label: 'Nedbank Limited',
      value: 'NEDBANK',
      universalBranchCode: '198765',
    },
    {
      label: 'Sasfin Bank Limited',
      value: 'Sasfin Bank Limited',
      universalBranchCode: '683000',
    },
    {
      label: 'Standard Bank of South Africa',
      value: 'STANDARD BANK SA',
      universalBranchCode: '051001',
    },
    {
      label: 'SA Post Bank (Post Office)',
      value: 'SA POST OFFICE',
      universalBranchCode: '460005',
    },
    {
      label: 'Tyme Bank',
      value: 'TYME BANK LIMITED',
      universalBranchCode: '678910',
    },
    {
      label: 'Grindrod Bank Limited',
      value: 'GRINDROD BANK',
      universalBranchCode: '223626',
    },
    {
      label: 'Albaraka Bank Limited',
      value: 'ALBARAKA BANK LIMITED',
      universalBranchCode: '800000',
    },
    {
      label: 'Bank Of Baroda',
      value: 'Bank Of Baroda',
      universalBranchCode: '110167',
    },
    {
      label: 'Barclays',
      value: 'BARCLAYS BANK PLC',
      universalBranchCode: '590000',
    },
    {
      label: 'Habib Overseas Bank',
      value: 'HABIB OVERSEAS BANK LIMITED',
      universalBranchCode: '701505',
    },
    {
      label: 'Ithala (Absa Bank)',
      value: 'Ithala (Absa Bank)',
      universalBranchCode: '756226',
    },
    {
      label: 'S.A. Banks Of Athens',
      value: 'S.A. Banks Of Athens',
      universalBranchCode: '410506',
    },
    {
      label: 'SA Reserve Bank',
      value: 'SA Reserve Bank',
      universalBranchCode: '430000',
    },
    {
      label: 'Standard Chartered Bank',
      value: 'Standard Chartered Bank',
      universalBranchCode: '730020',
    },
    {
      label: 'Teba Bank',
      value: 'Teba Bank',
      universalBranchCode: '431010',
    },
    {
      label: 'Unibank',
      value: 'Unibank',
      universalBranchCode: '790005',
    },
    {
      label: 'VBS Mutual Bank',
      value: 'VBS Mutual Bank',
      universalBranchCode: '588000',
    },
  ],
  accountType: [
    { label: 'Current account', value: 'CURRENT' },
    { label: 'Saving account', value: 'SAVING' },
  ],
  debitOrderDates: range(1, 32).map((day: number) => ({
    label: `${day}${ordinal(day)} of the month`,
    value: `${day}`,
  })),

  paymentTypes: [
    // {
    //   id: 'addToBill',
    //   label: 'Add to Vodacom bill',
    //   title:
    //     'The amount will be added to your Vodacom bill at the end of each month',
    //   value: 'AddToBill',
    //   icon: PaymentAddToBill,
    // },
    {
      id: 'debitOrder',
      label: 'Debit order',
      title:
        'The amount will be deducted from your bank account at the end of each month',
      value: 'DebitOrder',
      icon: PaymentDebitOrder,
    },
  ],
  familyCover: [
    {
      name: 'spouse',
      cover: 'Spouse',
      label: '(Maximum 1 | 18-74 years)',
      maxMembers: 1,
    },
    {
      name: 'child',
      cover: 'Child',
      label: '(Maximum 6 | 0-18 years)',
      maxMembers: 6,
    },
    {
      name: 'extended',
      cover: 'Extended',
      label: '(Maximum 6 | 18-74 years)',
      maxMembers: 6,
    },
  ],
  coverStart: [
    { label: 'Immediately', value: 'Immediately' },
    { label: 'Next Month', value: 'NextMonth' },
  ],
  privacyPolicyUrl:
    'https://www.vodacom.co.za/vodacom/terms/privacy-policy/life-assurance-company',
  termsAndConditionsUrl:
    'https://www.vodacom.co.za/vodacom/terms/family-funeral-cover',
  staticPageUrl:
    'https://www.vodacom.co.za/vodacom/services/insurance/funeral-cover',
  playStoreLink:
    'https://vodapay.go.link/4l5yc',
  appStoreLink: 'https://vodapay.go.link/4l5yc',
  cancellationReasons: [
    { label: 'The quotation is too high', value: 'The quotation is too high' },
    {
      label: 'The products on offer does not cater to my needs',
      value: 'The products on offer does not cater to my needs',
    },
    {
      label: 'I am interested, but I just need time to think about it',
      value: 'I am interested, but I just need time to think about it',
    },
    {
      label:
        'I was browsing the internet and I was not looking to take on a product currently',
      value:
        'I was browsing the internet and I was not looking to take on a product currently',
    },
  ],
  radioOptions: [
    { label: 'True', value: 'true' },
    { label: 'False', value: 'false' },
  ],
});

export const stepGroups: StepGroups = Object.freeze({
  cover_details: 'Cover details',
  quote: 'Your quote',
  personal_details: 'Personal details',
  family_details: 'Your family',
  beneficiary: 'Beneficiary',
  payment_details: 'Payment details',
  confirmation: 'Confirmation',
});

export const steps = Object.freeze({
  cover_details: 'cover_details',
  quote: 'quote',
  personal_details: 'personal_details',
  family_details: 'family_details',
  beneficiary: 'beneficiary',
  payment_details: 'payment_details',
  debit_order_details: 'debit_order_details',
  payment_summary: 'payment_summary',
  confirmation: 'confirmation',
});

export const journeySteps: JourneyStep[] = [
  {
    group: 'cover_details',
    step: steps.cover_details,
    route: routes.coverDetails,
  },
  {
    group: 'quote',
    step: steps.quote,
    route: routes.quote,
  },
  {
    group: 'personal_details',
    step: steps.personal_details,
    route: routes.personalDetails,
  },
  {
    group: 'family_details',
    step: steps.family_details,
    route: routes.familyDetails,
  },
  {
    group: 'beneficiary',
    step: steps.beneficiary,
    route: routes.beneficiary,
  },
  {
    group: 'payment_details',
    step: steps.payment_details,
    route: routes.paymentDetails,
  },
  {
    group: 'payment_details',
    step: steps.debit_order_details,
    route: routes.debitOrderDetails,
  },
  {
    group: 'payment_details',
    step: steps.payment_summary,
    route: routes.paymentSummary,
  },
  {
    group: 'confirmation',
    step: steps.confirmation,
    route: routes.confirmation,
  },
];

export const journeys = Object.freeze({
  individual: 'individualCover',
  family: 'familyCover',
});

export const assistanceRoute: IAssistanceRoutes = Object.freeze({
  funeral: {
    route: '/funeral-assistance',
  },
  dataReward: {
    route: '/data-reward-benefit',
  },
});

export const errorContent: ErrorContent = Object.freeze({
  genericError: {
    title: 'Oops…',
    description: 'Something went wrong. Please try again.',
    primaryButton: { title: 'Ok', action: ErrorActions.retry },
  },
  over18Child: {
    title: 'Something went wrong…',
    description:
      'Your child is older than 18. You may cover them as an extended family member.',
    primaryButton: { title: 'Transfer', route: '/#' },
    secondaryButton: { title: "Don't add", route: '/#' },
  },
  oldSystemAccount: {
    title: 'Oops…',
    description:
      "Your account hasn't been moved to our new system. Please try again or call 082 178 00 for assistance.",
    primaryButton: { title: 'Ok', route: '/#' },
  },
  applicationError: {
    title: 'Something went wrong…',
    description: "We couldn't process your application. Something went wrong. ",
    primaryButton: { title: 'Please try again', action: ErrorActions.retry },
    secondaryButton: { title: 'Cancel', action: ErrorActions.exit },
  },
  applicationCancelled: {
    title: 'Application cancelled',
    description: 'Thank you for your time',
    primaryButton: {
      title: 'Exit',
      action: ErrorActions.exit,
    },
  },
  coverDeclined: {
    title: 'Cover declined',
    description:
      'You must be between 18-74 years old for cover to be legally approved.',
    primaryButton: { title: 'Exit', route: '/#' },
  },
  identityVerification: {
    title: 'Identity verification failed',
    description:
      'The ID number provided has failed the liveness check. Please provide a valid South African ID number.',
    primaryButton: {
      title: 'Ok',
      action: ErrorActions.retry,
      analytics: () => {
        TealiumService.onIdentityVerificationErrorEnd();
      },
    },
    onMount: () => {
      TealiumService.onIdentityVerificationErrorStart();
    },
  },
  existingPolicy: {
    title: 'Existing policy',
    description:
      'You already have an existing funeral policy. Please call 082 178 00 for assistance.',
    primaryButton: {
      title: 'Exit',
      action: ErrorActions.exit,
      analytics: () => {
        TealiumService.onExistingPolicyErrorEnd();
      },
    },
    onMount: () => {
      TealiumService.onExistingPolicyErrorStart();
    },
  },
  accountArrears: {
    title: 'In Arrears',
    description:
      "Your account payments aren't up to date. Please try again or call 082 178 00 for assistance.",
    primaryButton: { title: 'Ok', route: '/#' },
  },
  vodacomBusinessCustomer: {
    title: 'Vodacom Business Customer',
    description:
      "You're a Vodacom Business customer. Please contact your administrator for insurance queries.",
    primaryButton: { title: 'Ok', route: '/#' },
  },
  invalidAccountType: {
    title: 'Invalid account type',
    description:
      "You're a Vodacom Business customer. Please contact your administrator for insurance queries.",
    primaryButton: { title: 'Ok', route: '/#' },
  },
  accountError: {
    title: 'Oops…',
    description:
      "Your account hasn't been moved to our new system. Please try again or call 082 178 00 for assistance.",
    primaryButton: { title: 'Ok', route: '/#' },
  },
  technicalError: {
    title: 'Oops...',
    description:
      'Unfortunately we are having technical issues and are working to resolve these as soon as possible. \nPlease try again later.',
    primaryButton: {
      title: 'Report this error',
      action: ErrorActions.callMeBack,
      analytics: () => {
        TealiumService.onTechnicalErrorEnd('report an issue');
      },
    },
    secondaryButton: {
      title: 'Ok',
      action: ErrorActions.retry,
      analytics: () => {
        TealiumService.onTechnicalErrorEnd('ok');
      },
    },
    onMount: () => {
      TealiumService.onTechnicalErrorStart();
    },
  },
});

export const queryKeys = Object.freeze({
  individualQuote: 'individual-quote',
  familyQuote: 'family-quote',
  startingVasRate: 'starting-vas-rate',
  startingDataRewardRate: 'starting-data-reward-rate',
  callMeBack: 'call-me-back',
  validateBankAccount: 'validate-bank-account',
  funeralPolicyOrder: 'funeral-policy-order',
  vodacomCustomerCheck: 'vodacom-customer-check',
  eligibilityCheck: 'eligibility-check',
});

export const validAge: ValidAge = Object.freeze({
  adult: { type: 'adult', max: 74, min: 18 },
  child: { type: 'child', max: 17, min: 0 },
});

export const childrenRelations = ['son', 'daughter'];

export const spouseMap: { [key: string]: BeneficiaryRelationships } =
  Object.freeze({
    Male: BeneficiaryRelationships.husband,
    Female: BeneficiaryRelationships.wife,
  });

export const ChildMap: { [key: string]: BeneficiaryRelationships } =
  Object.freeze({
    Male: BeneficiaryRelationships.son,
    Female: BeneficiaryRelationships.daughter,
  });

export const premiumPlanNames = Object.freeze({
  basic: 'Basic',
  funeral: 'Basic + VAS',
  dataReward: 'Basic + Data Reward',
  all: 'Basic + Data Reward + VAS',
});

export const paymentMethods = Object.freeze({
  addToBill: 'AddToBill',
  debitOrder: 'DebitOrder',
});

export const errorResponses = Object.freeze({
  debitOrder: [
    "There seems to be a problem with your bank account detail, Please check that the details you've entered are correct and try again",
    "The account number provided doesn't exist or cannot be debit",
  ],
});

import { BeneficiaryRelationships } from '@/types';

export const isMobile = () => {
  const mql = window.matchMedia('(max-width: 576px)');
  return mql.matches;
};

export const ordinal = (number: number) => {
  if ([11, 12, 13].includes(number)) {
    return 'th';
  }
  switch (number % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
};

export const isExtendedFamily = (
  relationship: BeneficiaryRelationships | undefined
) => {
  if (!relationship) {
    return false;
  }
  return !['Wife', 'Husband', 'Daughter', 'Son', 'Mother', 'Father'].includes(
    relationship
  );
};

import { validAge } from './constants';
import { calcAge } from './formatting';

export function idCheckSum(idString: string) {
  let control = -1;
  if (!idString) {
    return false;
  }
  try {
    let a = 0;
    for (let i = 0; i < 6; i++) {
      a += parseInt(idString[2 * i], 10);
    }

    let b = 0;
    for (let i = 0; i < 6; i++) {
      b = b * 10 + parseInt(idString[2 * i + 1], 10);
    }
    b *= 2;
    const bAsString = b.toString();
    let c = 0;
    for (let i = 0; i < bAsString.length; i++) {
      c += parseInt(bAsString[i], 10);
    }
    c += a;
    control = 10 - (c % 10);
    if (control === 10) {
      control = 0;
    }
  } catch {
    /* ignore*/
  }
  return parseInt(idString.slice(-1), 10) === control;
}

export function isValidMobileNumber(mobileNumber: string) {
  return Boolean(mobileNumber) && /^\+27\d{9}$/.test(mobileNumber);
}

export function isValidAlphaCharacters(referralCode: string) {
  return Boolean(referralCode) && /^[A-Z]{3}[^ ]{1,12}$/.test(referralCode);
}

export function isValidAlphabetical(stringValue: string): boolean {
  return (
    Boolean(stringValue) &&
    !/[<>?\\/*+!@$#%^&*()=}{\][|\\|~:;,_0-9]/.test(stringValue)
  );
}

export function isValidNumeric(stringValue: string) {
  return Boolean(stringValue) && /^[0-9]+$/.test(stringValue);
}

export function isValidAge(dateOfBirth: Date, type: string) {
  if (!dateOfBirth) {
    return false;
  }
  const age = calcAge(dateOfBirth.toISOString());
  return age >= validAge[type].min && age <= validAge[type].max;
}

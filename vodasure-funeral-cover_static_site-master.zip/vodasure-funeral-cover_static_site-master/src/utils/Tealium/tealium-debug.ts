/* eslint-disable no-restricted-syntax */
import { distance } from 'fastest-levenshtein';
import { tealiumSpec } from './tealium-spec';
import { Link, View } from '@/types';

type IEvent = View | Link;

const isVariableFieldValue = (field: string) =>
  field &&
  field.trim &&
  field.trim().startsWith('<') &&
  field.trim().endsWith('>');

const getFieldsCompareScore = (fieldA: string, fieldB: string) => {
  if (
    fieldA === fieldB ||
    isVariableFieldValue(fieldA) ||
    isVariableFieldValue(fieldB)
  ) {
    return 1;
  } else if (!fieldA || !fieldB) {
    return 0;
  }
  const dist = distance(fieldA, fieldB);
  const division = dist / Math.max(fieldA.length, fieldB.length);
  return 1 - division;
};

const getEventsCompareScore = (eventA: IEvent, eventB: IEvent) => {
  const keys = Object.keys({ ...eventA, ...eventB });
  let similarityScore = 0;

  keys.forEach(key => {
    similarityScore += getFieldsCompareScore(
      eventA[key as keyof IEvent] || '',
      eventB[key as keyof IEvent] || ''
    );
  });

  return (similarityScore / keys.length) * 100;
};

const getBestMatchingEventFromSpec = (event: IEvent) => {
  let bestScore = 0;
  let bestEvent = {};

  tealiumSpec.forEach(specEvent => {
    const score = getEventsCompareScore(event, specEvent);

    if (score > bestScore) {
      bestScore = score;
      bestEvent = specEvent;
    }
  });

  return {
    bestScore,
    bestEvent,
  };
};

export const prettyPrintTealiumEvent = (obj: IEvent) => {
  const objString = JSON.stringify(obj, undefined, 2);
  console.debug('------------------------------------------------');
  console.debug(`Tagging event fired on page ${window.location.href}\n`);
  if (tealiumSpec) {
    const { bestEvent, bestScore } = getBestMatchingEventFromSpec(obj);
    console.debug(
      `Best match percentage in spec: ${bestScore}% (you can expand matched event object on the next line)`
    );
    console.dir(bestEvent);
  }
  console.debug('------------------------------------------------');
  console.debug(objString);
  console.debug('\n\n');
};

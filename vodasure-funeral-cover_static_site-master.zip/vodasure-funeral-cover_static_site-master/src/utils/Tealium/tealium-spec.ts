import { Link, View } from '@/types';

export const tealiumSpec: (View | Link)[] = [
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    service_application_event: 'start',
    page_name: 'vodasure: funeral cover: cover amount: landing page',
    service_application_name: 'vodasure: funeral cover: cover amount',
    service_application_type: 'query',
  },
  {
    // When user clicks on call me back
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: [page_name]',
    page_tool_name: '[vodasure: funeral cover: [page_name]: call me back]',
  },
  {
    // When user clicks on an amount
    page_tool_event: 'use',
    page_form_event: 'start',
    page_name: 'vodasure: funeral cover: cover amount: landing page',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: [amount chosen]',
    page_form_name: 'few personal details',
  },
  {
    // When user clicks "get a free quote"
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: cover amount: landing page',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: get free quote',
  },
  {
    // When user clicks "continue"
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: cover amount: landing page',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: continue',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name:
      'vodasure: funeral cover: cover amount: landing page: extra cover',
  },
  {
    // When user clicks an option
    page_tool_event: 'use',
    page_name:
      'vodasure: funeral cover: cover amount: landing page: extra cover',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: [add family member/scan qr code]',
  },
  {
    // When user clicks an option
    page_tool_event: 'use',
    service_application_event: 'finish',
    page_name:
      'vodasure: funeral cover: cover amount: landing page: extra cover',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: continue',
    service_application_name: 'vodasure: funeral cover: cover amount',
    service_application_type: 'query',
  },
  {
    // When user clicks an option
    page_tool_event: 'use',
    page_name:
      'vodasure: funeral cover: cover amount: landing page: extra cover',
    page_tool_name:
      'vodasure: funeral cover: cover amount: landing page: claim discount',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    service_application_event: 'start',
    page_name: 'vodasure: funeral cover: your quote',
    service_application_name: 'vodasure: funeral cover: quote',
    service_application_type: 'query',
  },
  {
    // When user clicks the edit button
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: your quote',
    page_tool_name: 'vodasure: funeral cover: your quote: edit',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: your quote',
    page_tool_name:
      'vodasure: funeral cover: your quote: [funeral assistance benefits/medi assit benefits]',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: your quote: medi-assist benefits',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: your quote: medi-assist benefits',
    page_tool_name:
      'vodasure: funeral cover: your quote: medi-assist benefits: [add to cart/back]',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name:
      'vodasure: funeral cover: your quote: funeral assistance benefits',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name:
      'vodasure: funeral cover: your quote: funeral assistance benefits',
    page_tool_name:
      'vodasure: funeral cover: your quote: funeral assistance benefits: [add to cart/back]',
  },
  {
    // When user clicks the accept quote
    page_tool_event: 'use',
    service_application_event: 'finish',
    page_name: 'vodasure: funeral cover: your quote',
    page_tool_name: 'vodasure: funeral cover: your quote: continue',
    service_application_name: 'vodasure: funeral cover: quote',
    service_application_type: 'query',
    product_option: '[funeral assistance] | [data reward]'
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: your quote: cancel quote',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: your quote: cancel quote',
    page_tool_name:
      'vodasure: funeral cover: your quote: cancel quote: [no/yes]',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: your quote: cancel quote: reasons',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: your quote: cancel quote: reasons',
    page_tool_name:
      'vodasure: funeral cover: your quote: cancel quote: reasons: [no/confirm]',
    filter_query: '[option choosen]',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: your quote: cancel quote: confirmed',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    service_application_event: 'start',
    page_name: 'vodasure: funeral cover: your personal details',
    service_application_name: 'vodasure: funeral cover: personal details',
    service_application_type: 'query',
    page_form_name: 'personal details',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    service_application_event: 'finish',
    page_name: 'vodasure: funeral cover: your personal details',
    page_tool_name: 'vodasure: funeral cover: your personal details: back/next',
    service_application_name: 'vodasure: funeral cover: personal details',
    service_application_type: 'query',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    service_application_event: 'start',
    page_name: 'vodasure: funeral cover: add a beneficiary',
    service_application_name: 'vodasure: funeral cover: add a beneficiary',
    service_application_type: 'query',
    page_form_name: 'add a beneficiary',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    service_application_event: 'finish',
    page_name: 'vodasure: funeral cover: add a beneficiary',
    page_tool_name: 'vodasure: funeral cover: add a beneficiary: back/next',
    service_application_name: 'vodasure: funeral cover: add a beneficiary',
    service_application_type: 'query',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    service_application_event: 'start',
    page_name: 'vodasure: funeral cover: payment',
    service_application_name: 'vodasure: funeral cover: payment',
    service_application_type: 'query',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: payment',
    page_tool_name:
      'vodasure: funeral cover: payment: [option choosen]: continue',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: payment details',
    page_form_name: 'payment details',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: payment details',
    page_tool_name:
      'vodasure: funeral cover: payment details: create debit order/back',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: payment summary',
  },
  {
    // When user clicks the options
    page_tool_event: 'use',
    page_name: 'vodasure: funeral cover: payment summary',
    page_tool_name: 'vodasure: funeral cover: payment summary: cancel/buy now',
  },
  {
    // When users land on this page, set the below events.
    event_name: 'view',
    page_name: 'vodasure: funeral cover: payment success',
  },
];

import { prettyPrintTealiumEvent } from './tealium-debug';
import { Environment } from '../Environment';
import { Link, View } from '@/types';

interface CustomWindow extends Window {
  utag?: any;
}

class Tealium {
  _queue: { (): void }[] = [];
  _initialized = false;
  _frequency = 100;
  _timeout = 2000 * this._frequency; // 2 seconds * frequency (milliseconds);
  debug =
    Environment.current?.allowDebug &&
    Environment.current?.debugAnalytics === 'true';

  disable =
    Environment.current.allowDebug &&
    Environment.current.disableAnalytics === 'true';

  constructor() {
    if (!this.disable) {
      this._run();
    }
  }

  _initScriptElement() {
    const env = Environment.current?.tealium || 'dev';
    const scriptSrc = `https://tags.tiqcdn.com/utag/vodafone/za-microservice/${env}/utag.sync.js`;
    const scriptElement = document.createElement('script');
    scriptElement.src = scriptSrc;
    scriptElement.type = 'text/javascript';
    document.head.appendChild(scriptElement);
  }

  _run() {
    if (this.debug) {
      // eslint-disable-next-line no-restricted-syntax
      console.info('############### Tagging Debug Enabled ###############');
    }
    window.setTimeout(() => {
      if ('utag' in window) {
        this._initialized = true;
        this._timeout = 0;

        this._process();
      }

      this._timeout -= this._frequency;

      if (this._timeout > 0) {
        this._run();
      }
    }, this._frequency);
  }

  // Process queue
  _process() {
    if (!this._initialized) {
      return;
    }

    let action = null;

    action = this._queue.shift();

    while (action) {
      action();
      action = this._queue.shift();
    }
  }

  // Send view event
  view(data: View) {
    if (this.debug) {
      prettyPrintTealiumEvent(data);
      return;
    }

    this._queue.push(() => {
      (window as CustomWindow).utag.view(data);
    });
    this._process();
  }

  // Send link event
  link(data: Link) {
    if (data.link_name) {
      data.link_id = data.link_name;
    }

    if (this.debug) {
      prettyPrintTealiumEvent(data);
      return;
    }

    this._queue.push(() => {
      (window as CustomWindow).utag.link(data);
    });

    this._process();
  }
}

export const objTealium = new Tealium();

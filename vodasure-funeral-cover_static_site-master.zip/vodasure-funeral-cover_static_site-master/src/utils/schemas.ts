import * as Yup from 'yup';
import {
  childrenRelations,
  idCheckSum,
  isValidAge,
  isValidAlphabetical,
  isValidMobileNumber,
  isValidNumeric,
  stringFormat,
  validAge,
  isValidAlphaCharacters
} from '@/utils';

export const referralCodeFormSchema = () => {
  const errorMessage = 'Please enter a valid referral code e.g. ABC123456';

  return Yup.object().shape({
    referralCode: Yup.string()
      .min(4, errorMessage)
      .max(15, errorMessage)
      .required('Referral code field must not be empty')
      .test(
        'isValidAlphaCharacters',
        errorMessage,
        referralCode =>
        isValidAlphaCharacters(referralCode || '')
      )
  });
};

export const personalFormSchema = (small: boolean) =>
  Yup.object().shape({
    firstName: Yup.string()
      .min(2, 'Please enter a valid first name')
      .max(50, 'Please enter a valid first name')
      .required('Please enter your first name')
      .test('validAlphabetical', 'Please enter a valid first name', firstName =>
        isValidAlphabetical(firstName || '')
      ),
    surname: Yup.string()
      .min(2, 'Please enter a valid surname')
      .max(50, 'Please enter a valid surname')
      .required('Please enter your surname')
      .test('validAlphabetical', 'Please enter a valid surname', surname =>
        isValidAlphabetical(surname || '')
      ),
    cellphoneNumber: Yup.string()
      .required('Please enter your cellphone number')
      .test(
        'phoneNumberValidation',
        'Please enter a valid cellphone number',
        cellNumber =>
          isValidMobileNumber(stringFormat.stripWhitespace(cellNumber || ''))
      ),
    dateOfBirth: Yup.date().when('isShortForm', (_, field) =>
      small
        ? field
            .typeError('Please enter a valid date of birth')
            .required('Please enter your date of birth')
            .max(
              new Date(),
              'You need to be between the ages of 18 and 74 years to qualify'
            )
            .test(
              'dateOfBirthValidation',
              'You need to be between the ages of 18 and 74 years to qualify',
              (dob: Date) => isValidAge(dob, validAge.adult.type)
            )
        : field
    ),
    email: Yup.string().when('isLongForm', (_, field) =>
      !small
        ? field
            .email('Please enter a valid email address')
            .required('Please enter your email address')
        : field
    ),
    idNumber: Yup.string().when('isLongForm', (_, field) =>
      !small
        ? field
            .matches(
              /* eslint-disable-next-line */
              /^(((\d{2}((0[13578]|1[02])(0[1-9]|[12]\d|3[01])|(0[13456789]|1[012])(0[1-9]|[12]\d|30)|02(0[1-9]|1\d|2[0-8])))|([02468][048]|[13579][26])0229))(( |-)(\d{4})( |-)(\d{3})|(?<temp1>\d{7}))$/,
              'Please enter a valid ID number'
            )
            .required('Please enter your ID number')
            .test(
              'idCheckSum',
              'Please enter a valid ID number',
              (idNumber: string) =>
                idCheckSum(stringFormat.stripWhitespace(idNumber))
            )
        : field
    ),
  });

export const beneficiaryFormSchema = (isFamilyCover: boolean) =>
  Yup.object().shape({
    selectBeneficiary: Yup.string().when('isFamilyCover', (_, field) =>
      isFamilyCover ? field.required('Required') : field
    ),
    firstName: Yup.string()
      .min(2, 'Please enter a valid first name')
      .max(50, 'Please enter a valid first name')
      .required("Please enter the beneficiary's first name"),
    surname: Yup.string()
      .min(2, 'Please enter a valid surname')
      .max(50, 'Please enter a valid surname')
      .required("Please enter the beneficiary's surname"),
    cellphoneNumber: Yup.string()
      .required("Please enter the beneficiary's cellphone number")
      .test(
        'phoneNumberValidation',
        'Please enter a valid cellphone number',
        mobileNumber =>
          isValidMobileNumber(stringFormat.stripWhitespace(mobileNumber || ''))
      ),
    relationship: Yup.string().required('Please select a relationship'),
    dateOfBirth: Yup.date()
      .typeError('Please enter a valid date of birth')
      .required("Please enter the beneficiary's date of birth")
      .test(
        'dateOfBirthValidation',
        'Please enter a valid date of birth',
        function dobTest(dob) {
          if (!dob) return false;
          // eslint-disable-next-line no-invalid-this
          const relationship = this.parent?.relationship || '';
          const ageType = childrenRelations.includes(relationship.toLowerCase())
            ? validAge.child.type
            : validAge.adult.type;
          return isValidAge(dob, ageType);
        }
      ),
    gender: Yup.string().required('Required'),
  });

const familyFormSchema = (ageRange: string) =>
  Yup.object().shape({
    firstName: Yup.string()
      .min(2, 'Please enter a valid first name')
      .max(50, 'Please enter a valid first name')
      .required('Please enter the first name')
      .test('validAlphabetical', 'Please enter a valid first name', firstName =>
        isValidAlphabetical(firstName || '')
      ),
    surname: Yup.string()
      .min(2, 'Please enter a valid surname')
      .max(50, 'Please enter a valid surname')
      .required('Please enter the surname')
      .test('validAlphabetical', 'Please enter a valid surname', surname =>
        isValidAlphabetical(surname || '')
      ),
    dateOfBirth: Yup.date()
      .typeError('Please enter a valid date of birth')
      .required('Please enter the date of birth')
      .test(
        'dateOfBirthValidation',
        ageRange === validAge?.child.type
          ? 'Member needs to be between the ages of 0 and 18 years to qualify'
          : 'Member needs to be between the ages of 18 and 74 years to qualify',
        dob => {
          if (!dob) return false;
          return isValidAge(dob, ageRange);
        }
      ),
    gender: Yup.string().required('Please select a gender'),
  });

export const familyDetailsFormSchema = Yup.object().shape({
  spouse: Yup.array().of(familyFormSchema(validAge?.adult.type)),
  child: Yup.array().of(familyFormSchema(validAge?.child.type)),
  extended: Yup.array().of(familyFormSchema(validAge?.adult.type)),
});

export const debitOrderFormSchema = (showBranchCode: boolean) =>
  Yup.object().shape({
    bankName: Yup.string().required('Please select a bank'),
    accountNumber: Yup.string()
      .min(6, 'Please enter a valid account number')
      .max(15, 'Please enter a valid account number')
      .required('Please enter the account number')
      .test(
        'validNumerical',
        'Please enter a valid account number',
        accountNumber => isValidNumeric(accountNumber || '')
      ),
    accountType: Yup.string().required('Please select an account type'),
    branchCode: Yup.string().when('showBranchCode', (_, field) =>
      showBranchCode
        ? field
            .min(2, 'Please enter a valid branch code')
            .max(50, 'Please enter a valid branch code')
            .required('Please enter the branch code')
        : field
    ),
    accountHolderName: Yup.string()
      .min(2, 'Please enter a valid account holder name')
      .max(50, 'Please enter a valid account holder name')
      .required("Please enter the account holder's name")
      .test(
        'validAlphabetical',
        'Please enter a valid account holder name',
        accountHolderName => isValidAlphabetical(accountHolderName || '')
      ),
    debitOrderDate: Yup.string().required(
      'Please select a preferred debit order date'
    ),
    coverStart: Yup.string().required('Please select a preferred cover start'),
  });

export const familyMembersFormSchema = Yup.object().shape({
  spouse: Yup.array().of(
    Yup.object().shape({
      dateOfBirth: Yup.date()
        .typeError('Please enter a valid date of birth')
        .required("Please enter your spouse's date of birth")
        .test(
          'dateOfBirthValidation',
          'Please enter a valid date of birth',
          dob => {
            if (!dob) return false;
            return isValidAge(dob, validAge.adult.type);
          }
        ),
    })
  ),
  child: Yup.array().of(
    Yup.object().shape({
      dateOfBirth: Yup.date()
        .typeError('Please enter a valid date of birth')
        .required("Please enter your child's date of birth")
        .test(
          'dateOfBirthValidation',
          'Please enter a valid date of birth',
          dob => {
            if (!dob) return false;
            return isValidAge(dob, validAge.child.type);
          }
        ),
    })
  ),
  extended: Yup.array().of(
    Yup.object().shape({
      dateOfBirth: Yup.date()
        .typeError('Please enter a valid date of birth')
        .required("Please enter your extend member's date of birth")
        .test(
          'dateOfBirthValidation',
          'Please enter a valid date of birth',
          dob => {
            if (!dob) return false;
            return isValidAge(dob, validAge.adult.type);
          }
        ),
      coverAmount: Yup.string().required('Please select a cover amount'),
    })
  ),
});

export const cancellationFormSchema = Yup.object().shape({
  reason: Yup.string().required('Please select a reason'),
});

export const callMeBackSchema = Yup.object().shape({
  firstName: Yup.string()
    .min(2, 'Please enter a valid first name')
    .max(50, 'Please enter a valid first name')
    .required('Please enter first name')
    .test('validAlphabetical', 'Please enter a valid first name', firstName =>
      isValidAlphabetical(firstName || '')
    ),
  surname: Yup.string()
    .min(2, 'Please enter a valid surname')
    .max(50, 'Please enter a valid surname')
    .required('Please enter surname')
    .test('validAlphabetical', 'Please enter a valid surname', surname =>
      isValidAlphabetical(surname || '')
    ),
  cellphoneNumber: Yup.string()
    .required('Please enter cellphone number')
    .test(
      'phoneNumberValidation',
      'Please enter a valid cellphone number',
      cellNumber =>
        isValidMobileNumber(stringFormat.stripWhitespace(cellNumber || ''))
    ),
});

export const devToolsFormSchema = Yup.object().shape({
  apiRequests: Yup.string().required('Please select an option'),
  disableAnalytics: Yup.string().required('Please select an option'),
  apiHost: Yup.string().required('Please select an option'),
});

import React from 'react';
import { useLocation } from 'react-router-dom';
import { Error } from '@/components';
import { errorContent } from '@/utils';
import './error-screen.scss';

export const ErrorScreen = () => {
  const location = useLocation();
  const type = location?.state?.type || 'genericError';
  const { title, description, primaryButton, secondaryButton } =
    errorContent[type];

  return (
    <Error
      title={title}
      description={description}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      errorType={type}
    />
  );
};

import React, { useContext, useEffect } from 'react';
import { AppContext } from '@/context';
import {
  NavigationHeader,
  NavigationFooter,
  Tip,
  TermsAndConditions,
} from '@/components';
import { applicationDefaults, formatCurrency } from '@/utils';
import { SuccessIcon } from '@/assets';
import { Cache, TealiumService } from '@/services';
import { useJourneyService } from '@/hooks';
import './confirmation.scss';

export const Confirmation = () => {
  const { personalDetails, productDetails, paymentDetails, clearApplication } =
    useContext(AppContext);
  const { currentStep, journeySteps } = useJourneyService();
  const { paymentTypes, termsAndConditionsUrl, staticPageUrl } =
    applicationDefaults;

  useEffect(() => {
    TealiumService.onConfirmationStart();
  }, []);

  function handleNext() {
    clearApplication();
    Cache.clear();
    window.location.href = staticPageUrl;
  }

  return (
    <>
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        hideBack
      />
      <main className='main-content'>
        <img className='heading-icon' src={SuccessIcon} alt='icon' />
        <h1 className='heading-1 with-underline'>Success!</h1>
        <p className='paragraph-1'>
          Your application has been successfully submitted.
          <br /> We will send you an sms and email confirmation shortly.
          <br /> Please be on the lookout for your policy document.
        </p>
        <section className='confirmation-wrapper'>
          <article className='card-wrapper'>
            <section className='section-content'>
              <div className='content-item'>
                <p className='content-item-label'>Date and time:</p>
                <p>
                  {productDetails?.createdAt || '1 November 2022  |  10:30'}
                </p>
              </div>
            </section>
            <section className='section-content'>
              <div className='content-item'>
                <p className='content-item-label'>Payment method:</p>
                <span className='content-item-image'>
                  <img
                    src={
                      paymentTypes.find(
                        ({ value }) => value === paymentDetails.paymentMethod
                      )?.icon
                    }
                    alt='payment method'
                  />
                  <p className='content-item-value'>
                    {
                      paymentTypes.find(
                        ({ value }) => value === paymentDetails.paymentMethod
                      )?.label
                    }
                  </p>
                </span>
              </div>
              <div className='content-item'>
                <p className='content-item-label'>Total monthly premium:</p>
                <p className='content-item-value'>
                  {formatCurrency(productDetails?.totalPremium || 0)}
                </p>
              </div>
            </section>
            <section className='section-content'>
              <div className='content-item'>
                <p className='content-item-label'>Product type:</p>
                <p className='content-item-value'>vodasure | funeral cover</p>
              </div>
              <div className='content-item'>
                <p className='content-item-label'>Cover amount:</p>
                <p className='content-item-value'>
                  {formatCurrency(productDetails?.coverAmount || 0)}
                </p>
              </div>
              <div className='content-item'>
                <p className='content-item-label'>Cover start date:</p>
                <p className='content-item-value'>
                  {productDetails?.coverStart || '1 December 2022'}
                </p>
              </div>
            </section>
            <section className='section-content'>
              <div className='content-item'>
                <p className='content-item-label'>Full name:</p>
                <p className='content-item-value'>
                  {personalDetails.firstName}&nbsp;{personalDetails.surname}
                </p>
              </div>
              <div className='content-item'>
                <p className='content-item-label'>Cellphone number:</p>
                <p className='content-item-value'>
                  {personalDetails.cellphoneNumber}
                </p>
              </div>
              <div className='content-item'>
                <p className='content-item-label'>Email address:</p>
                <p className='content-item-value'>{personalDetails.email}</p>
              </div>
            </section>
          </article>
          <TermsAndConditions>
            <p className='main-text'>
              VodaSure | Funeral Cover{' '}
              <a href={termsAndConditionsUrl} rel='noreferrer' target='_blank'>
                Terms and conditions
              </a>
            </p>
          </TermsAndConditions>
          <Tip
            text='For any policy related queries after you have received documentation or if you do not receive your policy within 48 hours.'
            type='contact'
            linkText='Call 082 178 00'
            link='tel:08217800'
          />
        </section>
      </main>

      <NavigationFooter
        onNext={handleNext}
        nextEnabled
        nextButtonLabel='Done'
        hideBack
      />
    </>
  );
};

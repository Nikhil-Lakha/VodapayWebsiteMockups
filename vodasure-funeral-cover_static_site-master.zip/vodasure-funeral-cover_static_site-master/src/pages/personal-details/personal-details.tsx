import React, { useState, useContext, useEffect } from 'react';
import { useQuery } from 'react-query';
import { AppContext } from '@/context';
import { useErrorHandler, useNavService, useJourneyService } from '@/hooks';
import { ErrorTypes, PersonalDetails as PersonalDetailsType } from '@/types';
import { queryKeys, stringFormat, removeNonNumericCharacters } from '@/utils';
import { routes } from '@/router';
import { TealiumService, eligibilityCheck } from '@/services';
import { PersonalDetailsForm } from '@/forms';
import { NavigationHeader, NavigationFooter, Loader } from '@/components';
import './personal-details.scss';

interface ResponseData {
  messages: [];
  result: {
    haveFuneralCoverPolicy: boolean;
    individualDetails: unknown;
    addToBill: boolean;
    individualDeceased: boolean;
  };
  successful: boolean;
  code: number;
}

export const PersonalDetails = () => {
  const {
    personalDetails,
    setPersonalDetails,
    isFamilyJourney,
    setIsAddToBill,
  } = useContext(AppContext);
  const [formValid, setFormValid] = useState(false);
  const [formValues, setFormValues] = useState<PersonalDetailsType>({});
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();
  const handleError = useErrorHandler();

  useEffect(() => {
    TealiumService.onPersonalStart();
  }, []);

  function handleEligibilityCheck(data: ResponseData) {
    if (data.result) {
      const { haveFuneralCoverPolicy, addToBill, individualDeceased } =
        data.result;

      setIsAddToBill(addToBill);

      if (haveFuneralCoverPolicy) {
        handleError(new Error(ErrorTypes.existingPolicy));
        return;
      }
      if (individualDeceased) {
        handleError(new Error(ErrorTypes.identityVerification));
        return;
      }
      navigate.to(isFamilyJourney ? routes.familyDetails : routes.beneficiary);
    }
  }

  const { isFetching, isError, refetch } = useQuery(
    queryKeys.eligibilityCheck,
    () =>
      eligibilityCheck(
        removeNonNumericCharacters(
          stringFormat.stripWhitespace(personalDetails?.cellphoneNumber || '')
        ),
        stringFormat.stripWhitespace(formValues?.idNumber || '')
      ),
    {
      enabled: false,
      refetchOnWindowFocus: false,
      onSuccess: handleEligibilityCheck,
      retry: 2,
    }
  );

  useEffect(() => {
    if (isError) {
      handleError(new Error('genericError'));
    }
  }, [handleError, isError]);

  function handleBack() {
    TealiumService.onPersonalEnd('back');
    navigate.back();
  }

  function handleNext() {
    TealiumService.onPersonalEnd('next');
    setPersonalDetails(prev => ({
      ...prev,
      ...formValues,
      idNumber: stringFormat.stripWhitespace(formValues?.idNumber || ''),
    }));
    refetch();
  }

  const initialValues = {
    firstName: personalDetails?.firstName || '',
    surname: personalDetails?.surname || '',
    cellphoneNumber: personalDetails?.cellphoneNumber || '',
    email: personalDetails?.email || '',
    idNumber: personalDetails?.idNumber || '',
  };

  if (isFetching) {
    return <Loader />;
  }

  return (
    <>
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={handleBack}
      />

      <main className='main-content'>
        <h1 className='heading-1'>Great, now let&apos;s create your policy</h1>
        <p className='paragraph-1'>Please complete your details below</p>
        <section className='personal-details-form'>
          <PersonalDetailsForm
            validForm={setFormValid}
            formValues={setFormValues}
            initialValues={initialValues}
          />
        </section>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={formValid}
        nextButtonLabel='Next'
        backButtonLabel='Back'
      />
    </>
  );
};

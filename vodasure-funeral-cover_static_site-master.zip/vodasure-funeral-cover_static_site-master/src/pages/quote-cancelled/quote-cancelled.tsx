import React, { useEffect } from 'react';
import { Error } from '@/components';
import { errorContent } from '@/utils';
import { TealiumService } from '@/services';

export const QuoteCancelled = () => {
  const { title, description, primaryButton } =
    errorContent.applicationCancelled;

  useEffect(() => {
    TealiumService.onApplicationCancelled();
  }, []);

  return (
    <Error
      title={title}
      description={description}
      primaryButton={primaryButton}
      errorType='applicationCancelled'
    />
  );
};

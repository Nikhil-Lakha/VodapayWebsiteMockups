import React, { useState, useContext, useEffect } from 'react';
import { useQuery } from 'react-query';
import { DateTime } from 'luxon';
import { AppContext } from '@/context';
import { useErrorHandler, useNavService, useJourneyService } from '@/hooks';
import { routes } from '@/router';
import { DebitOrderForm } from '@/forms';
import { TealiumService, validateBankAccount } from '@/services';
import { queryKeys, determineCoverStartDate, errorResponses } from '@/utils';
import { CoverStartOption, PaymentDetails } from '@/types';
import {
  NavigationHeader,
  NavigationFooter,
  Loader,
  Notification,
} from '@/components';
import './debit-order.scss';

interface ResponseData {
  messages: [];
  result: {
    accountExists: string;
    identificationNumberMatched: string;
    canDebitAccount: string;
    exceptionMessage?: string;
  };
  successful: boolean;
  code: number;
  status?: number;
}

export const DebitOrder = () => {
  const {
    personalDetails,
    paymentDetails,
    setProductDetails,
    setPaymentDetails,
  } = useContext(AppContext);
  const [formValid, setFormValid] = useState(false);
  const [formValues, setFormValues] = useState<PaymentDetails>({});
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  const [coverStartOption, setCoverStartOption] = useState<CoverStartOption>(
    CoverStartOption.proceed
  );
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();
  const handleError = useErrorHandler();

  function handleResponse(data: ResponseData) {
    if (
      data &&
      data.result?.exceptionMessage &&
      errorResponses.debitOrder.some(
        value =>
          data.result?.exceptionMessage &&
          data.result?.exceptionMessage.includes(value)
      )
    ) {
      setNotificationMessage(
        "There seems to be a problem with your bank account details. Please check that the details you've entered are correct and try again."
      );
      setShowNotification(true);
      return;
    }

    if (data) {
      const { accountExists, identificationNumberMatched, canDebitAccount } =
        data.result;
      if (
        accountExists === 'Y' &&
        identificationNumberMatched === 'Y' &&
        canDebitAccount === 'Y'
      ) {
        navigate.to(routes.paymentSummary);
        return;
      }
    }

    handleError(new Error('genericError'));
  }

  const { refetch, isFetching, isError } = useQuery(
    queryKeys.validateBankAccount,
    () =>
      validateBankAccount({
        payment: formValues,
        idNumber: personalDetails?.idNumber || '',
      }),
    {
      refetchOnWindowFocus: false,
      enabled: false,
      retry: false,
      onSuccess: handleResponse,
    }
  );

  useEffect(() => {
    TealiumService.onDebitOrderStart();
  }, []);

  useEffect(() => {
    if (isError) {
      handleError(new Error('genericError'));
    }
  }, [handleError, isError]);

  function handleNext() {
    TealiumService.onDebitOrderEnd('create debit order');
    setPaymentDetails(prev => ({
      ...prev,
      ...formValues,
    }));
    setProductDetails(prev => ({
      ...prev,
      coverType: prev.coverType,
      coverStart: determineCoverStartDate(
        formValues.debitOrderDate || '1',
        formValues.coverStartOption || CoverStartOption.proceed
      ),
    }));
    refetch();
  }

  useEffect(() => {
    if (coverStartOption === CoverStartOption.nextMonth) {
      const monthFromToday = DateTime.now().plus({ months: 1 });
      const month = monthFromToday.monthLong;
      setShowNotification(true);
      setNotificationMessage(
        `Please note that due to your debit order date being less than 5 days' from collection, your selection start date will start in ${month}`
      );
    }
  }, [coverStartOption]);

  function handleBack() {
    TealiumService.onDebitOrderEnd('back');
    navigate.back();
  }

  const initialValues: PaymentDetails = {
    bankName: paymentDetails?.bankName || '',
    accountNumber: paymentDetails?.accountNumber || '',
    accountType: paymentDetails?.accountType,
    branchCode: paymentDetails?.branchCode || '',
    accountHolderName: paymentDetails?.accountHolderName || '',
    debitOrderDate: paymentDetails?.debitOrderDate || '',
    coverStart: paymentDetails?.coverStart,
  };

  if (isFetching) {
    return <Loader />;
  }

  return (
    <>
      <Notification
        message={notificationMessage}
        buttonText='Dismiss'
        visible={showNotification}
        setVisible={setShowNotification}
        interval={7000}
        onDismiss={() => setShowNotification(false)}
      />
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={handleBack}
      />
      <main className='main-content'>
        <h1 className='heading-1'>Debit order details</h1>
        <p className='paragraph-1'>
          We need your banking details to create a monthly debit order
        </p>
        <section className='form-section'>
          <DebitOrderForm
            validForm={setFormValid}
            formValues={setFormValues}
            initialValues={initialValues}
            setCoverStartOption={setCoverStartOption}
          />
        </section>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={formValid}
        nextButtonLabel='Create Debit Order'
        backButtonLabel='Back'
      />
    </>
  );
};

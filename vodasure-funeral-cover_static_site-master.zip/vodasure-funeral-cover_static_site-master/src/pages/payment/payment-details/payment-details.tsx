import React, { useState, useContext, useEffect, ChangeEvent } from 'react';
import { AppContext } from '@/context';
import { useNavService, useJourneyService } from '@/hooks';
import { routes } from '@/router';
import { applicationDefaults } from '@/utils';
import { PaymentMethods } from '@/types';
import {
  NavigationHeader,
  NavigationFooter,
  PaymentSelector,
  SecurityDisclaimer,
} from '@/components';
import { TealiumService } from '@/services';
import './payment-details.scss';

export const PaymentDetails = () => {
  const { setPaymentDetails } = useContext(AppContext);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethods>(
    PaymentMethods.unset
  );
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();

  const { paymentTypes } = applicationDefaults;

  function handleMethodChange(event: ChangeEvent<HTMLInputElement>) {
    setSelectedMethod(event.target.value as PaymentMethods);
  }

  function handleNext() {
    if (selectedMethod === PaymentMethods.addToBill) {
      setPaymentDetails(prev => ({
        ...prev,
        paymentMethod: PaymentMethods.addToBill,
        coverStart: '',
      }));
      navigate.to(routes.paymentSummary);
      return;
    }
    TealiumService.onPaymentMethodContinue(selectedMethod);
    setPaymentDetails(prev => ({
      ...prev,
      paymentMethod: selectedMethod,
    }));
    navigate.to(routes.debitOrderDetails);
  }

  useEffect(() => {
    TealiumService.onPaymentMethodStart();
  }, []);

  return (
    <>
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={() => navigate.back()}
      />
      <main className='main-content'>
        <h1 className='heading-1'>Select payment method</h1>
        <p className='paragraph-1'>
          How would you like to pay for your cover today?
        </p>
        <section>
          {paymentTypes.map(({ id, icon, label, title, value }, index) => (
            <PaymentSelector
              key={index}
              id={id}
              src={icon}
              label={label}
              title={title}
              value={value}
              handleChange={handleMethodChange}
            />
          ))}
          <SecurityDisclaimer />
        </section>
      </main>

      <NavigationFooter
        onBack={() => navigate.back()}
        onNext={handleNext}
        nextEnabled={selectedMethod !== ''}
        nextButtonLabel='Next'
        backButtonLabel='Back'
      />
    </>
  );
};

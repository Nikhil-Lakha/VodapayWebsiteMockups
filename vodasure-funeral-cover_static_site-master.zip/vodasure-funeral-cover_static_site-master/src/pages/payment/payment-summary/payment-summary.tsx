import React, { useContext, useEffect, useState } from 'react';
import { useQuery } from 'react-query';
import { DateTime } from 'luxon';
import { AppContext } from '@/context';
import { PaymentMethods } from '@/types';
import { useNavService, useJourneyService, useErrorHandler } from '@/hooks';
import { routes } from '@/router';
import { applicationDefaults, queryKeys } from '@/utils';
import { funeralPolicyOrder, kycXDSCheckRequest, kycAVSCheckRequest, TealiumService } from '@/services';
import { PaymentSummaryForm } from '@/forms';
import { QuestionMarkCircle } from '@/assets';
import {
  NavigationHeader,
  NavigationFooter,
  QuoteCard,
  TermsAndConditions,
  Loader,
  CancellationReasons,
  Modal,
  Button,
} from '@/components';
import './payment-summary.scss';

interface ResponseData {
  messages: [];
  result: {
    header: {
      date: string;
    };
    body: {
      transactionResult: {
        resultCode: string;
        resultInfo: {
          policyNumber: string;
          description: string;
          referenceNo: string;
        };
      };
    };
  };
  successful: boolean;
  code: number;
}

export const PaymentSummary = () => {
  const {
    personalDetails,
    productDetails,
    paymentDetails,
    familyDetails,
    beneficiaryDetails,
    setProductDetails,
    referralCode,
    isAddToBill
  } = useContext(AppContext);
  const [showCancellationModal, setShowCancellationModel] =
    useState<boolean>(false);
  const [showDialog, setShowDialog] = useState<boolean>(false);
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();
  const handleError = useErrorHandler();

  const { privacyPolicyUrl, termsAndConditionsUrl } = applicationDefaults;

  async function handlePolicyOrder(data: ResponseData) {
    if (data && data?.result) {
      const result = data.result;
      const { resultCode } = result?.body?.transactionResult || '';
      if (resultCode === 'SUCCESS') {
        try {
          await kycXDSCheckRequest({ personal: personalDetails });
          if (paymentDetails?.paymentMethod === PaymentMethods.debitOrder) {
            await kycAVSCheckRequest({ personal: personalDetails, payment: paymentDetails });
          }
        }
        catch (e) {
          console.error('Exception occured while saving kyc checks', e);
        }
        const { date } = result?.header || '';
        const parsedDate = DateTime.fromSQL(date);
        setProductDetails(prev => ({
          ...prev,
          createdAt: `${parsedDate.toLocaleString(
            DateTime.DATE_FULL
          )} | ${parsedDate.toLocaleString(DateTime.TIME_24_SIMPLE)}`,
        }));
        navigate.to(routes.confirmation);
        return;
      }
    }
    handleError(new Error('applicationError'));
  }

  const { isFetching, refetch } = useQuery(
    queryKeys.funeralPolicyOrder,
    () =>
      funeralPolicyOrder({
        personal: personalDetails,
        payment: paymentDetails,
        family: familyDetails,
        beneficiary: beneficiaryDetails,
        product: productDetails,
        referralCode
      }),
    {
      refetchOnWindowFocus: false,
      enabled: false,
      retry: false,
      onSuccess: handlePolicyOrder,
    }
  );

  useEffect(() => {
    TealiumService.onPaymentSummaryStart();
  }, []);

  function handleNext() {
    TealiumService.onPaymentSummaryEnd('buy now');
    refetch({ throwOnError: true });
  }

  function handleBack() {
    TealiumService.onPaymentSummaryEnd('cancel');
    setShowDialog(true);
  }

  function handleCloseCancellationModal() {
    setShowCancellationModel(false);
  }

  function handleConfirmCancellation() {
    setShowCancellationModel(false);
    navigate.to(routes.quoteCancelled);
  }

  function handleCancelDialog() {
    setShowCancellationModel(true);
    setShowDialog(false);
  }

  if (isFetching) {
    return <Loader />;
  }

  return (
    <>
      <Modal
        onClickClose={() => setShowDialog(false)}
        onOpen={() => TealiumService.onDeclineQuoteView()}
        show={showDialog}
        type='dialog'
      >
        <>
          <img
            src={QuestionMarkCircle}
            alt='question-mark'
            className='dialog-icon'
          />
          <p className='dialog-heading'>Are you sure you want to cancel?</p>
          <section className='dialog-button-group'>
            <Button onClick={() => setShowDialog(false)} secondary>
              No, don&apos;t cancel
            </Button>
            <Button onClick={handleCancelDialog} primary>
              Yes, cancel
            </Button>
          </section>
        </>
      </Modal>
      <CancellationReasons
        handleClose={handleCloseCancellationModal}
        handleConfirm={handleConfirmCancellation}
        show={showCancellationModal}
      />
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={handleBack}
      />
      <main className='main-content'>
        <h1 className='heading-1'>Payment summary</h1>
        <p className='paragraph-1'>Monthly premium to cover your life only</p>
        <QuoteCard
          product={productDetails}
          personal={personalDetails}
          payment={paymentDetails}
          family={familyDetails}
          selectedAddOns={
            productDetails?.addOns || { funeral: {}, dataReward: {} }
          }
          step='summary'
        />
        <section className='agree-conditions'>
          <PaymentSummaryForm
            id='agreeToTerms'
            name='agreeToTerms'
            initialValues={{
              agreeToTerms: paymentDetails?.agreeToTerms || false,
            }}
          />
          <TermsAndConditions>
            <p className='main-text'>
              <a href={termsAndConditionsUrl} rel='noreferrer' target='_blank'>
                Terms and conditions
              </a>
              <span>and</span>
              <a href={privacyPolicyUrl} target='_blank' rel='noreferrer'>
                Privacy Policy.
              </a>
            </p>
          </TermsAndConditions>
        </section>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={paymentDetails?.agreeToTerms || false}
        nextButtonLabel='Buy now'
        backButtonLabel='Cancel'
      />
    </>
  );
};

/* eslint-disable complexity */
import React, { useState, useContext, useEffect } from 'react';
import { AppContext } from '@/context';
import {
  useNavService,
  useJourneyService,
  useBenefitQualification,
} from '@/hooks';
import { applicationDefaults, journeys, premiumPlanNames } from '@/utils';
import { routes } from '@/router';
import { TealiumService } from '@/services';
import {
  NavigationHeader,
  NavigationFooter,
  QuoteCard,
  AddOnCard,
  TermsAndConditions,
  Modal,
  Button,
  CancellationReasons,
} from '@/components';
import { QuestionMarkCircle } from '@/assets';
import './quote.scss';

export const Quote = () => {
  const {
    personalDetails,
    productDetails,
    paymentDetails,
    familyDetails,
    setProductDetails,
    setIsFamilyJourney,
    premiumOptions,
  } = useContext(AppContext);
  const [showDialog, setShowDialog] = useState(false);
  const [showCancellationModal, setShowCancellationModel] = useState(false);
  const { currentStep, journeySteps } = useJourneyService();
  const { qualifies: qualifiesForDataReward } =
    useBenefitQualification('dataReward');
  const navigate = useNavService();

  const { funeralBenefits, dataRewardBenefits, termsAndConditionsUrl } =
    applicationDefaults;

  useEffect(() => {
    TealiumService.onQuoteStart();
  }, []);

  useEffect(() => {
    if (!premiumOptions) {
      return;
    }

    const dataReward = productDetails.addOns?.dataReward;
    const funeral = productDetails.addOns?.funeral;
    const totalPremium = premiumOptions
      .filter(option =>
        Object.values(premiumPlanNames).includes(
          option?.planName || premiumPlanNames.basic
        )
      )
      .find(
        option =>
          Boolean(option?.dataRewardBenefit?.included) ===
            Boolean(dataReward?.state) &&
          Boolean(option?.vasBenefit.included) === Boolean(funeral?.state)
      )?.amount;

    setProductDetails(prev => ({
      ...prev,
      totalPremium: Number(totalPremium),
    }));
  }, [productDetails.addOns, premiumOptions]);

  function handleNext() {
    const { funeral, dataReward } = productDetails.addOns || {};
    const addOns = [{ addOn: funeral, label: 'funeral assistance' }, { addOn: dataReward, label: 'data reward' }]
    .filter(({ addOn }) => Boolean(addOn?.state))
    .map(({ label }) => label);
    TealiumService.onQuoteAccept(addOns);

    if (productDetails.coverType === journeys.family) {
      setIsFamilyJourney(true);
    }

    navigate.to(routes.personalDetails);
  }

  function handleEditQuote() {
    TealiumService.onQuoteEdit();
    navigate.with(routes.coverDetails, { edit: true });
  }

  function toggleAddOn(type: string) {
    TealiumService.onAddOns(type);
    setProductDetails(prev => ({
      ...prev,
      addOns: {
        ...(prev?.addOns || {
          funeral: { state: false },
          dataReward: { state: false },
        }),
        [type]: {
          ...(prev?.addOns as any)[type],
          state: !(prev.addOns as any)[type]?.state,
        },
      },
    }));
  }

  function handleCloseDialog() {
    TealiumService.onDeclineQuoteClick('no');
    setShowDialog(false);
  }

  function handleCancelDialog() {
    TealiumService.onDeclineQuoteClick('yes');
    setShowCancellationModel(true);
    setShowDialog(false);
  }

  function handleCloseCancellationModal() {
    setShowCancellationModel(false);
  }

  function handleConfirmCancellation() {
    setShowCancellationModel(false);
    navigate.to(routes.quoteCancelled);
  }

  return (
    <>
      <Modal
        onClickClose={handleCloseDialog}
        onOpen={() => TealiumService.onDeclineQuoteView()}
        show={showDialog}
        type='dialog'
      >
        <>
          <img
            src={QuestionMarkCircle}
            alt='question-mark'
            className='dialog-icon'
          />
          <p className='dialog-heading'>
            Are you sure you want to cancel your quote?
          </p>
          <section className='dialog-button-group'>
            <Button onClick={handleCloseDialog} secondary>
              No, don&apos;t cancel
            </Button>
            <Button onClick={handleCancelDialog} primary>
              Yes, cancel
            </Button>
          </section>
        </>
      </Modal>
      <CancellationReasons
        handleClose={handleCloseCancellationModal}
        handleConfirm={handleConfirmCancellation}
        show={showCancellationModal}
      />

      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={() => setShowDialog(true)}
        hideBack
      />
      <main className='main-content'>
        <h1 className='heading-1'>Here&apos;s your quote</h1>
        <p className='paragraph-1'>
          {productDetails && productDetails.coverType === journeys.family
            ? 'Monthly premium to cover you and your family members'
            : 'Monthly premium to cover your life only'}
        </p>
        <QuoteCard
          product={productDetails ?? {}}
          personal={personalDetails}
          payment={paymentDetails}
          family={familyDetails}
          selectedAddOns={
            productDetails?.addOns || { funeral: {}, dataReward: {} }
          }
          defaultAddOns={
            productDetails?.addOns || { funeral: {}, dataReward: {} }
          }
          onClickEdit={handleEditQuote}
        />
        <section className='add-ons-title-container'>
          <p>
            Choose your add-ons <span>(Optional)</span>
          </p>
        </section>
        <section className='add-ons-container'>
          <AddOnCard
            type='dataReward'
            heading='VodaPay Data Reward'
            badgeText='New!'
            disabled={
              !qualifiesForDataReward ||
              !productDetails.addOns?.dataReward?.fromPremium
            }
            amount={productDetails?.addOns?.dataReward?.cost}
            fromPremium={productDetails?.addOns?.dataReward?.fromPremium}
            benefits={dataRewardBenefits}
            onToggleSwitch={toggleAddOn}
            defaultActive={productDetails?.addOns?.dataReward?.state || false}
          />
        </section>
        <TermsAndConditions>
          <p className='main-text'>
            By selecting &apos;Accept quote&apos; you agree to the{' '}
            <a href={termsAndConditionsUrl} rel='noreferrer' target='_blank'>
              Terms and Conditions
            </a>
            and understand that applications for waiting period waivers will only be considered within 30 days of the policy start date.
          </p>
          <p>
            Please note: Cover starts on commencement date, provided that your
            first premium has been paid. No waiting period applies on accidental
            death. A 6-month waiting period applies to death as a result of
            natural causes. Death from suicide is not covered for the first 12
            months of cover.
          </p>
        </TermsAndConditions>
      </main>
      <NavigationFooter
        onBack={() => setShowDialog(true)}
        onNext={handleNext}
        nextEnabled
        nextButtonLabel='Accept quote'
        backButtonLabel='Decline'
      />
    </>
  );
};

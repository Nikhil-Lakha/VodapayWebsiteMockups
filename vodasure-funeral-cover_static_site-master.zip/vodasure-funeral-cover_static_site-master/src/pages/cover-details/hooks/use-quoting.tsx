import { AppContext, CoverContext } from '@/context';
import { useBenefitQualification } from '@/hooks';
import { dynamicQuotes } from '@/services';
import { FamilyMember, Quote, QuoteResponse } from '@/types';
import {
  applicationDefaults,
  calcAge,
  premiumPlanNames,
  queryKeys,
  stringFormat,
  validAge,
} from '@/utils';
import { useCallback, useContext } from 'react';
import { useQuery } from 'react-query';

const defaultQueryConfig = {
  enabled: false,
  refetchOnWindowFocus: false,
  retry: 2,
};

export function useQuoting() {
  const {
    familyDetails,
    personalDetails,
    referralCode,
    productDetails,
    setProductDetails,
    setPremiumOptions,
  } = useContext(AppContext);
  const { formValues } = useContext(CoverContext);
  const { qualifies: qualifiesForDataReward } =
    useBenefitQualification('dataReward');

  const getPayload = ({
    dataReward = qualifiesForDataReward,
    funeral = true,
    coverAmount,
    individualAge = validAge.adult.min,
    spouse = [],
    children = [],
    extended = [],
  }: {
    dataReward?: boolean;
    funeral?: boolean;
    coverAmount: number;
    individualAge?: number;
    spouse?: FamilyMember[];
    children?: FamilyMember[];
    extended?: FamilyMember[];
  }): Quote => ({
    channelId: referralCode ? 'vodacom' : 'online',
    cellphoneNumber: stringFormat.stripWhitespace(
      formValues.cellphoneNumber || personalDetails.cellphoneNumber || ''
    ),
    coverAmount,
    individualAge,
    spouse,
    children,
    extended,
    dataReward,
    funeral,
  });

  const getFamilyMemberQuoteEntry = useCallback(
    (member: FamilyMember[]) =>
      member.reduce((acc: FamilyMember[], value: FamilyMember) => {
        if (value?.dateOfBirth) {
          acc.push({
            coverAmount: Number(
              value?.coverAmount || Number(productDetails?.coverAmount)
            ),
            age: calcAge(value.dateOfBirth),
          });
          return acc;
        }
        return acc;
      }, []),
    [productDetails]
  );

  const handleStartingPremiumResponse =
    (benefit: 'dataReward' | 'funeral') => (data: QuoteResponse) => {
      if (data) {
        const { selectedPremium } = data.result;
        setProductDetails(prev => ({
          ...prev,
          addOns: {
            ...prev.addOns,
            funeral: {
              ...prev.addOns?.funeral,
              ...(benefit === 'funeral' && {
                fromPremium: selectedPremium.vasBenefit.amount,
              }),
            },
            dataReward: {
              ...prev.addOns?.dataReward,
              ...(benefit === 'dataReward' && {
                fromPremium: selectedPremium.dataRewardBenefit?.amount,
              }),
            },
          },
        }));
      }
    };

  const handleQuoteQuery = (data: QuoteResponse) => {
    if (data) {
      const { premiumOptions, selectedPremium } = data.result;
      setProductDetails(prev => ({
        ...prev,
        basePremium: Number(
          premiumOptions.find(
            premium => premium.planName === premiumPlanNames.basic
          )?.amount
        ),
        totalPremium: selectedPremium?.amount || 0,
        addOns: {
          ...prev.addOns,
          funeral: {
            ...prev?.addOns?.funeral,
            cost: selectedPremium.vasBenefit.amount,
          },
          dataReward: {
            ...prev.addOns?.dataReward,
            state: prev.addOns?.dataReward.state && qualifiesForDataReward,
            cost: selectedPremium?.dataRewardBenefit?.amount,
          },
        },
      }));
      setPremiumOptions(premiumOptions);
    }
    return data;
  };

  const dataRewardStartingPremiumRequest = useQuery(
    queryKeys.startingDataRewardRate,
    () =>
      dynamicQuotes(
        getPayload({
          funeral: false,
          dataReward: true,
          coverAmount:
            applicationDefaults.benefitRequirements.dataReward.minCoverAmount,
        })
      ),
    {
      ...defaultQueryConfig,
      onSuccess: handleStartingPremiumResponse('dataReward'),
    }
  );

  const vasStartingPremiumRequest = useQuery(
    queryKeys.startingVasRate,
    () =>
      dynamicQuotes(
        getPayload({
          funeral: true,
          dataReward: false,
          coverAmount: Number(applicationDefaults.coverAmounts[0].value),
        })
      ),
    {
      ...defaultQueryConfig,
      onSuccess: handleStartingPremiumResponse('funeral'),
    }
  );

  const individualQuoteRequest = useQuery(
    [queryKeys.individualQuote, qualifiesForDataReward],
    () =>
      dynamicQuotes(
        getPayload({
          coverAmount: Number(productDetails?.coverAmount),
          individualAge: calcAge(
            formValues.dateOfBirth || personalDetails.dateOfBirth || ''
          ),
        })
      ),
    {
      ...defaultQueryConfig,
      onSuccess: handleQuoteQuery,
    }
  );

  const familyQuoteRequest = useQuery(
    [queryKeys.familyQuote, qualifiesForDataReward],
    () =>
      dynamicQuotes(
        getPayload({
          coverAmount: Number(productDetails?.coverAmount),
          individualAge: calcAge(
            formValues.dateOfBirth || personalDetails.dateOfBirth || ''
          ),
          spouse: getFamilyMemberQuoteEntry(familyDetails?.spouse),
          children: getFamilyMemberQuoteEntry(familyDetails?.child),
          extended: getFamilyMemberQuoteEntry(familyDetails?.extended),
        })
      ),
    {
      ...defaultQueryConfig,
      onSuccess: handleQuoteQuery,
    }
  );

  return {
    dataRewardStartingPremiumRequest,
    vasStartingPremiumRequest,
    individualQuoteRequest,
    familyQuoteRequest,
  };
}

/* eslint-disable complexity */
import React, { useContext, useEffect, useState } from 'react';
import {
  QueryObserverResult,
  useQuery,
} from 'react-query';
import { useLocation } from 'react-router-dom';
import { AppContext, CoverContext } from '@/context';
import {
  applicationDefaults,
  queryKeys,
  calcAge,
  journeys,
  stringFormat,
  removeNonNumericCharacters,
} from '@/utils';
import {
  useNavService,
  useJourneyService,
  useErrorHandler,
  useMultiStep,
  useBenefitQualification,
} from '@/hooks';
import { routes } from '@/router';
import {
  TealiumService,
  callMeBack,
  vodacomCustomerCheck,
} from '@/services';
import {
  PersonalDetails,
  ICallMeBackStatus,
  QuoteResponse,
} from '@/types';
import {
  NavigationHeader,
  NavigationFooter,
  AmountSelector,
  Tip,
  Modal,
  LoaderAnimation,
  QuickQuoteStep,
  QuickPersonalStep,
  CallMeBack,
  CallMeBackStatus,
  Notification,
} from '@/components';
import { QRCode, AppStoreBadge, GooglePlayBadge } from '@/assets';
import './cover-details.scss';
import { useQuoting } from './hooks';
import get from 'lodash.get';

interface CallMeResponseData {
  result: {
    name: string;
    status: ICallMeBackStatus;
  };
}

interface VodacomCustomerResponseData {
  result: {
    customerType?: string;
    exceptionMessage?: string;
  };
}

export const CoverDetails = () => {
  const {
    personalDetails,
    setPersonalDetails,
    familyDetails,
    setFamilyDetails,
    productDetails,
    setProductDetails,
    isFamilyJourney,
    setIsVodacomCustomer,
  } = useContext(AppContext);
  const {
    formValues,
    formValid,
    editDetails,
    setEditDetails,
    familyFormValid,
    showQRModal,
    setShowQRModal,
    noFamilyMembers,
    setNoFamilyMembers,
    someFamilyMembers,
    setSomeFamilyMembers,
    addedOneFamilyMember,
  } = useContext(CoverContext);

  const [showCallMeBack, setShowCallMeBack] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  const [callMeBackValues, setCallMeBackValues] = useState<PersonalDetails>({
    firstName: '',
    surname: '',
    cellphoneNumber: '',
  });
  const [callMeBackStatus, setCallMeBackStatus] = useState<ICallMeBackStatus>(
    ICallMeBackStatus.unset
  );
  const { qualifies: qualifiesForDataReward } =
    useBenefitQualification('dataReward');

  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();
  const handleError = useErrorHandler();
  const { next, back, step, currentStepIndex, goTo } = useMultiStep([
    <QuickPersonalStep key={0} />,
    <QuickQuoteStep key={1} />,
  ]);
  const {
    dataRewardStartingPremiumRequest,
    vasStartingPremiumRequest,
    individualQuoteRequest,
    familyQuoteRequest,
  } = useQuoting();
  const location = useLocation();
  const { coverAmounts, playStoreLink, appStoreLink } = applicationDefaults;

  function handleQuoteQuery(result: QueryObserverResult<QuoteResponse>) {
    const { data } = result;
    if (data) {
      if (currentStepIndex === 0) {
        TealiumService.onViewQuote();
        next();
        return;
      }
      if (noFamilyMembers) {
        setNoFamilyMembers(false);
      }
      if (someFamilyMembers) {
        setSomeFamilyMembers(false);
      }
    }
  }

  function handleVodacomCustomerQuery(data: VodacomCustomerResponseData) {
    if (data?.result?.exceptionMessage !== undefined || data instanceof Error) {
      setNotificationMessage(
        'There was a problem checking your Vodacom customer status. Please try again'
      );
      setShowNotification(true);
      setIsVodacomCustomer(false);
    } else {
      const { customerType } = data.result;
      setIsVodacomCustomer(Boolean(customerType));
    }
  }

  function handleCallMeBackQuery(data: CallMeResponseData) {
    if (data && data.result?.status) {
      setCallMeBackStatus(data.result.status);
      setShowCallMeBack(false);
      return;
    }
    handleError(new Error('genericError'));
  }

  const callMeBackRequest = useQuery(
    queryKeys.callMeBack,
    () =>
      callMeBack({
        firstName: callMeBackValues.firstName || '',
        lastName: callMeBackValues.surname || '',
        phoneNumber: stringFormat.stripWhitespace(
          callMeBackValues.cellphoneNumber || ''
        ),
      }),
    {
      refetchOnWindowFocus: false,
      enabled: false,
      retry: false,
      onSuccess: handleCallMeBackQuery,
    }
  );

  const vodacomCustomerQuery = useQuery(
    queryKeys.vodacomCustomerCheck,
    () =>
      vodacomCustomerCheck(
        removeNonNumericCharacters(
          stringFormat.stripWhitespace(
            formValues?.cellphoneNumber || personalDetails.cellphoneNumber || ''
          )
        )
      ),
    {
      refetchOnWindowFocus: false,
      enabled: false,
      retry: false,
      onError: handleVodacomCustomerQuery,
      onSuccess: handleVodacomCustomerQuery,
    }
  );

  if (
    [
      callMeBackRequest,
      familyQuoteRequest,
      individualQuoteRequest,
      vasStartingPremiumRequest,
      dataRewardStartingPremiumRequest,
    ].some(({ isError: error }) => error)
  ) {
    handleError(new Error('technicalError'));
  }

  useEffect(() => {
    TealiumService.onLandingStart(get(location, 'state.isReferral', false) ? 'retail partner' : 'consumer');
  }, []);

  useEffect(() => {
    switch (callMeBackStatus) {
      case ICallMeBackStatus.accepted:
        TealiumService.onCallMeBackSuccess();
        break;
      case ICallMeBackStatus.rejected:
        TealiumService.onCallMeBackFailed();
        break;
      default:
        break;
    }
  }, [callMeBackStatus]);

  useEffect(() => {
    if (individualQuoteRequest.isError) {
      handleError(new Error('genericError'));
    }
  }, [
    handleError,
    vasStartingPremiumRequest.isError,
    dataRewardStartingPremiumRequest.isError,
    individualQuoteRequest.isError,
  ]);

  useEffect(() => {
    if (editDetails) {
      back();
    }
  }, [back, editDetails]);

  useEffect(() => {
    if (currentStepIndex === 1 && familyFormValid && isFamilyJourney) {
      familyQuoteRequest.refetch({ throwOnError: true }).then(handleQuoteQuery);
    }
  }, [currentStepIndex, familyFormValid, familyDetails]);

  useEffect(() => {
    if (noFamilyMembers) {
      individualQuoteRequest
        .refetch({ throwOnError: true })
        .then(handleQuoteQuery);
    }
  }, [noFamilyMembers, qualifiesForDataReward]);

  useEffect(() => {
    if (someFamilyMembers) {
      familyQuoteRequest.refetch({ throwOnError: true }).then(handleQuoteQuery);
    }
  }, [someFamilyMembers, qualifiesForDataReward]);

  useEffect(() => {
    if (currentStepIndex === 1 && !isFamilyJourney) {
      individualQuoteRequest
        .refetch({ throwOnError: true })
        .then(handleQuoteQuery);
    }

    if (currentStepIndex === 1 && isFamilyJourney) {
      familyQuoteRequest.refetch({ throwOnError: true }).then(handleQuoteQuery);
    }
  }, [productDetails?.coverAmount, qualifiesForDataReward]);

  useEffect(() => {
    if (location.state?.edit) {
      goTo(1);
    }
  }, [location.state?.edit]);

  useEffect(() => {
    if (!isFamilyJourney && currentStepIndex === 1) {
      individualQuoteRequest
        .refetch({ throwOnError: true })
        .then(handleQuoteQuery);
    }
  }, [isFamilyJourney, qualifiesForDataReward]);

  useEffect(() => {
    if (
      location.state?.edit &&
      isFamilyJourney &&
      Object.values(familyDetails).some(elem => elem.length > 0) &&
      familyFormValid
    ) {
      familyQuoteRequest.refetch({ throwOnError: true }).then(handleQuoteQuery);
    }
  }, [isFamilyJourney, location.state?.edit, familyDetails]);

  function handleNext() {
    if (currentStepIndex === 0) {
      Promise.all([
        dataRewardStartingPremiumRequest.refetch(),
        vasStartingPremiumRequest.refetch(),
      ])
        .then(() => vodacomCustomerQuery.refetch())
        .then(() => individualQuoteRequest.refetch())
        .then(handleQuoteQuery);
      setPersonalDetails(prev => ({
        ...prev,
        ...formValues,
        age: calcAge(formValues.dateOfBirth || ''),
        cellphoneNumber: stringFormat.stripWhitespace(
          formValues.cellphoneNumber || ''
        ),
      }));
      setEditDetails(false);
      TealiumService.onGetFreeQuote();
      return;
    }
    if (currentStepIndex === 1) {
      const coverAmountUpdated =
        isFamilyJourney &&
        familyDetails.spouse.length > 0 &&
        familyDetails.spouse[0]?.coverAmount !== productDetails.coverAmount;

      if (isFamilyJourney) {
        TealiumService.onFamilyCoverEnd(productDetails?.coverAmount || 0);
      } else {
        TealiumService.onLandingEnd();
      }

      if (isFamilyJourney) {
        setFamilyDetails(prev => ({
          ...prev,
          ...(coverAmountUpdated && isFamilyJourney
            ? {
                spouse: [
                  {
                    ...prev.spouse[0],
                    coverAmount: `${productDetails.coverAmount}`,
                  },
                ],
              }
            : {}),
        }));
      } else {
        setFamilyDetails({
          spouse: [],
          child: [],
          extended: [],
        });
      }

      setProductDetails(prev => ({
        ...prev,
        coverType: isFamilyJourney ? journeys.family : journeys.individual,
      }));
      navigate.with(routes.quote, { edit: false });
    }
  }

  function handleBack() {
    TealiumService.onCallMeBackStart();
    setShowCallMeBack(true);
  }

  function closeModal() {
    setShowQRModal(false);
  }

  function closeCallMeBack() {
    setShowCallMeBack(false);
  }

  function confirmCallMeBack() {
    TealiumService.onCallMeBackEnd();
    callMeBackRequest.refetch();
  }

  return (
    <>
      <Modal onClickClose={closeModal} show={showQRModal} type='small'>
        <>
          <div className='qr-code-container'>
            <img className='qr-code' src={QRCode} alt='QR Code' />
          </div>
          <h1 className='modal-title'>Get up to 40% off your premiums</h1>
          <p className='modal-text'>
            Scan the QR code and get up to 40% off in premiums when you apply
            for VodaSure Funeral Cover on VodaPay
          </p>
          <section className='app-buttons'>
            <a href={appStoreLink} target='_blank' rel='noreferrer'>
              <img src={AppStoreBadge} alt='Apple App Store' />
            </a>
            <a href={playStoreLink} target='_blank' rel='noreferrer'>
              <img src={GooglePlayBadge} alt='Google Play Store' />
            </a>
          </section>
        </>
      </Modal>
      <Notification
        message={notificationMessage}
        buttonText='Dismiss'
        visible={showNotification}
        setVisible={setShowNotification}
        interval={7000}
        onDismiss={() => setShowNotification(false)}
      />
      <CallMeBack
        handleClose={closeCallMeBack}
        handleConfirm={confirmCallMeBack}
        formValues={setCallMeBackValues}
        loading={callMeBackRequest.isFetching}
        show={showCallMeBack}
      />
      <CallMeBackStatus
        status={callMeBackStatus}
        onClose={() => setCallMeBackStatus(ICallMeBackStatus.unset)}
        show={
          callMeBackStatus === ICallMeBackStatus.rejected ||
          callMeBackStatus === ICallMeBackStatus.accepted
        }
      />
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        hideBack
      />
      <main className='main-content'>
        <h1 className='heading-1'>
          {isFamilyJourney ? 'Me and my family' : 'Just me'}
        </h1>
        <p>
          {isFamilyJourney
            ? 'This plan covers you and your family'
            : 'This plan covers only you'}
        </p>
        <Tip
          text='Age:(Minimum age of 18 - Maximum 74)'
          type='info'
          centerAlign
        />
        <h2 className='heading-2'>How much cover do you need?</h2>
        <AmountSelector
          buttonArray={coverAmounts}
          name='coverAmount'
          initialValues={{ coverAmount: productDetails?.coverAmount }}
        />
        {[
          dataRewardStartingPremiumRequest.isFetching,
          vasStartingPremiumRequest.isFetching,
          vodacomCustomerQuery.isFetching,
          individualQuoteRequest.isFetching,
        ].some(Boolean) && currentStepIndex === 0 ? (
          <div className='loader-content'>
            <LoaderAnimation height={140} width={140} />
          </div>
        ) : (
          productDetails?.coverAmount && step
        )}
      </main>
      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={
          isFamilyJourney && currentStepIndex === 1
            ? familyFormValid && addedOneFamilyMember
            : formValid &&
              !individualQuoteRequest.isFetching &&
              !vodacomCustomerQuery.isFetching
        }
        nextButtonLabel={`${
          location.state?.edit ? 'Update my quote' : 'Get a free quote'
        }`}
        backButtonLabel='Call me back'
      />
    </>
  );
};

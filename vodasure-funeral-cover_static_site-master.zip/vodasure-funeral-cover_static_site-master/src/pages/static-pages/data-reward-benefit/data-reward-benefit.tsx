import React, { useContext, useEffect, useState } from 'react';
import { useBenefitQualification, useNavService } from '@/hooks';
import { AppContext } from '@/context';
import { TealiumService } from '@/services';
import { AddOns } from '@/types';
import { NavigationFooter, Notification } from '@/components';
import { VodaSureFuneralCoverLogo } from '@/assets';
import './data-reward-benefit.scss';

export const DataRewardBenefit = () => {
  const { setProductDetails, productDetails } = useContext(AppContext);
  const { qualifies } = useBenefitQualification('dataReward');
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [addToCart, setAddToCart] = useState<boolean>(
    productDetails.addOns?.dataReward.state || false
  );
  const navigate = useNavService();

  useEffect(() => {
    TealiumService.onAddOnView();
    window.scrollTo(0, 0);
  }, []);

  function handleBack() {
    TealiumService.onAddOnBack('data reward');
    navigate.back();
  }

  function handleNext() {
    TealiumService.onAddOnCart('data reward');
    setProductDetails(prev => ({
      ...prev,
      addOns: {
        ...prev.addOns,
        dataReward: {
          ...prev.addOns?.dataReward,
          state: !prev.addOns?.dataReward.state,
        },
      } as AddOns,
    }));
    setAddToCart(prev => !prev);
    setShowNotification(!addToCart);
  }

  return (
    <>
      <Notification
        message='Data reward benefit has been added to your cart'
        buttonText='Dismiss'
        visible={showNotification}
        setVisible={setShowNotification}
        onDismiss={() => setShowNotification(false)}
      />
      <header className='top-bar'>
        <img
          className='vodasure-logo'
          src={VodaSureFuneralCoverLogo}
          alt='VodaSure'
        />
      </header>

      <main className='content'>
        <h1 className='page-title'>
          VodaPay Data Rewards Terms and Conditions
        </h1>

        <article className='content-section'>
          <p className='sub-heading'>&#47;&#47; Assistance Products:</p>

          <p className='description'>
            VodaPay Data Rewards provide qualifying Vodacom Funeral Cover Policy
            Owners, who have selected the benefit, with discounted data of up to
            1GB per month. In order to qualify for this benefit, the Policy
            Owner must:
          </p>

          <section className='info-list'>
            <ul>
              <li>
                Hold a valid and up to date Vodacom Funeral Cover Policy and be
                covered for at least R20 000 on such a policy
              </li>
              <li>Be an active Vodacom contract or prepaid subscriber</li>
              <li>
                Have an active VodaPay account and must visit the app at least
                once a month
              </li>
              <li>
                Have their Vodacom number as the primary contact number on their
                policy and use the same on the VodaPay App
              </li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='sub-heading'>&#47;&#47; Price Breakdown</p>
          <p className='description'>
            The data applicable per cover amount is as follows:
          </p>
          <section className='info-list'>
            <ul>
              <li>R20 000: 250MB for 14 days at R3.75</li>
              <li>R30 000: 500MB for 14 days at R7.50</li>
              <li>R40 000: 750MB for 14 days at R11.25</li>
              <li>R50 000: 1GB for 14 days at R15.00</li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p>
            Please note that the data rewards will only be allocated to the
            contact number provided on the policy and cannot be exchanged for
            cash.
          </p>
          <p>
            If the data benefit is due to you in any month, it will be
            automatically allocated on the 15th every month. The data will
            expire after 14 days once allocated and any unused data benefit will
            be forfeited.
          </p>
          <p>
            Please visit{' '}
            <a
              target='_blank'
              rel='noreferrer'
              href='https://www.vodacom.co.za/vodacom/terms/competition/funeral-cover-rewards'
            >
              https://www.vodacom.co.za/vodacom/terms/competition/funeral-cover-rewards
            </a>{' '}
            for detailed terms and conditions.
          </p>
        </article>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={qualifies}
        nextButtonLabel={addToCart ? 'Remove from my cart' : 'Add to my cart'}
        backButtonLabel='Back'
      />
    </>
  );
};

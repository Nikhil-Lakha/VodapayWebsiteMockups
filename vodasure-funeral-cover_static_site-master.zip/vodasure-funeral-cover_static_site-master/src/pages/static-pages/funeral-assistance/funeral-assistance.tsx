import React, { useContext, useEffect, useState } from 'react';
import { useNavService } from '@/hooks';
import { AppContext } from '@/context';
import { TealiumService } from '@/services';
import { AddOns } from '@/types';
import { NavigationFooter, Notification } from '@/components';
import { VodaSureFuneralCoverLogo } from '@/assets';
import './funeral-assistance.scss';

export const FuneralAssistance = () => {
  const { setProductDetails, productDetails } = useContext(AppContext);
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [addToCart, setAddToCart] = useState<boolean>(
    productDetails.addOns?.funeral.state || false
  );
  const navigate = useNavService();

  useEffect(() => {
    TealiumService.onAddOnView();
    window.scrollTo(0, 0);
  }, []);

  function handleBack() {
    TealiumService.onAddOnBack('funeral assistance');
    navigate.back();
  }

  function handleNext() {
    TealiumService.onAddOnCart('funeral assistance');
    setProductDetails(prev => ({
      ...prev,
      addOns: {
        ...prev.addOns,
        funeral: {
          ...prev.addOns?.funeral,
          state: !prev.addOns?.funeral.state,
        },
      } as AddOns,
    }));
    setAddToCart(prev => !prev);
    setShowNotification(!addToCart);
  }

  return (
    <>
      <Notification
        message='Funeral assistance benefit has been added to your cart'
        buttonText='Dismiss'
        visible={showNotification}
        setVisible={setShowNotification}
        onDismiss={() => setShowNotification(false)}
      />
      <header className='top-bar'>
        <img
          className='vodasure-logo'
          src={VodaSureFuneralCoverLogo}
          alt='VodaSure'
        />
      </header>

      <main className='content'>
        <h1 className='page-title'>Funeral assistance benefit</h1>

        <article className='content-section'>
          <p className='sub-heading'>
            &#47;&#47; Assistance products: Funeral concierge assistance
          </p>

          <p className='description'>
            To protect your account from fraudsters, DebiCheck lets you
            authorise debit orders electronically before transactions are
            processed. It&apos;s an extra layer of security for your peace of
            mind.
          </p>

          <section className='info-list'>
            <p className='text-grey'>
              The service assists the bereaved family and next-of-kin with the
              facilitation of the burial. It comprises of the following:
            </p>
            <ul>
              <li>Locating of the deceased</li>
              <li>
                Overnight accommodation for the next-of-kin in order to identify
                the body (up to R1500)
              </li>
              <li>
                Repatriation of mortal remains to a place of burial, at no extra
                cost (only in SA)
              </li>
              <li>Referral to a pathologist if an autopsy is required</li>
              <li>Referral to a reputable undertaker</li>
              <li>Assistance with funeral arrangements</li>
              <li>
                Advice on how to apply for death certificate and border-crossing
                documentation
              </li>
              <li>
                Interpretation of legal documentation such as the funeral policy
              </li>
              <li>Referral to counselling services for support and advice</li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='description'>
            Annual limit: 2 cases per policy per annum
          </p>
          <div className='info-list'>
            <ul>
              <li>
                *This service is only available on confirmation of death,
                through death certificate or Affidavit.
              </li>
              <li>
                In addition to the above the below will be added to this
                product:
              </li>
              <li>
                **These services are only available to be redeemed within a 30
                day period from death. Death Certificate / Affidavit will be
                required to redeem these services.
              </li>
            </ul>
          </div>
        </article>

        <article className='content-section'>
          <p className='sub-heading'>
            &#47;&#47; Trauma and bereavement assistance: 24-hour Emergency
            Assistance Helpline
          </p>
          <p className='text-grey'>
            For the deceased&apos;s family, we will provide the beneficiary with
            counselling by trained medical professionals. This is a 24-hour
            emergency assistance helpline that:
          </p>
          <section className='info-list'>
            <ul>
              <li>Offers referrals for psychiatric consultations.</li>
              <li>
                10 trips per annum related to the policy within the metropolitan
                areas, to assist with trauma visits and/or funeral arrangements.
              </li>
              <li>
                6 x 60 minute trauma and bereavement counselling sessions can be
                used for the family(for individuals or groups).
              </li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='description'>
            Annual limit: 10 taxi service trips (R450.00 per trip, either with
            our internal drivers or uber vouchers) and 6 x 60min trauma and
            bereavement counselling
          </p>
          <p>
            *This program can only be made use of related to a death that has
            happened under the policy and is valid for up to 12 months after the
            death.
          </p>
        </article>

        <article className='content-section'>
          <p className='sub-heading'>
            &#47;&#47; Bereavement box: This box will include any of the above
            as well as the below mentioned.
          </p>
          <p className='text-grey'>
            A box will be delivered to the immediate family member of the
            deceased which includes the following:
          </p>
          <section className='info-list'>
            <ul>
              <li>
                R300 airtime to be sent to the cellphone number of one specified
                next of kin
              </li>
              <li>
                R500 to be loaded onto Mastercard debit card that can be used at
                any store where Mastercard is accepted, alternatively, this can
                be sent as a Cashsend to their phones.
              </li>
              <li>
                FAQ&apos;s sheet and pamphlets to assist with funeral
                arrangements, these can also be sent via email.
              </li>
              <li>Government forms to complete for death certificate.</li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='description'>Annual limit: 1box</p>
          <p>
            **These services are only available to be redeemed within a 30 day
            period from death. Death Certificate / Affidavit will be required to
            redeem these services.
          </p>
        </article>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled
        nextButtonLabel={addToCart ? 'Remove from my cart' : 'Add to my cart'}
        backButtonLabel='Back'
      />
    </>
  );
};

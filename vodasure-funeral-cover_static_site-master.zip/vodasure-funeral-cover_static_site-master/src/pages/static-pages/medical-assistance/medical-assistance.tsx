import React, { useContext, useEffect, useState } from 'react';
import { useNavService } from '@/hooks';
import { AppContext } from '@/context';
import { TealiumService } from '@/services';
import { AddOns } from '@/types';
import { NavigationFooter, Notification } from '@/components';
import { VodaSureFuneralCoverLogo } from '@/assets';
import './medical-assistance.scss';

export const MedicalAssistance = () => {
  const { setProductDetails, productDetails } = useContext(AppContext);
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [addToCart, setAddToCart] = useState<boolean>(
    productDetails.addOns?.medical?.state || false
  );
  const navigate = useNavService();

  useEffect(() => {
    TealiumService.onAddOnView();
    window.scrollTo(0, 0);
  }, []);

  function handleBack() {
    TealiumService.onAddOnBack('medi');
    navigate.back();
  }

  function handleNext() {
    TealiumService.onAddOnCart('medi');
    setProductDetails(prev => ({
      ...prev,
      addOns: {
        ...prev.addOns,
        medical: {
          ...prev.addOns?.medical,
          state: !prev.addOns?.medical?.state,
        },
      } as AddOns,
    }));
    setAddToCart(prev => !prev);
    setShowNotification(!addToCart);
  }

  return (
    <>
      <Notification
        message='Medi-Assist benefit has been added to your cart'
        buttonText='Dismiss'
        visible={showNotification}
        setVisible={setShowNotification}
        onDismiss={() => setShowNotification(false)}
      />
      <header className='top-bar'>
        <img
          className='vodasure-logo'
          src={VodaSureFuneralCoverLogo}
          alt='VodaSure'
        />
      </header>

      <main className='content'>
        <h1 className='page-title'>VodaSure Medi-Assist</h1>

        <article className='content-section'>
          <p className='sub-heading'>&#47;&#47; Assistance products: General</p>

          <p className='description'>
            The following is a summary of the Medi Assist Benefits. For full
            terms and conditions you can go to{' '}
            <a
              target='_blank'
              rel='noreferrer'
              href='https://www.vodacom.co.za/vodacom/terms/vodasure-medi-assist'
            >
              https://www.vodacom.co.za/vodacom/terms/vodasure-medi-assist.
            </a>
          </p>

          <section className='info-list'>
            <p className='text-grey'>24 hour Medical Advice</p>

            <ul>
              <li>
                Our Medical Team will guide you through your emergency while
                help is on the way.
              </li>
              <li>Get answers to health-related questions.</li>
              <li>
                Referrals to crisis lines in the case of family abuse, rape,
                bereavement, suicide or poisoning.
              </li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='description'>Medical transportation</p>
          <section className='info-list'>
            <ul>
              <li>
                In the even to a medical emergency, Yebo Doctor will co-ordinate
                the most appropriate method of emergency medical transportation.
              </li>
            </ul>
          </section>
        </article>

        <article className='content-section'>
          <p className='description'>Tele-Medicine nurse consultation</p>
          <p className='text-grey'>
            24 hour Corona Medical line, roviding advice on how to treat
            symptoms with home care and referral to an appropriate medical
            facility.
          </p>
          <p>Advice lines</p>
          <section className='info-list'>
            <ul>
              <li>Pregnancy</li>
              <li>Mum and Baby child care information</li>
              <li>Men&apos;s and Women&apos;s health</li>
              <li>Sex and Drug information</li>
              <li>Advice on chronic diseases and medication</li>
              <li>HIV</li>
            </ul>
          </section>
        </article>
        <article className='content-section'>
          <p className='text-grey'>
            Discounts on doctors, dentists and optometrists get access to
            network of doctors and cell Centre will arrange appointments for you
          </p>
          <p className='text-grey'>
            USSD Medical Panic Button one press and we will know where and who
            you are
          </p>
        </article>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled
        nextButtonLabel={addToCart ? 'Remove from my cart' : 'Add to my cart'}
        backButtonLabel='Back'
      />
    </>
  );
};

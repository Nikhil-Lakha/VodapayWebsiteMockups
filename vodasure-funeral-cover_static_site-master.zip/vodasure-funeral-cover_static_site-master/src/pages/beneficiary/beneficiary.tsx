import React, { useState, useContext, useEffect } from 'react';
import get from 'lodash.get';
import { AppContext } from '@/context';
import { useNavService, useJourneyService } from '@/hooks';
import { calcAge, stringFormat } from '@/utils';
import { BeneficiaryDetails, PaymentMethods } from '@/types';
import { BeneficiaryDetailsForm } from '@/forms';
import { routes } from '@/router';
import { TealiumService } from '@/services';
import { NavigationHeader, NavigationFooter, Notification } from '@/components';
import './beneficiary.scss';

export const Beneficiary = () => {
  const {
    beneficiaryDetails,
    setBeneficiaryDetails,
    familyDetails,
    isFamilyJourney,
    isAddToBill,
    setPaymentDetails,
  } = useContext(AppContext);
  const [formValid, setFormValid] = useState(false);
  const [formValues, setFormValues] = useState<BeneficiaryDetails>({});
  const [isOtherBeneficiary, setIsOtherBeneficiary] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [formTouched, setFormTouched] = useState<boolean>(false);
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();

  useEffect(() => {
    if (isFamilyJourney) {
      TealiumService.onFamilyBeneficiaryStart();
    } else {
      TealiumService.onBeneficiaryStart();
    }

    setShowNotification(true);
  }, []);

  useEffect(() => {
    if (formValues.selectBeneficiary === 'Other') {
      setIsOtherBeneficiary(true);
      TealiumService.onAddOtherFamilyBeneficiaryStart();
    }
  }, [formValues.selectBeneficiary]);

  useEffect(() => {
    if (!formTouched && Object.values(formValues).length > 0) {
      setFormTouched(
        Object.values(formValues).some(value => value && value.length > 0)
      );
    }
  }, [formTouched, formValues]);

  function handleNext() {
    if (isFamilyJourney) {
      if (isOtherBeneficiary) {
        TealiumService.onAddOtherFamilyBeneficiaryEnd();
      } else {
        TealiumService.onFamilyBeneficiaryEnd();
      }

      const selectedBeneficiary = formValues?.selectBeneficiary || '';
      const data = get(familyDetails, selectedBeneficiary);
      setBeneficiaryDetails(prev => ({
        ...prev,
        ...data,
        ...formValues,
        age: calcAge(data?.dateOfBirth || formValues.dateOfBirth),
        selectBeneficiary: formValues.selectBeneficiary,
        cellphoneNumber: stringFormat.stripWhitespace(
          formValues.cellphoneNumber || ''
        ),
      }));
    }

    if (!isFamilyJourney) {
      TealiumService.onBeneficiaryEnd('next');
      setBeneficiaryDetails(prev => ({
        ...prev,
        ...formValues,
        age: calcAge(formValues?.dateOfBirth || ''),
        cellphoneNumber: stringFormat.stripWhitespace(
          formValues?.cellphoneNumber || ''
        ),
      }));
    }

    if (!isAddToBill) {
      setPaymentDetails(prevData => ({
        ...prevData,
        paymentMethod: PaymentMethods.debitOrder,
      }));
      navigate.to(routes.debitOrderDetails);
      return;
    }
    navigate.to(routes.paymentDetails);
  }

  function handleBack() {
    TealiumService.onBeneficiaryEnd('back');
    navigate.back();
  }

  function addBeneficiaryLater() {
    setShowNotification(false);
    if (isFamilyJourney) {
      TealiumService.onNoFamilyBeneficiaryAction('maybe later');
    }
    if (!isAddToBill) {
      setPaymentDetails(prevData => ({
        ...prevData,
        paymentMethod: PaymentMethods.debitOrder,
      }));
      navigate.to(routes.debitOrderDetails);
      return;
    }
    navigate.to(routes.paymentDetails);
  }

  const initialValues = {
    selectBeneficiary: beneficiaryDetails.selectBeneficiary || '',
    firstName: beneficiaryDetails.firstName || '',
    surname: beneficiaryDetails.surname || '',
    cellphoneNumber: beneficiaryDetails.cellphoneNumber || '',
    dateOfBirth: beneficiaryDetails.dateOfBirth || '',
    relationship: beneficiaryDetails.relationship || undefined,
    gender: beneficiaryDetails.gender || undefined,
  };

  return (
    <>
      <Notification
        message='Adding a beneficiary to your funeral cover will help us pay the proceeds to your deceased estate promptly when you pass on.'
        buttonText='Add beneficiary later'
        visible={showNotification && !formTouched}
        onDismiss={addBeneficiaryLater}
      />
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={handleBack}
      />
      <main className='main-content'>
        <h1 className='heading-1'>Add a beneficiary</h1>
        <p className='paragraph-1 w60'>
          You must add a beneficiary over the age of 18 to receive the funds in
          the event of your passing.
        </p>
        <section className='beneficiary-form'>
          <BeneficiaryDetailsForm
            formValid={setFormValid}
            formValues={setFormValues}
            initialValues={initialValues}
            isFamilyCover={isFamilyJourney}
          />
        </section>
      </main>

      <NavigationFooter
        onBack={handleBack}
        onNext={handleNext}
        nextEnabled={formValid}
        nextButtonLabel={`${
          !(isOtherBeneficiary || !isFamilyJourney)
            ? 'Select and continue'
            : 'Next'
        }`}
        backButtonLabel='Back'
      />
    </>
  );
};

import { NavigationFooter, NavigationHeader } from '@/components';
import { useNavService } from '@/hooks';
import { AppContext } from '@/context';
import { routes } from '@/router';
import { ReferralCode as ReferralCodeType } from '@/types';
import React, { useContext, useState, useEffect } from 'react';
import './retail-partners.scss';
import { ReferralCodeForm } from '@/forms';
import { TealiumService } from '@/services';

export const RetailPartners = () => {
  const { referralCode, setReferralCode } = useContext(AppContext);
  const navigate = useNavService();

  const [formValid, setFormValid] = useState(false);
  const [formValues, setFormValues] = useState<ReferralCodeType>({});

  function handleNext() {
    TealiumService.onReferralCodeSubmit();
    setReferralCode(formValues?.referralCode || '');
    navigate.with(routes.coverDetails, { isReferral: true });
  }

  const initialValues = {
    referralCode: referralCode || '',
  };

  useEffect(() => {
    TealiumService.onReferralPage();
  }, []);

  return (
    <>
      <NavigationHeader hideBack />

      <main className='main-content'>
        <section className='wrapper-content'>
          <h3 className='heading-3'>Please enter your referral code</h3>
          <p className='paragraph-2'>
            It is important that you enter the correct referral code. This
            can&apos;t be changed once the funeral cover application is
            successfully submitted.
          </p>
          <section className='referral-code-form'>
            <ReferralCodeForm
              validForm={setFormValid}
              formValues={setFormValues}
              initialValues={initialValues}
            />
          </section>
        </section>
      </main>
      <NavigationFooter
        hideBack
        onNext={handleNext}
        nextEnabled={formValid}
        nextButtonLabel='Submit'
      />
    </>
  );
};

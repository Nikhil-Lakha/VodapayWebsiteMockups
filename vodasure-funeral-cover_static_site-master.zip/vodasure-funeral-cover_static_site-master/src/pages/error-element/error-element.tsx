import React from 'react';
import { useRouteError } from 'react-router-dom';
import { errorContent } from '@/utils';
import { Error } from '@/components';

export const ErrorElement = () => {
  const error = useRouteError() as Error;

  if (error.message) {
    const { title, description, primaryButton, secondaryButton, onMount } =
      errorContent[error.message] || errorContent.technicalError;
    return (
      <Error
        title={title}
        description={description}
        primaryButton={primaryButton}
        secondaryButton={secondaryButton}
        errorType={error.message}
        onMount={onMount}
      />
    );
  }
  const { title, description, primaryButton, secondaryButton, onMount } =
    errorContent.technicalError;
  return (
    <Error
      title={title}
      description={description}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      errorType='genericError'
      onMount={onMount}
    />
  );
};

import React, { useContext, useEffect, useState } from 'react';
import { useNavService, useJourneyService } from '@/hooks';
import { AppContext } from '@/context';
import { routes } from '@/router';
import { FamilyDetails as FamilyDetailsType } from '@/types';
import { calcAge } from '@/utils';
import { TealiumService } from '@/services';
import { FamilyDetailsForm } from '@/forms';
import { NavigationHeader, NavigationFooter } from '@/components';

export const FamilyDetails = () => {
  const { familyDetails, setFamilyDetails } = useContext(AppContext);
  const [validForm, setValidForm] = useState<boolean>(false);
  const [formValues, setFormValues] = useState<FamilyDetailsType>({
    spouse: [],
    child: [],
    extended: [],
  });
  const [addedFamilyDetails, setAddedFamilyDetails] = useState(false);
  const { currentStep, journeySteps } = useJourneyService();
  const navigate = useNavService();

  const initialValues = {
    spouse: familyDetails.spouse || [],
    child: familyDetails.child || [],
    extended: familyDetails.extended || [],
  };

  useEffect(() => {
    TealiumService.onAboutYourFamilyStart();
  }, []);

  function handleNext() {
    const data = {
      spouse: formValues.spouse.map(spouse => ({
        ...spouse,
        age: calcAge(spouse?.dateOfBirth || ''),
      })),
      child: formValues.child.map(child => ({
        ...child,
        age: calcAge(child?.dateOfBirth || ''),
      })),
      extended: formValues.extended.map(extended => ({
        ...extended,
        age: calcAge(extended?.dateOfBirth || ''),
      })),
    };
    setFamilyDetails(prev => ({ ...prev, ...data }));
    TealiumService.onAboutYourFamilyEnd();
    navigate.to(routes.beneficiary);
  }

  return (
    <>
      <NavigationHeader
        steps={journeySteps}
        currentStep={currentStep}
        onBack={() => navigate.back()}
      />
      <main className='main-content'>
        <h1 className='heading-1'>About your family</h1>
        <p className='paragraph-1'>
          We need a little more information so that we can add your family to
          your policy
        </p>
        <FamilyDetailsForm
          initialValues={initialValues}
          validForm={setValidForm}
          formValues={setFormValues}
          addedValues={setAddedFamilyDetails}
        />
      </main>
      <NavigationFooter
        onBack={() => navigate.back()}
        onNext={handleNext}
        nextEnabled={validForm && addedFamilyDetails}
        nextButtonLabel='Next'
        backButtonLabel='Back'
      />
    </>
  );
};

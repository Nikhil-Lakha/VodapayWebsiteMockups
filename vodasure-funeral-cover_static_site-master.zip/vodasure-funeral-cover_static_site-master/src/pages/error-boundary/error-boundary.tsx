import React, { ErrorInfo, ReactNode } from 'react';
import { Error } from '@/components';
import { errorContent } from '@/utils';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorType: string;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, errorType: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, errorType: error?.message };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // eslint-disable-next-line no-restricted-syntax
    console.error(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      const { title, description, primaryButton, secondaryButton, onMount } =
        errorContent[this.state?.errorType] || errorContent.technicalError;
      return (
        <Error
          title={title}
          description={description}
          primaryButton={primaryButton}
          secondaryButton={secondaryButton}
          errorType={this.state.errorType}
          onMount={onMount}
        />
      );
    }

    return this.props.children;
  }
}

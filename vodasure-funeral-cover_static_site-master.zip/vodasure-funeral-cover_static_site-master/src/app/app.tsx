import React, { useMemo } from 'react';
import { Router } from '@/router';
import { QueryClientProvider, QueryClient } from 'react-query';
import { Cache } from '@/services';

const queryClient = new QueryClient();

export const App = () => {
  useMemo(() => {
    const debugKey = new URLSearchParams(window.location.search).get(
      'debugKey'
    );

    if (debugKey) {
      Cache.save('debugKey', debugKey);
    }
  }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
    </QueryClientProvider>
  );
};

import { Environment } from '@/utils';

export class Api {
  static getUrl(callMeBack?: boolean): string {
    if (callMeBack) {
      return Environment.current?.callMeBackApi || '';
    }
    let baseUrl =
      (Environment.current?.apiHost || '') +
      (Environment.current?.apiBase || '');
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    return baseUrl;
  }

  static get(url: string, options: RequestInit) {
    const _url = Api.getUrl() + url;
    options.method = 'GET';

    return Api.request(_url, options);
  }

  static post(url: string, options: RequestInit, callMeBack?: boolean) {
    const _url = Api.getUrl(callMeBack) + url;
    options.method = 'POST';

    return Api.request(_url, options);
  }

  static request(url: string, options: RequestInit) {
    return fetch(url, options).then(res => {
      if (res.status === 400) {
        return res.json();
      }
      if (!res.ok) {
        throw new Error('Something happened when making a request');
      }
      return res.json();
    });
  }
}

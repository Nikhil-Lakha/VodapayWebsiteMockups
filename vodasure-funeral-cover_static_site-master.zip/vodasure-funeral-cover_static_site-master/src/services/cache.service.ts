export class Cache {
  static save = (key: string, data: unknown) => {
    window.sessionStorage.setItem(key, JSON.stringify(data));
  };

  static fetch = (key: string) => {
    const data = window.sessionStorage.getItem(key);
    if (!data) {
      return undefined;
    }
    return JSON.parse(data);
  };

  static clear = () => {
    window.sessionStorage.clear();
  };
}

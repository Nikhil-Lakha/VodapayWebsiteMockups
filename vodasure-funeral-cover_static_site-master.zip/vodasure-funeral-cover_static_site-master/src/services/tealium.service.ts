import { View, Link } from '@/types';
import { objTealium } from '@/utils';

export class TealiumService {
  static landingPageName =
    'vodasure: funeral cover: cover amount: landing page';

  static callMeBackPageName = 'vodasure: funeral cover: call me back';

  static quotePageName = 'vodasure: funeral cover: your quote';

  static personalPageName = 'vodasure: funeral cover: your personal details';

  static beneficiaryPageName = 'vodasure: funeral cover: add a beneficiary';

  static paymentMethodPageName = 'vodasure: funeral cover: payment';

  static debitOrderPageName = 'vodasure: funeral cover: payment details';

  static paymentSummaryPageName = 'vodasure: funeral cover: payment summary';

  static confirmationPageName = 'vodasure: funeral cover: payment success';

  /** FAMILY FUNERAL COVER PAGE NAMES */

  static familyMembersLandingPage =
    'vodasure: funeral cover: cover amount: family funeral';

  static familyPersonalDetailsPage =
    'vodasure: funeral cover: personal details: about your family';

  static familyBeneficiaryPage =
    'vodasure: funeral cover: personal details: about your family: beneficiary';

  static errorPage = 'vodasure: funeral cover: error page';

  static referrelPage = 'vodasure: funeral cover: retail partners';

  static attempt = (func: () => void) => {
    try {
      func();
    } catch (err) {
      // eslint-disable-next-line no-restricted-syntax
      console.error(err);
    }
  };

  static sendViewToTealium(obj: View) {
    this.attempt(() => {
      objTealium.view(obj);
    });
  }

  static sendLinkToTealium(obj: Link) {
    this.attempt(() => {
      objTealium.link(obj);
    });
  }

  /**
   *
   * Page name: landing page
   * Page url: /cover-amount
   *
   * */
  static onLandingStart(visitorType: 'retail partner'|'consumer') {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.landingPageName,
      service_application_name: 'vodasure: funeral cover: cover amount',
      service_application_type: 'query',
      visitor_type: visitorType
    });
  }

  static onAmountSelected(amount: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_form_event: 'start',
      page_name: this.landingPageName,
      page_tool_name: `${this.landingPageName}: ${amount}`,
      page_form_name: 'few personal details',
    });
  }

  static onGetFreeQuote() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.landingPageName,
      page_tool_name: `${this.landingPageName}: get free quote`,
    });
  }

  static onViewQuote() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: `${this.landingPageName}: extra cover`,
    });
  }

  static onQuoteInteract() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.landingPageName}: extra cover`,
      page_tool_name: `${this.landingPageName}: scan qr code`,
    });
  }

  static onLandingEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'finish',
      page_name: `${this.landingPageName}: extra cover`,
      page_tool_name: `${this.landingPageName}: continue`,
      service_application_name: 'vodasure: funeral cover: cover amount',
      service_application_type: 'query',
    });
  }

  /**
   *
   * Page name: Call Me back
   * Page url: N/A
   *
   * */

  static onCallMeBackStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'start',
      page_name: this.callMeBackPageName,
      page_form_name: 'call me back',
    });
  }

  static onCallMeBackEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.callMeBackPageName,
      page_tool_name: 'vodasure: funeral cover: call me back: submit',
    });
  }

  static onCallMeBackSuccess() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'success',
      page_name: `${this.callMeBackPageName}: success`,
      page_form_name: 'call me back',
    });
  }

  static onCallMeBackFailed() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.callMeBackPageName}: failed`,
    });
  }

  /**
   *
   * Page name: Quote
   * Page url: /quote
   *
   * */
  static onQuoteStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.quotePageName,
      service_application_event: 'start',
      service_application_name: 'vodasure: funeral cover: quote',
      service_application_type: 'query',
    });
  }

  static onQuoteEdit() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.quotePageName,
      page_tool_name: `${this.quotePageName}: edit`,
    });
  }

  static onAddOns(type: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.quotePageName,
      page_tool_name: `${this.quotePageName}: ${type} assistance benefits`,
    });
  }

  static onAddOnView() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.quotePageName}: assistance benefits`,
    });
  }

  static onAddOnBack(benefit: 'funeral assistance' | 'medi' | 'data reward') {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.quotePageName}: assistance benefits`,
      page_tool_name: `${this.quotePageName}: assistance benefits: back`,
      product_option: benefit
    });
  }

  static onAddOnCart(benefit: 'funeral assistance' | 'medi' | 'data reward') {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.quotePageName}: assistance benefits`,
      page_tool_name: `${this.quotePageName}: add to cart`,
      product_option: benefit
    });
  }

  static onQuoteAccept(benefits: string[]) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'finish',
      page_name: `${this.quotePageName}`,
      page_tool_name: `${this.quotePageName}: accept quote`,
      service_application_name: 'vodasure: funeral cover: quote',
      service_application_type: 'query',
      product_option: benefits.join(' | ')
    });
  }

  static onDeclineQuoteView() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.quotePageName}: cancel quote`,
    });
  }

  static onDeclineQuoteClick(option: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.quotePageName}: cancel quote`,
      page_tool_name: `${this.quotePageName}: cancel quote: ${option}`,
    });
  }

  static onDeclineQuoteReasons() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.quotePageName}: cancel quote: reasons`,
    });
  }

  static onDeclineQuoteReasonsClick(
    option: 'no' | 'confirm',
    cancelReason?: string
  ) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.quotePageName}: cancel quote: reasons`,
      page_tool_name: `${this.quotePageName}: cancel quote: reasons: ${option}`,
      ...(cancelReason && { filter_query: cancelReason }),
    });
  }

  static onApplicationCancelled() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.quotePageName}: cancel quote: confirmed`,
    });
  }

  /**
   *
   * Page name: Personal details
   * Page url: /personal-details
   *
   * */
  static onPersonalStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.personalPageName,
      service_application_event: 'start',
      service_application_name: 'vodasure: funeral cover: personal details',
      service_application_type: 'query',
      page_form_name: 'personal details',
    });
  }

  static onPersonalEnd(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'finish',
      page_name: this.personalPageName,
      page_tool_name: `${this.personalPageName}: ${action}`,
      service_application_type: 'query',
    });
  }

  /**
   *
   * Page name: Beneficiary Details
   * Page url: /beneficiary
   *
   * */
  static onBeneficiaryStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.beneficiaryPageName,
      service_application_event: 'start',
      service_application_name: 'vodasure: funeral cover: add a beneficiary',
      service_application_type: 'query',
      page_form_name: 'add a beneficiary',
    });
  }

  static onBeneficiaryEnd(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'finish',
      page_name: this.beneficiaryPageName,
      page_tool_name: `${this.beneficiaryPageName}: ${action}`,
      service_application_name: 'vodasure: funeral cover: add a beneficiary',
      service_application_type: 'query',
    });
  }

  static onNoBeneficiaryStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.beneficiaryPageName}: no beneficiary`,
    });
  }

  static onNoBeneficiaryAction(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.beneficiaryPageName}: no beneficiary`,
      page_tool_name: `${this.beneficiaryPageName}: no beneficiary: ${action}`,
    });
  }

  /**
   *
   * Page name: Payment method
   * Page url: /payment-details
   *
   * */
  static onPaymentMethodStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.paymentMethodPageName,
      service_application_event: 'finish',
      service_application_name: 'vodasure: funeral cover: payment',
      service_application_type: 'query',
    });
  }

  static onPaymentMethodContinue(option: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'start',
      page_name: this.paymentMethodPageName,
      page_tool_name: `${this.paymentMethodPageName}: ${option}: continue`,
    });
  }

  /**
   *
   * Page name: Debit order details
   * Page url: /payment/debit-order
   *
   * */
  static onDebitOrderStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.debitOrderPageName,
      page_form_name: 'payment details',
    });
  }

  static onDebitOrderEnd(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      service_application_event: 'finish',
      page_name: this.debitOrderPageName,
      page_tool_name: `${this.debitOrderPageName}: ${action}`,
      service_application_name: 'vodasure: funeral cover: payment',
      service_application_type: 'query',
    });
  }

  /**
   *
   * Page name: Payment summary
   * Page url: /payment/summary
   *
   * */
  static onPaymentSummaryStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.paymentSummaryPageName,
    });
  }

  static onPaymentSummaryEnd(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.paymentSummaryPageName,
      page_tool_name: `${this.paymentSummaryPageName}: ${action}`,
    });
  }

  /**
   *
   * Page name: Confirmation
   * Page url: /confirmation
   *
   * */
  static onConfirmationStart() {
    this.sendViewToTealium({
      event_name: 'view',
      page_name: this.confirmationPageName,
    });
  }

  /**
   * FAMILY FUNERAL COVER
   */

  /*
   *
   * Page name: Cover Details
   * Page url: /cover-details
   * Journey: Family cover
   *
   */

  static onFamilyCoverStart() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_form_event: 'start',
      page_name: this.familyMembersLandingPage,
      page_tool_name: `${this.familyMembersLandingPage}: enable`,
      page_form_name:
        'vodasure: funeral cover: cover amount: add members: details',
    });
  }

  static onFamilyCoverAddMember(familyMember: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.familyMembersLandingPage,
      page_tool_name: `${this.familyMembersLandingPage}: ${
        familyMember === 'child' ? 'children' : familyMember
      }: add`,
    });
  }

  static onFamilyCoverRemoveMember(familyMember: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.familyMembersLandingPage,
      page_tool_name: `${this.familyMembersLandingPage}: ${
        familyMember === 'child' ? 'children' : familyMember
      }: remove`,
    });
  }

  static onFamilyCoverEnd(coverAmount: number) {
    this.sendLinkToTealium({
      page_form_event: 'success',
      page_tool_event: 'use',
      page_name: this.familyMembersLandingPage,
      page_tool_name: `${this.familyMembersLandingPage}: continue: ${coverAmount}`,
      page_form_name:
        'vodasure: funeral cover: cover amount: add members: details',
    });
  }

  /*
   *
   * Page name: About your family
   * Page url: /family-details
   * Journey: Family cover
   *
   */

  static onAboutYourFamilyStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'start',
      page_name: this.familyPersonalDetailsPage,
      page_form_name: 'about your family',
    });
  }

  static onAboutYourFamilyEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_form_event: 'success',
      page_name: this.familyPersonalDetailsPage,
      page_tool_name: `${this.familyPersonalDetailsPage}: continue`,
      page_form_name: 'about your family',
    });
  }

  /*
   *
   * Page name: Add a Beneficiary
   * Page url: /beneficiary
   * Journey: Family cover
   *
   */

  static onFamilyBeneficiaryStart() {
    this.sendViewToTealium({
      page_event: 'view',
      service_application_event: 'start',
      page_name: this.familyBeneficiaryPage,
      page_form_name: 'add beneficiary',
      service_application_name: 'vodasure: funeral cover: add a beneficiary',
      service_application_type: 'query',
    });
  }

  static onFamilyBeneficiaryEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.familyBeneficiaryPage,
      page_tool_name: `${this.familyBeneficiaryPage}: continue`,
    });
  }

  static onNoFamilyBeneficiaryStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.familyBeneficiaryPage}: no beneficiary`,
    });
  }

  static onNoFamilyBeneficiaryAction(action: string) {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.familyBeneficiaryPage}: no beneficiary`,
      page_tool_name: `${this.familyBeneficiaryPage}: no beneficiary: ${action}`,
    });
  }

  static onAddOtherFamilyBeneficiaryStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_name: `${this.familyBeneficiaryPage}: other beneficiary`,
    });
  }

  static onAddOtherFamilyBeneficiaryEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: `${this.familyBeneficiaryPage}: other beneficiary`,
      page_tool_name: `${this.familyBeneficiaryPage}: other beneficiary: next`,
    });
  }

  /**
   * ERROR PAGES
   */

  /*
   *
   * Page name: Technical Error
   * Page url: N/A
   *
   */

  static onTechnicalErrorStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'error',
      page_name: this.errorPage,
      page_errors: 'we are experiencing technical issues',
      page_error_type: 'page',
    });
  }

  static onTechnicalErrorEnd(tool: 'ok' | 'report an issue') {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.errorPage,
      page_tool_name: `we are experiencing technical issues: ${tool}`,
    });
  }

  /*
   *
   * Page name: Identity Verification Failed
   * Page url: N/A
   *
   */

  static onIdentityVerificationErrorStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'error',
      page_name: this.errorPage,
      page_errors: 'identity verification failed',
      page_error_type: 'page',
    });
  }

  static onIdentityVerificationErrorEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.errorPage,
      page_tool_name: 'identity verification failed: ok',
    });
  }

  /*
   *
   * Page name: Existing policy
   * Page url: N/A
   *
   */

  static onExistingPolicyErrorStart() {
    this.sendViewToTealium({
      page_event: 'view',
      page_form_event: 'error',
      page_name: this.errorPage,
      page_errors: 'existing policy',
      page_error_type: 'page',
    });
  }

  static onExistingPolicyErrorEnd() {
    this.sendLinkToTealium({
      page_tool_event: 'use',
      page_name: this.errorPage,
      page_tool_name: 'existing policy: ok',
    });
  }

    /**
   *
   * Page name: referrel page
   * Page url: /cover-amount
   *
   * */
    static onReferralPage() {
      this.sendViewToTealium({
        event_name: 'view',
        page_name: this.referrelPage,
        service_application_event: 'start',
        service_application_name: 'vodasure: retail partners',
        service_application_type: 'query',
        visitor_type: 'retail partner'
      });
    }

    static onReferralCodeSubmit() {
      this.sendLinkToTealium({
        page_tool_event: 'use',
        page_name: this.referrelPage,
        page_tool_name: 'vodasure: funeral cover: retail partners: submit',
        service_application_event: 'finish',
        service_application_name: 'vodasure: retail partners',
        service_application_type: 'query',
        visitor_type: 'retail partner'
      });
    }

    static onErrorOnReferralPage(formErrors: string) {
      this.sendViewToTealium({
        event_name: 'view',
        page_name: this.referrelPage,
        page_form_event: 'error',
        service_application_event: 'start',
        page_errors: formErrors,
        page_error_type: 'form',
        service_application_name: 'vodasure: retail partners',
        service_application_type: 'query'
      });
    }
}

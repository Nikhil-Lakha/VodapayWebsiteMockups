import { Quote, BankInfo, Order, KycRequest } from '@/types';
import { Api } from './api';
import { Environment } from '@/utils';
import {
  callMeBackMock,
  dynamicQuotesMock,
  eligibilityCheckMock,
  funeralPolicyOrderMock,
  validateBankAccountMock,
  vodacomCustomerCheckMock,
} from '@/utils/mock';

const requestBody = (body: object) => ({
  body: JSON.stringify(body),
  headers: {
    'Content-Type': 'application/json',
    'X-API-Channel': 'VodacomWeb',
  },
});

export const vodacomCustomerCheck = async (phoneNumber: string) => {
  const ENDPOINT = `rest/financial-services/product/qualification/account?msisdn=${phoneNumber}`;

  if (Environment.current.apiRequests === 'false') {
    return await vodacomCustomerCheckMock();
  }

  return await Api.get(ENDPOINT, {});
};

export const dynamicQuotes = async (data: Quote) => {
  const ENDPOINT = 'rest/insurance/funeralcover/dynamic-quotes';
  const body = {
    channelId: data.channelId,
    msisdn: data.cellphoneNumber,
    coverAmount: data.coverAmount,
    individualAge: data.individualAge,
    includeSpouse: data?.spouse ? data.spouse.length > 0 : false,
    includeVas: Boolean(data?.funeral),
    includeDataReward: Boolean(data?.dataReward),
    includeMedical: false,
    includeLoyalty: false,
    children: [...(data.children || [])],
    dependants: [...(data.extended || [])],
  };

  if (Environment.current.apiRequests === 'false') {
    return await dynamicQuotesMock();
  }

  return await Api.post(ENDPOINT, requestBody(body));
};

export const eligibilityCheck = async (
  phoneNumber: string,
  idNumber: string
) => {
  const ENDPOINT = `rest/financial-services/product/qualification/insurance?msisdn=${phoneNumber}&idNumber=${idNumber}&idType=RSAID&product=FUNERAL&campaign=OnlFun`;

  if (Environment.current.apiRequests === 'false') {
    return await eligibilityCheckMock();
  }

  return await Api.get(ENDPOINT, {
    headers: {
      'X-API-Channel': 'VodacomWeb',
    },
  });
};

export const callMeBack = async (data: {
  firstName: string;
  lastName: string;
  phoneNumber: string;
}) => {
  const ENDPOINT = '';
  const body = {
      campaign: 'Family Funeral Cover',
      ...data,
  };

  if (Environment.current.apiRequests === 'false') {
    return await callMeBackMock();
  }

  return await Api.post(
    ENDPOINT,
    {
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
      },
    },
    true
  );
};

export const validateBankAccount = async (data: BankInfo) => {
  const ENDPOINT = 'financial-services/funeral-insurance/order/accountvetting';
  const body = {
    accountNumber: data.payment.accountNumber,
    accountType: data.payment.accountType,
    bankName: data.payment.bankName,
    branchCode: data.payment.branchCode,
    idNumber: data.idNumber,
    surname: data.payment.accountHolderName,
  };

  if (Environment.current.apiRequests === 'false') {
    return await validateBankAccountMock();
  }

  return await Api.post(ENDPOINT, requestBody(body));
};

const getAddOnsForOrder = (data: Order) => ({
  loyaltyBenefit: false,
  medicalAssist: false,
  funeralAssist: data.product.addOns?.funeral.state ?? false,
  dataRewardBenefit: data.product.addOns?.dataReward.state ?? false
});

export const funeralPolicyOrder = async (data: Order) => {
  const ENDPOINT = 'financial-services/funeral-insurance/order';
  const body = {
    funeralCoverCampaign: data.referralCode ? 'RetailOnline' : 'OnlFun',
    mainClient: {
      firstName: data.personal.firstName,
      lastName: data.personal.surname,
      dateOfBirth: data.personal.dateOfBirth?.replace(/-/g, ''),
      cellphoneNumber: data.personal.cellphoneNumber,
      age: data.personal.age,
      amount: Number(data.product.coverAmount),
      idNumber: data.personal.idNumber,
      funeralCoverMainClientCommunicationDetails: {
        emailAddress: data.personal.email,
        funeralCoverCommunicationMethod: 'EMAIL',
      },
    },
    ...(data.family?.spouse.length !== 0 && {
      spouse: {
        age: data.family?.spouse[0].age,
        dateOfBirth: (data.family?.spouse[0]?.dateOfBirth || '').replace(
          /-/g,
          ''
        ),
        amount: Number(data.family?.spouse[0]?.coverAmount || ''),
        funeralCoverGender: data.family?.spouse[0].gender,
        name: data.family?.spouse[0].firstName,
        lastName: data.family?.spouse[0].surname,
      },
    }),
    children: [
      ...data.family.child.map(child => ({
        dateOfBirth: child?.dateOfBirth?.replace(/-/g, ''),
        amount: Number(data.product.coverAmount),
        lastName: child.surname,
        name: child.firstName,
        funeralCoverGender: child.gender,
        age: child.age,
      })),
    ],
    extendedFamily: [
      ...data.family.extended.map(member => ({
        dateOfBirth: member.dateOfBirth?.replace(/-/g, ''),
        amount: Number(member.coverAmount),
        lastName: member.surname,
        funeralCoverGender: member.gender,
        name: member.firstName,
        age: member.age,
      })),
    ],
    funeralCoverPaymentOption: data.payment.paymentMethod,
    funeralCoverBankingDetails: {
      accountNumber: data.payment.accountNumber,
      accountType: data.payment.accountType,
      bankName: data.payment.bankName,
      branchCode: data.payment.branchCode,
      debitOrderDate: Number(data.payment.debitOrderDate),
      nameOfAccountHolder: data.payment.accountHolderName,
      funeralCoverCommencement: data.payment.coverStart
        ? data.payment.coverStart
        : null,
    },
    ...(data?.beneficiary &&
      Object.values(data?.beneficiary).length > 0 && {
        funeralCoverBeneficiaryDetails: {
          firstName: data.beneficiary.firstName,
          gender: data.beneficiary.gender,
          lastName: data.beneficiary.surname,
          dateOfBirth: data.beneficiary.dateOfBirth?.replace(/-/g, ''),
          relationship: 'ExtendedFamily',
          extendedRelationship: data.beneficiary.relationship,
          age: data.beneficiary.age,
          cellphoneNumber: data.beneficiary.cellphoneNumber,
        },
      }),
    ...(data.referralCode && { lead: [{ campaignCode: 'VodasureLead', leadRefs: [{ refName: 'ReferralCode', refValue: data.referralCode }] }] }),
    ...getAddOnsForOrder(data)
  };

  if (Environment.current.apiRequests === 'false') {
    return await funeralPolicyOrderMock();
  }

  return await Api.post(ENDPOINT, requestBody(body));
};

function createKycMandatoryFieldObj({ data, typeOfCheck } : { data : any, typeOfCheck : string }): KycRequest {
  const result:KycRequest = {
    channel: 'OnlineJourney',
    idNumber: data.personal.idNumber,
    result: 'pass',
    firstName: data.personal.firstName,
    lastName: data.personal.surname,
    checkDoneTimestamp: new Date(),
    typeOfCheck: typeOfCheck === 'AVS' ? 'AVS' : 'XDS',
  };
  if (typeOfCheck && typeOfCheck === 'AVS') {
    result.bankName = typeOfCheck === 'AVS' ? data.payment.bankName : null,
    result.accountHolderName = typeOfCheck === 'AVS' ? data.payment.accountHolderName : null,
    result.accountNumber = typeOfCheck === 'AVS' ? data.payment.accountNumber : null,
    result.bankCode = typeOfCheck === 'AVS' ? data.payment.branchCode : null;
  }
  return result;
}

export const kycXDSCheckRequest = async (data: any) => {
  const ENDPOINT = 'financial-services/funeral-insurance/order/kyc';

  if (Environment.current.apiRequests === 'false') {
    return await funeralPolicyOrderMock();
  }
  const kycXdsChecks = createKycMandatoryFieldObj({ data, typeOfCheck: 'XDS' });
  return await Api.post(ENDPOINT, requestBody(kycXdsChecks));
};

export const kycAVSCheckRequest = async (data: any) => {
  const ENDPOINT = 'financial-services/funeral-insurance/order/kyc';
  if (Environment.current.apiRequests === 'false') {
    return await funeralPolicyOrderMock();
  }
  const kycAvsChecks = createKycMandatoryFieldObj({ data, typeOfCheck: 'AVS' });
  return await Api.post(ENDPOINT, requestBody(kycAvsChecks));
};

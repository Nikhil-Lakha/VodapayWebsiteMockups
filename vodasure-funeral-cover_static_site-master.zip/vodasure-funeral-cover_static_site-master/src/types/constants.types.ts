/* eslint-disable no-shadow */
export enum ErrorActions {
  exit = 'exit',
  retry = 'retry',
  callMeBack = 'callMeBack',
}

export enum ErrorTypes {
  genericError = 'genericError',
  applicationCancelled = 'applicationCancelled',
  identityVerification = 'identityVerification',
  existingPolicy = 'existingPolicy',
  accountArrears = 'accountArrears',
  technicalError = 'technicalError',
}

export interface ErrorButton {
  title: string;
  action?: ErrorActions;
  analytics?: () => void;
}

export interface ErrorContent {
  [key: string]: {
    title: string;
    description: string;
    primaryButton: ErrorButton;
    secondaryButton?: ErrorButton;
    onMount?: () => void;
  };
}

export interface ValidAge {
  [key: string]: {
    type: string;
    max: number;
    min: number;
  };
}

export interface JourneyStep {
  group: string;
  step: string;
  route: string;
}

export interface StepGroups {
  [key: string]: string;
}

export interface IAssistanceRoutes {
  [key: string]: { route: string };
}

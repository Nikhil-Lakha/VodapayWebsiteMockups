export interface View {
  event_name?: 'view';
  page_event?: 'view';
  page_name: string;
  page_form_event?: 'start' | 'success' | 'error';
  page_form_name?: string;
  page_errors?: string;
  page_error_type?: 'page' | 'form';
  service_application_name?: string;
  service_application_type?: string;
  service_application_event?: string;
  visitor_type?: 'retail partner' | 'consumer';
}

export interface Link {
  page_name: string;
  page_tool_event?: 'use';
  page_tool_name?: string;
  page_form_event?: 'start' | 'use' | 'success';
  page_form_name?: string;
  service_application_name?: string;
  service_application_event?: 'finish' | 'start';
  service_application_type?: 'query';
  product_option?: string;
  filter_query?: string;
  link_name?: string;
  link_id?: string;
  visitor_type?: 'retail partner' | 'consumer';
}

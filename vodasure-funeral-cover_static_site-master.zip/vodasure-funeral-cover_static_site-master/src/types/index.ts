/* eslint-disable no-shadow */
interface Person {
  firstName?: string;
  surname?: string;
  dateOfBirth?: string;
}

export interface ReferralCode {
  referralCode?: string;
}

export interface PersonalDetails extends Person {
  cellphoneNumber?: string;
  email?: string;
  idNumber?: string;
  age?: number;
}

export interface AddOns {
  funeral: { state?: boolean; cost?: string, fromPremium?: string };
  medical?: { state?: boolean; cost?: string, fromPremium?: string };
  dataReward: { state?: boolean; cost?: string, fromPremium?: string };
}
export interface ProductDetails {
  coverAmount?: number;
  basePremium?: number;
  totalPremium?: number;
  coverType: 'individualCover' | 'familyCover';
  addOns?: AddOns;
  createdAt?: string;
  coverStart?: string;
}

export enum BeneficiaryRelationships {
  wife = 'Wife',
  husband = 'Husband',
  daughter = 'Daughter',
  son = 'Son',
  adultChild = 'AdultChild',
  sister = 'Sister',
  brother = 'Brother',
  mother = 'Mother',
  father = 'Father',
  aunt = 'Aunt',
  uncle = 'Uncle',
  femaleCousin = 'FemaleCousin',
  maleCousin = 'MaleCousin',
  niece = 'Niece',
  nephew = 'Nephew',
  grandmother = 'Grandmother',
  grandfather = 'Grandfather',
  granddaughter = 'Granddaughter',
  grandson = 'Grandson',
  other = 'Other',
}

export interface BeneficiaryDetails extends Person {
  coverAmount?: string;
  gender?: 'female' | 'male';
  selectBeneficiary?: string;
  relationship?: BeneficiaryRelationships;
  cellphoneNumber?: string;
  age?: number;
}

export enum CoverStart {
  Immediately = 'Immediately',
  NextMonth = 'NextMonth',
}

export enum CoverStartOption {
  proceed = 'proceed', // NextMonth & Immediately
  nextMonth = 'nextMonth', // NextMonth
  twoMonths = 'twoMonths', // NextMonth
}

export enum PaymentMethods {
  debitOrder = 'DebitOrder',
  addToBill = 'AddToBill',
  unset = '',
}

export interface PaymentDetails {
  bankName?: string;
  accountNumber?: string;
  accountType?: 'SAVING' | 'CURRENT';
  branchCode?: string;
  accountHolderName?: string;
  debitOrderDate?: string;
  coverStart?: CoverStart | '';
  coverStartOption?: CoverStartOption | '';
  paymentMethod?: PaymentMethods;
  agreeToTerms?: boolean;
}

export interface FamilyMember extends Person {
  coverAmount?: string | number;
  gender?: 'female' | 'male';
  age?: number;
}

export interface FamilyDetails {
  spouse: FamilyMember[];
  child: FamilyMember[];
  extended: FamilyMember[];
}

interface Benefit {
  included: boolean;
  amount: string;
}

export interface Premium {
  planName:
    | 'Basic'
    | 'Basic + VAS'
    | 'Basic + Data Reward'
    | 'Basic + Data Reward + VAS';
  amount: string;
  vasBenefit: Benefit;
  loyaltyBenefit: Benefit;
  medicalBenefit: Benefit;
  dataRewardBenefit?: Benefit
}

export interface JourneyStep {
  group: string;
  step: string;
  route: string;
}

export interface Quote {
  channelId: string;
  cellphoneNumber: string;
  coverAmount: number;
  individualAge: number;
  dataReward: boolean;
  funeral: boolean;
  spouse?: object[];
  children?: object[];
  extended?: object[];
}

export interface QuoteResponse {
  messages: [];
  result: {
    premiumOptions: Premium[];
    selectedPremium: {
      amount: number;
      vasBenefit: { amount: string };
      dataRewardBenefit?: { amount: string };
    };
  };
  successful: boolean;
  code: number;
  status?: number;
}

export interface BankInfo {
  payment: PaymentDetails;
  idNumber: string;
}

export interface Order {
  personal: PersonalDetails;
  payment: PaymentDetails;
  family: FamilyDetails;
  beneficiary: BeneficiaryDetails;
  product: ProductDetails;
  referralCode?: string;
}

export interface DevToolSettings {
  apiRequests: string;
  disableAnalytics: string;
  apiHost: string;
  debugAnalytics: string;
}

export enum ICallMeBackStatus {
  unset = '',
  accepted = 'accepted',
  rejected = 'rejected',
}

export interface IEnvironment {
  name: string;
  env: string;
  uiHost: string;
  apiHost: string;
  callMeBackApi: string;
  apiBase: string;
  tealium: string;
  allowDebug: boolean;
  debugKey?: string;
  apiRequests?: string;
  disableAnalytics?: string;
  debugAnalytics?: string;
}

export interface IAppContext {
  clearApplication: () => void;
  personalDetails: PersonalDetails;
  setPersonalDetails: React.Dispatch<React.SetStateAction<PersonalDetails>>;
  productDetails: ProductDetails;
  setProductDetails: React.Dispatch<React.SetStateAction<ProductDetails>>;
  beneficiaryDetails: BeneficiaryDetails;
  setBeneficiaryDetails: React.Dispatch<
    React.SetStateAction<BeneficiaryDetails>
  >;
  paymentDetails: PaymentDetails;
  setPaymentDetails: React.Dispatch<React.SetStateAction<PaymentDetails>>;
  familyDetails: FamilyDetails;
  setFamilyDetails: React.Dispatch<React.SetStateAction<FamilyDetails>>;
  finalSteps: JourneyStep[];
  setFinalSteps: React.Dispatch<React.SetStateAction<JourneyStep[]>>;
  isFamilyJourney: boolean;
  setIsFamilyJourney: React.Dispatch<React.SetStateAction<boolean>>;
  premiumOptions: Premium[];
  setPremiumOptions: React.Dispatch<React.SetStateAction<Premium[]>>;
  isAddToBill: boolean;
  setIsAddToBill: React.Dispatch<React.SetStateAction<boolean>>;
  isVodacomCustomer: boolean;
  setIsVodacomCustomer: React.Dispatch<React.SetStateAction<boolean>>;
  referralCode: string;
  setReferralCode: React.Dispatch<React.SetStateAction<string>>;
}

export interface KycRequest {
  channel: string,
  idNumber: string,
  result: string,
  firstName: string,
  lastName: string,
  checkDoneTimestamp: Date,
  typeOfCheck: string,
  bankName?: string|null,
  accountHolderName?: string | null,
  accountNumber?: string | null,
  bankCode?: string | null

}

export * from './constants.types';
export * from './tealium.types';

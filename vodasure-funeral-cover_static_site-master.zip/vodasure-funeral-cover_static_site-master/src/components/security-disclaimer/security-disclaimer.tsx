import React from 'react';
import { LockIcon, LockIconSolid, IconSymantec, IconDigicert } from '@/assets';
import './security-disclaimer.scss';

export const SecurityDisclaimer = () => (
  <section className='security-disclaimer'>
    <section className='lock-line'>
      <span className='lock-bg'>
        <img src={LockIcon} alt='lock' />
      </span>
      <p>Secure checkout</p>
    </section>
    <section className='secured-by'>
      <span className='text'>
        <img src={LockIconSolid} alt='icon lock' /> Secured by:
      </span>
      <img src={IconSymantec} alt='icon symantec' />
      <img src={IconDigicert} alt='icon digicert' />
    </section>
  </section>
);

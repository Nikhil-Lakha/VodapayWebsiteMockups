import React, { useState } from 'react';
import { IconCaretDown } from '@/assets';
import './family-member-accordion.scss';

interface Props {
  index: number;
  coverType: string;
  children: React.ReactNode;
}

export const FamilyMemberAccordion = ({
  index,
  coverType,
  children,
}: Props) => {
  const [isActive, setIsActive] = useState(false);

  return (
    <article className='family-details-accordion'>
      <header onClick={() => setIsActive(curr => !curr)}>
        <h4>
          {coverType} {coverType !== 'spouse' ? index + 1 : ''}
        </h4>
        <img
          className={`${isActive && 'is-active'}`}
          src={IconCaretDown}
          alt='icon'
        />
      </header>
      <section className={`accordion-content ${isActive && 'is-active'}`}>
        {children}
      </section>
    </article>
  );
};

import React from 'react';
import classNames from 'classnames';
import './overlay.scss';

interface Props {
  children: React.ReactNode;
  onClick: () => void;
  show: boolean;
}

export const Overlay = ({ children, onClick, show }: Props) => {
  const overlayClass = classNames('overlay', {
    show,
  });

  return (
    <article className={overlayClass} onClick={onClick}>
      {children}
    </article>
  );
};

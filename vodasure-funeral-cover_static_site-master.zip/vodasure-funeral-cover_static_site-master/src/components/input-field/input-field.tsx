import React, { useMemo, useState } from 'react';
import { getIn, FormikProps } from 'formik';
import MaskedInput, { Mask } from 'react-text-mask';
import { Tip, Dropdown, DatePicker } from '@/components';
import './input-field.scss';
import classNames from 'classnames';

interface RenderProps<T> {
  inputType: string;
  name: string;
  type: string;
  inputmode:
    | 'email'
    | 'search'
    | 'text'
    | 'tel'
    | 'url'
    | 'numeric'
    | 'none'
    | 'decimal';
  autoComplete?: string;
  formik: FormikProps<T>;
  mask: Mask;
  showCharacterLimit?: boolean;
  disabled?: boolean;
  items?: { label: string; value: string }[];
  maxLength?: number;
}

const RenderInput = <T extends object>({
  inputType,
  name,
  type,
  inputmode,
  autoComplete,
  formik,
  mask,
  items,
  showCharacterLimit = false,
  disabled = false,
  ...restProps
}: RenderProps<T>) => {
  const [showWarning, setShowWarning] = useState<boolean>(false);

  const { maxLength } = restProps;

  useMemo(() => {
    setShowWarning(getIn(formik.touched, name) && getIn(formik.errors, name));
  }, [formik.touched, formik.errors, name]);

  switch (inputType) {
    case 'masked':
      return (
        <MaskedInput
          name={name}
          type={type}
          inputMode={inputmode}
          autoComplete={autoComplete}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          mask={mask}
          value={getIn(formik.values, name)}
          disabled={disabled}
          {...restProps}
          className={`${showWarning && 'is-warning'}`}
        />
      );
    case 'select':
      return (
        <Dropdown
          name={name}
          options={items || []}
          formik={formik}
          disabled={disabled}
          {...restProps}
        />
      );
    case 'date':
      return (
        <DatePicker
          name={name}
          formik={formik}
          disabled={disabled}
          {...restProps}
        />
      );
    default:
      return maxLength && showCharacterLimit ? (
        <article className={classNames('character-limit-wrapper', { 'is-warning': showWarning })}>
          <input
            name={name}
            type={type}
            inputMode={inputmode}
            autoComplete={autoComplete}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={getIn(formik.values, name)}
            disabled={disabled}
            {...restProps}
          />
          <span>{getIn(formik.values, name)?.length || 0}/{maxLength}</span>
        </article>
        ) :
        <input
          name={name}
          type={type}
          inputMode={inputmode}
          autoComplete={autoComplete}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={getIn(formik.values, name)}
          disabled={disabled}
          {...restProps}
          className={`${showWarning && 'is-warning'}`}
        />;
  }
};

interface InputProps<T> {
  name: string;
  label?: string;
  type: string;
  inputmode:
    | 'email'
    | 'search'
    | 'text'
    | 'tel'
    | 'url'
    | 'numeric'
    | 'none'
    | 'decimal';
  autocomplete?: string;
  tip?: string;
  fieldType?: 'masked' | 'date' | 'select';
  items?: { label: string; value: string }[];
  mask?: Mask;
  formik: FormikProps<T>;
  disabled?: boolean;
  showCharacterLimit? : boolean;
  [x: string]: unknown;
}

export const InputField = <T extends object>({
  name,
  label,
  type,
  inputmode,
  autocomplete,
  tip,
  fieldType,
  items,
  showCharacterLimit = false,
  disabled = false,
  ...props
}: InputProps<T>) => {
  const { formik, mask, ...restProps } = props;

  return (
    <div className='input-field'>
      <label className='input-label'>{label ? label : '\u00A0'}</label>
      <RenderInput
        inputType={fieldType || ''}
        name={name}
        type={type}
        inputmode={inputmode}
        autoComplete={autocomplete}
        formik={formik}
        mask={mask || []}
        items={items}
        disabled={disabled}
        showCharacterLimit={showCharacterLimit}
        {...restProps}
      />
      {getIn(formik.touched, name) && getIn(formik.errors, name) ? (
        <Tip text={getIn(formik.errors, name)} type='warning' />
      ) : (
        tip && <Tip text={tip} type='info' />
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { useQuery } from 'react-query';
import {
  ICallMeBackStatus,
  ErrorActions,
  ErrorButton,
  PersonalDetails,
} from '@/types';
import { TealiumService, callMeBack } from '@/services';
import { applicationDefaults, queryKeys, stringFormat } from '@/utils';
import { ErrorIcon } from '@/assets';
import { Button, CallMeBack, CallMeBackStatus } from '@/components';
import './error.scss';
import { useErrorHandler } from '@/hooks';

interface Props {
  title: string;
  description: string;
  primaryButton: ErrorButton;
  secondaryButton?: ErrorButton;
  errorType: string;
  traceId?: string;
  onMount?: () => void;
}

interface CallMeResponseData {
  result: {
    name: string;
    status: ICallMeBackStatus;
  };
}

export const Error = ({
  title,
  description,
  primaryButton,
  secondaryButton,
  errorType,
  traceId,
  onMount,
}: Props) => {
  const [showCallMeBack, setShowCallMeBack] = useState(false);
  const [callMeBackValues, setCallMeBackValues] = useState<PersonalDetails>({
    firstName: '',
    surname: '',
    cellphoneNumber: '',
  });
  const [callMeBackStatus, setCallMeBackStatus] = useState<ICallMeBackStatus>(
    ICallMeBackStatus.unset
  );
  const handleError = useErrorHandler();

  const { staticPageUrl } = applicationDefaults;

  useEffect(() => {
    if (onMount) {
      onMount();
    }
  }, [onMount]);

  useEffect(() => {
    switch (callMeBackStatus) {
      case ICallMeBackStatus.accepted:
        TealiumService.onCallMeBackSuccess();
        break;
      case ICallMeBackStatus.rejected:
        TealiumService.onCallMeBackFailed();
        break;
      default:
        break;
    }
  }, [callMeBackStatus]);

  function handleCallMeBack(data: CallMeResponseData) {
    if (data && data.result?.status) {
      setCallMeBackStatus(data.result.status);
      setShowCallMeBack(false);
    }
    // handleError(new Error('genericError' as Props));
  }

  const callMeBackRequest = useQuery(
    queryKeys.callMeBack,
    () =>
      callMeBack({
        firstName: callMeBackValues.firstName || '',
        lastName: callMeBackValues.surname || '',
        phoneNumber: stringFormat.stripWhitespace(
          callMeBackValues.cellphoneNumber || ''
        ),
      }),
    {
      refetchOnWindowFocus: false,
      enabled: false,
      retry: false,
      onSuccess: handleCallMeBack,
    }
  );

  function handleClick(button: ErrorButton) {
    if (button.analytics) {
      button.analytics();
    }

    switch (button.action) {
      case ErrorActions.exit:
        window.location.href = staticPageUrl;
        break;

      case ErrorActions.retry:
        window.location.reload();
        break;

      case ErrorActions.callMeBack:
        TealiumService.onCallMeBackStart();
        setShowCallMeBack(true);
        break;

      default:
        break;
    }
  }

  function closeCallMeBack() {
    setShowCallMeBack(false);
  }

  function confirmCallMeBack() {
    TealiumService.onCallMeBackEnd();
    callMeBackRequest.refetch();
  }

  function onCloseCallMeBackStatus() {
    setCallMeBackStatus(ICallMeBackStatus.unset);
    window.location.reload();
  }

  return (
    <>
      <CallMeBack
        handleClose={closeCallMeBack}
        handleConfirm={confirmCallMeBack}
        formValues={setCallMeBackValues}
        loading={callMeBackRequest.isFetching}
        show={showCallMeBack}
      />
      <CallMeBackStatus
        status={callMeBackStatus}
        onClose={onCloseCallMeBackStatus}
        show={
          callMeBackStatus === ICallMeBackStatus.rejected ||
          callMeBackStatus === ICallMeBackStatus.accepted
        }
      />
      <main className='error-container'>
        <img className='logo' src={ErrorIcon} alt='error logo' />

        <h1>{title}</h1>
        <p>
          {`${description.split('.').join('.\n')}\n
            ${
              traceId && errorType === 'technicalError'
                ? `Trace ID: ${traceId}`
                : ''
            }`}
        </p>

        <section className='button-group'>
          {secondaryButton && (
            <Button onClick={() => handleClick(secondaryButton)} secondary>
              {secondaryButton.title}
            </Button>
          )}
          <Button onClick={() => handleClick(primaryButton)} primary>
            {primaryButton.title}
          </Button>
        </section>
      </main>
    </>
  );
};

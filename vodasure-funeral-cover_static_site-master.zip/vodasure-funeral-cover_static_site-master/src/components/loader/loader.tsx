import React from 'react';
import { Overlay, LoaderAnimation } from '@/components';
import './loader.scss';

export const Loader = () => (
  // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
  <Overlay onClick={() => {}} show>
    <section className='loader-container' onClick={e => e.stopPropagation()}>
      <LoaderAnimation height={140} width={140} />
    </section>
  </Overlay>
);

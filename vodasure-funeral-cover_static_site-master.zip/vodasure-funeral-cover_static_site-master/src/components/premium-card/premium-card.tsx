import React, { useContext, Dispatch, SetStateAction } from 'react';
import { AppContext } from '@/context';
import { formatCurrency } from '@/utils';
import { Switch } from '@/components';
import {
  VodaSureLogo,
  VodaFoneLogo,
  ChevronRight,
  SuccessCircle,
  EditIcon,
} from '@/assets';
import './premium-card.scss';
import { PersonalDetails } from '@/types';

interface Props {
  onClick: () => void;
  showFamily: () => void;
  editDetails: () => void;
  details: PersonalDetails;
  familyCoverActive: boolean;
}

export const PremiumCard = ({
  onClick,
  showFamily,
  editDetails,
  details,
  familyCoverActive,
}: Props) => {
  const { productDetails } = useContext(AppContext);
  const { firstName, surname } = details;

  return (
    <article className='premium-card'>
      <header>
        <img src={VodaSureLogo} alt='vodasure' />
        <h3>vodasure funeral cover</h3>
      </header>
      <section>
        <p className='premium-amount'>
          {formatCurrency(productDetails?.basePremium || 0)}
        </p>
        <p>Per month</p>
        <Switch
          label='Add family members'
          onClick={showFamily}
          active={familyCoverActive}
        />
      </section>
      <section className='user-info-edit'>
        <p>
          <img src={SuccessCircle} alt='success-icon' /> {firstName} {surname}
        </p>
        <a onClick={editDetails}>
          <img src={EditIcon} alt='edit-icon' /> Edit details
        </a>
      </section>
      <p className='info-text'>
        Estimated monthly premium based on minimal information and subject to
        change.
      </p>
      <footer>
        <img src={VodaFoneLogo} alt='vodapay' />
        <p>
          Scan the QR code and get up to 40% off in premiums when you apply on
          VodaPay
        </p>
        <button type='button' onClick={onClick}>
          <span>Scan QR code</span>
          <img src={ChevronRight} alt='right' />
        </button>
      </footer>
    </article>
  );
};

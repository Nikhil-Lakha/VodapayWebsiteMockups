import React, { useEffect } from 'react';
import { InfoIconWhite } from '@/assets';
import './notification.scss';

interface Props {
  message: string;
  buttonText: string;
  visible: boolean;
  setVisible?: (value: boolean) => void;
  onDismiss: () => void;
  interval?: number;
}

export const Notification = ({
  message,
  buttonText,
  visible = false,
  setVisible,
  onDismiss,
  interval = 10000,
}: Props) => {
  useEffect(() => {
    if (interval && setVisible) {
      const timeout = setTimeout(() => {
        setVisible(false);
      }, interval);

      return () => clearInterval(timeout);
    }
  }, [interval, setVisible]);
  return (
    <div
      className='notification-container'
      style={{ top: visible ? '0' : '-250px' }}
    >
      <div className='notification'>
        <img src={InfoIconWhite} alt='info' />
        <p>{message}</p>
        <button type='button' onClick={onDismiss}>
          {buttonText}
        </button>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Modal } from '../modal/modal';
import { applicationDefaults } from '@/utils';
import { CancellationForm } from '@/forms';
import { Button } from '../button/button';
import { WarningIconBlack } from '@/assets';
import { TealiumService } from '@/services';

interface Props {
  handleClose: () => void;
  handleConfirm: () => void;
  show: boolean;
}

export const CancellationReasons = ({
  handleClose,
  handleConfirm,
  show,
}: Props) => {
  const [formValid, setFormValid] = useState<boolean>(false);
  const [formValues, setFormValues] = useState<{ reason: string }>({
    reason: '',
  });
  const { cancellationReasons } = applicationDefaults;

  useEffect(() => {
    if (show) {
      TealiumService.onDeclineQuoteReasons();
    }
  }, [show]);

  function onClickConfirm() {
    TealiumService.onDeclineQuoteReasonsClick('confirm', formValues.reason);
    handleConfirm();
  }

  function onClickCancel() {
    TealiumService.onDeclineQuoteReasonsClick('no');
    handleClose();
  }

  return (
    <Modal onClickClose={onClickCancel} show={show} type='large'>
      <>
        <img src={WarningIconBlack} alt='warning' />
        <p className='dialog-heading'>Cancel my quote</p>
        <CancellationForm
          initialValues={{ reason: '' }}
          reasons={cancellationReasons}
          formValid={setFormValid}
          formValues={setFormValues}
        />
        <section className='dialog-button-group'>
          <Button onClick={onClickCancel} secondary>
            No, don&apos;t cancel
          </Button>
          <Button onClick={onClickConfirm} disabled={!formValid} primary>
            Confirm and submit
          </Button>
        </section>
      </>
    </Modal>
  );
};

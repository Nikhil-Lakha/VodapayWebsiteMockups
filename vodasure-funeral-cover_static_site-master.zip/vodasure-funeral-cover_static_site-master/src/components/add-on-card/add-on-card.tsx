import React, { useEffect, useState } from 'react';
import { useNavService } from '@/hooks';
import { Button, Switch } from '@/components';
import {
  VodaFoneLogo,
  FuneralAssistIcon,
  Sparkle,
  VodaFoneDisabled,
} from '@/assets';
import { assistanceRoute, formatCurrency } from '@/utils';
import './add-on-card.scss';
import classNames from 'classnames';

const unavailable = 'Unavailable';

interface Props {
  type: string;
  heading: string;
  amount?: string;
  fromPremium?: string;
  badgeText?: string;
  benefits: string[];
  onToggleSwitch: (type: string) => void;
  defaultActive: boolean;
  disabled?: boolean;
}

export const AddOnCard = ({
  type,
  heading,
  amount,
  fromPremium,
  badgeText,
  benefits,
  onToggleSwitch,
  defaultActive,
  disabled,
}: Props) => {
  const navigate = useNavService();
  const [toggleActive, setToggleActive] = useState(defaultActive);
  const [switchLabel, setSwitchLabel] = useState('');
  const [benefitDisabled, setBenefitDisabled] = useState(false);

  const icons: { [key: string]: { enabled: string; disabled?: string } } = {
    dataReward: { enabled: VodaFoneLogo, disabled: VodaFoneDisabled },
    funeral: { enabled: FuneralAssistIcon, disabled: FuneralAssistIcon },
  };

  const { route } = assistanceRoute[type];

  function clickToggle() {
    setToggleActive(() => !toggleActive);
    onToggleSwitch(type);
  }

  useEffect(() => {
    if (amount) {
      setSwitchLabel(`${formatCurrency(Number(amount))} per month`);
    } else if (fromPremium) {
      setSwitchLabel(`From ${formatCurrency(Number(fromPremium))} per month`);
    } else {
      setSwitchLabel(unavailable);
    }
  }, [amount, fromPremium]);

  useEffect(() => {
    setBenefitDisabled(disabled || !amount);
  }, [disabled, amount]);

  return (
    <div className={`add-on-card-wrapper ${toggleActive && 'active'} `}>
      {badgeText && !benefitDisabled && (
        <aside className='badge'>
          <img src={Sparkle} />
          <img src={Sparkle} style={{ width: '10px', height: '10px' }} />
          <p>{badgeText}</p>
        </aside>
      )}
      <article
        className={classNames('add-on-card', {
          inactive: !toggleActive,
          disabled: benefitDisabled,
        })}
      >
        <header>
          <img
            src={icons[type][benefitDisabled ? 'disabled' : 'enabled']}
            alt='funeral assistance'
          />
          <h2
            className={classNames('heading-2', { disabled: benefitDisabled })}
          >
            {heading}
          </h2>
        </header>
        <section className='add-on-info'>
          <Switch
            disabled={benefitDisabled}
            label={switchLabel}
            onClick={clickToggle}
            active={defaultActive}
            alignLeft
          />
          <ul className={`${benefitDisabled && 'disabled'}`}>
            {benefits.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </section>
        <footer>
          <Button onClick={() => navigate.to(route)} secondary>
            View full list of benefits
          </Button>
        </footer>
      </article>
    </div>
  );
};

import React, { useContext, useState, Dispatch, SetStateAction } from 'react';
import { CallMeBackForm } from '@/forms';
import { AppContext } from '@/context';
import { PersonalDetails } from '@/types';
import { CallIcon } from '@/assets';
import { Button, LoaderAnimation, Modal } from '@/components';
import './call-me-back.scss';

interface Props {
  handleClose: () => void;
  handleConfirm: () => void;
  formValues: Dispatch<SetStateAction<PersonalDetails>>;
  loading: boolean;
  show: boolean;
}

export const CallMeBack = ({
  handleClose,
  handleConfirm,
  formValues,
  loading,
  show,
}: Props) => {
  const [formValid, setFormValid] = useState(false);

  const { personalDetails } = useContext(AppContext);

  return (
    <Modal onClickClose={handleClose} show={show} type='large'>
      <>
        <img src={CallIcon} alt='phone' />
        <p className='dialog-heading'>We&apos;ll call you back</p>
        <p className='dialog-subtext'>
          Give us your information and a call centre agent will be in touch.
        </p>
        {loading ? (
          <div className='loader-content'>
            <LoaderAnimation height={140} width={140} />
          </div>
        ) : (
          <>
            <CallMeBackForm
              initialValues={{
                firstName: personalDetails.firstName,
                surname: personalDetails.surname,
                cellphoneNumber: personalDetails.cellphoneNumber,
              }}
              formValid={setFormValid}
              formValues={formValues}
            />
            <section className='call-me-back-button-container'>
              <Button onClick={handleConfirm} disabled={!formValid} primary>
                Submit
              </Button>
            </section>
          </>
        )}
      </>
    </Modal>
  );
};

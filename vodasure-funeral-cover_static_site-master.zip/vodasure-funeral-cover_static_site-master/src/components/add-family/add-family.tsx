import React, { useState, useEffect, Dispatch, SetStateAction } from 'react';
import { TealiumService } from '@/services';
import { FamilyDetails } from '@/types';
import { Tip, Modal } from '@/components';
import { InfoIconCircle } from '@/assets';
import { MemberForm } from '@/forms';
import './add-family.scss';

interface Props {
  validForm: Dispatch<SetStateAction<boolean>>;
  initialValues: FamilyDetails;
}

export const AddFamily = ({ validForm, initialValues }: Props) => {
  const [showCoverAmountModal, setShowCoverAmountModal] = useState(false);

  function closeDialog() {
    setShowCoverAmountModal(false);
  }

  useEffect(() => {
    TealiumService.onFamilyCoverStart();
  }, []);

  return (
    <article className='add-family-card'>
      <header className='header-text'>
        <h3>Add family members</h3>
        <p>Choose cover for your family</p>
        <Tip
          text='Click for info on cover amounts'
          type='infoLink'
          centerAlign
          onClick={() => setShowCoverAmountModal(true)}
        />
      </header>
      <MemberForm
        validForm={validForm}
        initialValues={initialValues}
        showCoverAmountModal={setShowCoverAmountModal}
      />

      <Modal onClickClose={closeDialog} show={showCoverAmountModal}>
        <>
          <img src={InfoIconCircle} alt='info-icon' className='dialog-icon' />
          <p className='dialog-heading'>Cover amounts</p>
          <section className='dialog-body'>
            <section className='cover-info'>
              <h4>Spouse</h4>
              <ul>
                <li>
                  Cover amounts will remain the same as primary members cover
                  amount.
                </li>
              </ul>
            </section>
            <section className='cover-info'>
              <h4>Children</h4>
              <ul>
                <li>
                  Ages 0 - 6 years: 50% of main member&apos;s cover subject to a
                  maximum of R20 000 as per legislation.
                </li>
                <li>
                  Ages 7 - 13: 75% of main member&apos;s cover subject to a
                  maximum of R50 000 as per legislation.
                </li>
                <li>
                  Ages 14 - 18: 100% of main member&apos;s cover subject to a
                  maximum of R50 000 as per legislation.
                </li>
              </ul>
            </section>
            <section className='cover-info'>
              <h4>Extended family</h4>
              <ul>
                <li>
                  Ages 18 - 74: The maximum you can select is the cover your
                  policy provides you.
                </li>
              </ul>
            </section>
          </section>
        </>
      </Modal>
    </article>
  );
};

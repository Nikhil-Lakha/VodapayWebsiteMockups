import React from 'react';
import classNames from 'classnames';
import { InfoIcon, WarningIcon, InfoIconCustom, ContactIcon } from '@/assets';
import './tip.scss';

interface Props {
  text: string;
  type: 'info' | 'infoLink' | 'warning' | 'custom' | 'contact';
  centerAlign?: boolean;
  linkText?: string;
  link?: string;
  onClick?: () => void;
}

export const Tip = ({
  text,
  type,
  centerAlign,
  linkText,
  link,
  onClick,
}: Props) => {
  const tipClass = classNames(`info is-${type}`, {
    'center-align': centerAlign,
  });
  const iconMapper = {
    info: InfoIcon,
    infoLink: InfoIcon,
    warning: WarningIcon,
    custom: InfoIconCustom,
    contact: ContactIcon,
  };
  return (
    <section className={tipClass} onClick={onClick}>
      <img src={iconMapper[type]} alt='info' />
      <p>
        {type === 'contact' && (
          <>
            <a href={link}>{linkText}</a>
            <br />
          </>
        )}
        {text}
      </p>
    </section>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import lottie, { AnimationItem, AnimationConfigWithData } from 'lottie-web';
import { RedLoader } from '@/assets';
import './loader-animation.scss';

interface Props {
  width: number;
  height: number;
}

export const LoaderAnimation = ({ width, height }: Props) => {
  const element = useRef(null);
  const lottieInstance = useRef<AnimationItem>();
  const [style, setStyle] = useState<Props>({ width: 100, height: 100 });

  useEffect(() => {
    const styleNew: Props = { width: 100, height: 100 };

    if (width) {
      styleNew.width = width;
    }

    if (height) {
      styleNew.height = height;
    }

    setStyle(styleNew);

    if (element.current) {
      const params: AnimationConfigWithData = {
        container: element.current,
        loop: true,
        autoplay: true,
        animationData: RedLoader,
        rendererSettings: {
          preserveAspectRatio: 'xMidYMid slice',
        },
        ...styleNew,
      };
      lottieInstance.current = lottie.loadAnimation({
        ...params,
      });
    }
  }, [height, width]);

  return <div className='loader-animation' style={style} ref={element} />;
};

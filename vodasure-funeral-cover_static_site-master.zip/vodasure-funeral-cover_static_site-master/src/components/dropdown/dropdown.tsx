import React, { useState, useContext, FocusEvent } from 'react';
import { getIn, FormikProps } from 'formik';
import get from 'lodash.get';
import { AppContext } from '@/context';
import './dropdown.scss';

interface Props<T> {
  name: string;
  options: { label: string; value: string }[];
  formik: FormikProps<T>;
  [x: string]: unknown;
}

export const Dropdown = <T extends object>({
  name,
  options,
  ...props
}: Props<T>) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const [indexSelected, setIndexSelected] = useState<number>(-1);
  const { familyDetails } = useContext(AppContext);

  const { formik, ...restProps } = props;

  function handleOnBlur(e: FocusEvent<HTMLInputElement>) {
    setTimeout(() => setIsDropdownOpen(false), 200);
    formik.handleBlur(e);
  }

  function handleClick() {
    setIsDropdownOpen(true);
  }

  function handleItemClick(value: string, index: number) {
    formik.setFieldValue(name, value);
    setIsDropdownOpen(false);
    if (indexSelected === index) {
      setIndexSelected(-1);
    } else {
      setIndexSelected(index);
    }
  }

  function getValue() {
    const value = getIn(formik.values, name);
    if (value?.includes('.')) {
      const member = get(familyDetails, value);
      return `${member.firstName} ${member.surname} (${value.substring(
        0,
        value.indexOf('.')
      )})`;
    }
    return options.find(option => option?.value === value)?.label;
  }

  return (
    <>
      <input
        name={name}
        type='text'
        onChange={formik.handleChange}
        onBlur={handleOnBlur}
        onClick={handleClick}
        value={options[indexSelected]?.label || getValue()}
        {...restProps}
        className={`${
          getIn(formik.touched, name) &&
          getIn(formik.errors, name) &&
          'is-warning'
        }`}
        readOnly
      />
      <span className='ddl-arrow' />
      {isDropdownOpen && (
        <div className='dropdown-wrapper'>
          <div className='dropdown-list'>
            {options.map(({ label, value }, index) => (
              <p
                key={value}
                className={`dropdown-item ${
                  indexSelected === index && 'selected'
                }`}
                onClick={() => handleItemClick(value, index)}
              >
                {label}
              </p>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

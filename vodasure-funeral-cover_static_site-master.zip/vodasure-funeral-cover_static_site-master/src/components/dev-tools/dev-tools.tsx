import React, { useState } from 'react';
import { ToolIcon } from '@/assets';
import {
  Environment,
  applicationDefaults,
  reloadEnvironmentConfig,
} from '@/utils';
import { Cache } from '@/services';
import { DevToolsForm } from '@/forms';
import { DevToolSettings, IEnvironment } from '@/types';
import { Button } from '../button/button';
import { Modal } from '../modal/modal';
import './dev-tools.scss';

type EnvironmentEntry<T> = { [K in keyof T]: T[K] };

export const DevTools = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [formValid, setFormValid] = useState<boolean>(false);
  const [formValues, setFormValues] = useState<DevToolSettings>({
    apiHost: 'dev',
    apiRequests: 'true',
    disableAnalytics: 'false',
    debugAnalytics: 'false',
  });
  const { radioOptions } = applicationDefaults;

  function onClick() {
    setOpenDialog(prev => !prev);
  }

  function onClickCancel() {
    setOpenDialog(false);
  }

  function onClickConfirm() {
    Cache.save('debugConfig', formValues);
    reloadEnvironmentConfig();
    setOpenDialog(false);
    window.location.reload();
  }

  const initialValues = Cache.fetch('debugConfig') || {
    apiHost: 'https://apidev.vodacom.co.za/cloud',
    apiRequests: 'true',
    disableAnalytics: 'false',
    debugAnalytics: 'false',
  };

  return (
    <>
      <Modal onClickClose={onClickCancel} show={openDialog} type='xlarge'>
        <p className='dialog-heading'>Developer Tools</p>
        <div className='dev-tools-content'>
          <div className='env-container'>
            <p className='env-heading'>{Environment.current.name}</p>
            <ul>
              {Object.entries<string | boolean>(
                Environment.current as EnvironmentEntry<IEnvironment>
              ).map(([key, value], index) => (
                <li className='env-item' key={index}>
                  <p className='env-item-title'>{`${key}:`}</p>
                  <p className='env-item-text'>{value.toString()}</p>
                </li>
              ))}
            </ul>
          </div>
          <DevToolsForm
            initialValues={initialValues}
            formValid={setFormValid}
            formValues={setFormValues}
            radioOptions={radioOptions}
          />
        </div>
        <section className='dialog-button-group'>
          <Button onClick={onClickCancel} secondary>
            Cancel
          </Button>
          <Button onClick={onClickConfirm} disabled={!formValid} primary>
            Update
          </Button>
        </section>
      </Modal>

      <div onClick={onClick} className='dev-tools-button'>
        <img src={ToolIcon} alt='tool' />
      </div>
    </>
  );
};

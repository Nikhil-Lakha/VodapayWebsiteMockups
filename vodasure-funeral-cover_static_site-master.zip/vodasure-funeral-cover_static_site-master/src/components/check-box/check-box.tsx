import React, { useState, useEffect, ChangeEvent } from 'react';
import { FormikProps, getIn } from 'formik';
import './check-box.scss';

interface Props<T> {
  id: string;
  name: string;
  label: string;
  handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
  formik: FormikProps<T>;
}

export const CheckBox = <T extends object>({
  id,
  name,
  label,
  handleChange,
  formik,
}: Props<T>) => {
  const [inputProps, setInputProps] = useState({ checked: false });
  useEffect(() => {
    if (formik) {
      setInputProps(prevInputProps => ({
        ...prevInputProps,
        checked: getIn(formik.values, name),
      }));
    } else {
      setInputProps({ checked: false });
    }
  }, [formik, name]);

  return (
    <label className='checkbox-field' htmlFor={id}>
      {label}
      <input
        type='checkbox'
        id={id}
        name={name}
        onChange={handleChange}
        {...inputProps}
      />
      <span className='check-mark' />
    </label>
  );
};

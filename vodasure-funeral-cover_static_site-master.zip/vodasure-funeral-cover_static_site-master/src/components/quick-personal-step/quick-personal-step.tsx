import React, { useContext } from 'react';
import { AppContext, CoverContext } from '@/context';
import { PersonalDetailsForm } from '@/forms';

export const QuickPersonalStep = () => {
  const { personalDetails } = useContext(AppContext);
  const { setFormValid, setFormValues } = useContext(CoverContext);

  const initialValues = {
    firstName: personalDetails?.firstName || '',
    surname: personalDetails?.surname || '',
    cellphoneNumber: personalDetails?.cellphoneNumber || '',
    dateOfBirth: personalDetails?.dateOfBirth || '',
  };

  return (
    <>
      <h2 className='heading-2'>Let&apos;s get to know you a little better</h2>
      <PersonalDetailsForm
        validForm={setFormValid}
        formValues={setFormValues}
        initialValues={initialValues}
        small
      />
    </>
  );
};

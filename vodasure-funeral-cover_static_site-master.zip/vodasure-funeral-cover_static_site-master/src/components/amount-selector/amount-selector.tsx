import React, { useContext, useEffect } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { RadioButton } from '@/components';
import { AppContext } from '@/context';
import './amount-selector.scss';
import { TealiumService } from '@/services';

const validationSchema = Yup.object().shape({
  coverAmount: Yup.string().required('Required'),
});

interface Props {
  buttonArray: { label: string; value: string }[];
  name: string;
  initialValues: any;
}

export const AmountSelector = ({ buttonArray, name, initialValues }: Props) => {
  const { setProductDetails } = useContext(AppContext);
  const formik = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: () => {},
  });

  useEffect(() => {
    if (formik.values?.coverAmount) {
      TealiumService.onAmountSelected(formik.values?.coverAmount);
      setProductDetails(prev => ({
        ...prev,
        coverAmount: formik.values?.coverAmount,
      }));
    }
  }, [setProductDetails, formik.values?.coverAmount]);

  return (
    <form className='amount-selector-group'>
      {buttonArray.map(({ label, value }, index) => (
        <RadioButton
          id={`${index}`}
          key={index}
          name={name}
          value={value}
          label={label}
          formik={formik}
        />
      ))}
    </form>
  );
};

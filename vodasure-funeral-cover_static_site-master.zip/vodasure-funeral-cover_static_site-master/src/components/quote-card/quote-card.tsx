/* eslint-disable complexity */
import React, { useEffect, useState } from 'react';
import { journeys, formatCurrency, applicationDefaults } from '@/utils';
import {
  PersonalDetails,
  ProductDetails,
  AddOns,
  PaymentDetails,
  FamilyDetails,
  PaymentMethods,
} from '@/types';
import { Button } from '@/components';
import { UserIcon } from '@/assets';
import './quote-card.scss';

interface Props {
  product: ProductDetails;
  personal: PersonalDetails;
  payment?: PaymentDetails;
  family: FamilyDetails;
  selectedAddOns: AddOns;
  defaultAddOns?: AddOns;
  onClickEdit?: () => void;
  step?: 'quote' | 'summary';
}

export const QuoteCard = ({
  product,
  personal,
  payment,
  family,
  selectedAddOns,
  defaultAddOns,
  onClickEdit,
  step,
}: Props) => {
  const [numFamilyMembers, setNumFamilyMembers] = useState<number>(0);
  const { firstName, surname, age, cellphoneNumber } = personal;
  const { coverAmount, basePremium, totalPremium, coverType, addOns } = product;
  const [quoteAddOns, setQuoteAddOns] = useState<AddOns>(
    defaultAddOns || { funeral: {}, dataReward: {} }
  );
  const { paymentTypes } = applicationDefaults;

  useEffect(() => {
    if (selectedAddOns && Object.values(selectedAddOns).length > 0) {
      setQuoteAddOns(selectedAddOns);
    }
  }, [selectedAddOns]);

  useEffect(() => {
    const sum = Object.values(
      family as { spouse: []; child: []; extended: [] }
    ).reduce((acc: number, member: []) => {
      const add: number = acc + member.length;
      return add;
    }, 0);
    setNumFamilyMembers(sum);
  }, [family]);

  return (
    <article className='quote-card'>
      <header>
        <img src={UserIcon} alt='user' />
        <section>
          <h3>
            {coverType === journeys.family ? 'Family' : 'Individual'} funeral
            cover
          </h3>
        </section>
        {onClickEdit && (
          <Button onClick={() => onClickEdit()} quaternary rounded>
            Edit
          </Button>
        )}
      </header>
      <section className='card-content'>
        <div className='card-content-personal'>
          <section className='card-content-item'>
            <p className='label'>Full name:</p>
            <p className='value'>
              {firstName} {surname}
            </p>
          </section>

          <section className='card-content-item'>
            <p className='label'>Age:</p>
            <p className='value'>{age}</p>
          </section>

          <section className='card-content-item'>
            <p className='label'>Cellphone number:</p>
            <p className='value'>{cellphoneNumber}</p>
          </section>

          {step === 'summary' && (
            <>
              <section className='card-content-item'>
                <p className='label'>Email address:</p>
                <p className='value'>{personal.email}</p>
              </section>

              <section className='card-content-item'>
                <p className='label'>Payment method:</p>
                <p className='value'>
                  {
                    paymentTypes.find(
                      type => type.value === payment?.paymentMethod
                    )?.label
                  }
                </p>
              </section>
              {product.coverStart !== '' &&
                payment?.paymentMethod === PaymentMethods.debitOrder && (
                  <section className='card-content-item'>
                    <p className='label'>Cover start date:</p>
                    <p className='value'>{product.coverStart}</p>
                  </section>
                )}
            </>
          )}
        </div>

        {coverType === journeys.family && (
          <>
            <section className='card-content-item'>
              <p className='label'>You</p>
              <p className='value bold'>
                {formatCurrency(coverAmount, { trailingZeroDisplay: 'stripIfInteger' })} cover
              </p>
            </section>
            {family?.spouse && family?.spouse?.length > 0 && (
              <section className='card-content-item'>
                <p className='family-label'>1 Spouse (18-74)</p>
                <p className='value'>
                  {formatCurrency(family?.spouse[0].coverAmount, { trailingZeroDisplay: 'stripIfInteger' })}{' '}
                  cover
                </p>
              </section>
            )}
            {family?.child && family?.child?.length > 0 && (
              <section className='card-content-item'>
                <p className='family-label'>
                  {family.child.length} Children (0-18)
                </p>
                <p className='value'>
                  {formatCurrency(
                    family.child.length * Number(coverAmount), { trailingZeroDisplay: 'stripIfInteger' }
                  )}{' '}
                  cover
                </p>
              </section>
            )}
            {family?.extended && family?.extended?.length > 0 && (
              <section className='card-content-item'>
                <p className='family-label'>
                  {family.extended.length} Extended family (18-74)
                </p>
                <p className='value'>
                  {formatCurrency(
                    family.extended.reduce(
                      (acc, value) => acc + Number(value.coverAmount),
                      0
                    ), { trailingZeroDisplay: 'stripIfInteger' }
                  )}{' '}
                  cover
                </p>
              </section>
            )}
          </>
        )}

        {coverType === journeys.individual && (
          <section className='card-content-item'>
            <p className='label'>Your cover:</p>
            <p className='value bold'>
              {formatCurrency(coverAmount, { trailingZeroDisplay: 'stripIfInteger' })}
            </p>
          </section>
        )}
        <section className='card-content-item underline'>
          <p className='label'>Monthly premium:</p>
          <p className='value bold'>{formatCurrency(basePremium || 0)}</p>
        </section>
        {Object.values(quoteAddOns).some(value => value.state === true) && (
          <section className='card-content-item underline mobile-column'>
            <p className='label'>Monthly addons:</p>
            <div className='add-on-section'>
              {quoteAddOns?.funeral.state && (
                <>
                  <p>Funeral Assistance</p>
                  <p className='amount'>
                    {formatCurrency(Number(addOns?.funeral?.cost) || 0)}
                  </p>
                </>
              )}
              {quoteAddOns?.dataReward.state && (
                <>
                  <p>Data Benefit</p>
                  <p className='amount'>
                    {formatCurrency(Number(addOns?.dataReward?.cost) || 0)}
                  </p>
                </>
              )}
            </div>
          </section>
        )}
      </section>

      <footer>
        <div className='quote-footer-content'>
          <p>
            {numFamilyMembers + 1 > 1
              ? `${numFamilyMembers + 1} lives`
              : `${numFamilyMembers + 1} life`}{' '}
            - Cover can be cancelled anytime
          </p>
          {onClickEdit && (
            <button
              className='edit-button'
              type='button'
              onClick={() => onClickEdit()}
            >
              Edit
            </button>
          )}
        </div>
        <section className='total-premium'>
          <p>Total premium:</p>
          <p className='total-premium-amount'>
            {formatCurrency(totalPremium || 0)} per month
          </p>
        </section>
      </footer>
    </article>
  );
};

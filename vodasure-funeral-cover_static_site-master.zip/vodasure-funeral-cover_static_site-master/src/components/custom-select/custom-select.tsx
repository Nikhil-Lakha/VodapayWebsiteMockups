import React, { useState, useMemo, useContext, useEffect } from 'react';
import { FormikProps, getIn } from 'formik';
import Select, {
  components,
  OptionProps,
  DropdownIndicatorProps,
} from 'react-select';
import { AppContext } from '@/context';
import get from 'lodash.get';
import { IconCaretDown } from '@/assets';
import { Tip } from '../tip/tip';
import './custom-select.scss';

const Option = (props: OptionProps<{ label: string; value: string }>) => (
  <div>
    <components.Option {...props} />
  </div>
);

const DropdownIndicator = (
  props: DropdownIndicatorProps<{ label: string; value: string }>
) => (
  <components.DropdownIndicator {...props} className='indicator-container'>
    <img src={IconCaretDown} />
  </components.DropdownIndicator>
);

interface Props<T> {
  label: string;
  placeholder: string;
  options: { label: string; value: string }[];
  name: string;
  formik: FormikProps<T>;
  tip?: string;
  disabled?: boolean;
  required?: boolean;
}

export const CustomSelect = <T extends object>({
  label,
  placeholder,
  options,
  name,
  formik,
  tip,
  disabled = false,
  required = false,
}: Props<T>) => {
  const { familyDetails } = useContext(AppContext);
  const [showWarning, setShowWarning] = useState<boolean>(false);

  useMemo(() => {
    setShowWarning(getIn(formik.touched, name) && getIn(formik.errors, name));
  }, [formik.touched, formik.errors, name]);

  function handleChange(newValue: any) {
    if (!Array.isArray(newValue)) {
      formik.setFieldValue(name, newValue.value);
    }
  }

  function handleBlur() {
    formik.setFieldTouched(name, true, true);
  }

  function getValue() {
    const value = getIn(formik.values, name);

    if (value?.includes('.') && !value.startsWith('http')) {
      const memberIndex = value.split('.').at(-1);
      const memberType = value.split('.').at(0);
      const member = get(familyDetails, value);

      const memberLabel = `${member.firstName} ${
        member.surname
      } (${value.substring(0, value.indexOf('.'))})`;
      const memberValue = `${memberType}.${memberIndex}`;
      return { label: memberLabel, value: memberValue };
    }
    if (value) {
      const memberLabel =
        options.find(option => option?.value === value)?.label || value;
      return { label: memberLabel, value };
    }
  }

  return (
    <div className='input-field'>
      <label className='input-label'>{label ? label : '\u00A0'}</label>
      <Select
        name={name}
        components={{ Option, DropdownIndicator }}
        isSearchable
        placeholder={placeholder}
        onChange={handleChange}
        onBlur={handleBlur}
        value={getValue()}
        styles={{
          option: (base, { isFocused, isSelected }) => ({
            ...base,
            display: 'flex',
            height: '48px',
            maxWidth: '646px',
            width: '100%',
            backgroundColor: isFocused || isSelected ? '#EBEDEF' : undefined,
            color: 'black',
            fontSize: '16px',
            padding: '12px 24px',
            cursor: 'pointer',
            ':after': isSelected
              ? {
                  height: '24px',
                  width: '24px',
                  content: "'\u2713'",
                  display: 'inline-block',
                  color: 'green',
                  padding: '0 6px 0 6px',
                  marginLeft: 'auto',
                }
              : { ...base[':after'] },
            '@media screen and (max-width: 576px)': {
              fontSize: '16px',
              padding: '12px 12px',
              ':after': isSelected
                ? {
                    height: '20px',
                    width: '20px',
                  }
                : { ...base[':after'] },
            },
            '@media screen and (max-width: 320px)': {
              fontSize: '12px',
            },
          }),
          container: base => ({
            ...base,
            marginBottom: '0.5rem',
          }),
          valueContainer: base => ({
            ...base,
            paddingLeft: '1rem',
            fontSize: '16px',
            '@media screen and (max-width: 320px)': {
              fontSize: '14px',
              paddingLeft: '0.5rem',
            },
          }),
          placeholder: base => ({
            // ...base,
            fontSize: '16px',
            color: 'gray',
            fontWeight: 400,
            position: 'absolute',
            paddingLeft: '1rem',
          }),
          control: base => ({
            ...base,
            borderRadius: '8px',
            border: showWarning ? '0.6px solid #e60000' : '0.6px solid #a8acb8',
            height: '56px',
          }),
          indicatorSeparator: base => ({
            ...base,
            display: 'none',
          }),
          menu: base => ({
            ...base,
            zIndex: '40',
          }),
          menuList: base => ({
            ...base,
            scrollbarWidth: 'thin',
            scrollbarColor: '#393949 #c9ccd4',
            '::-webkit-scrollbar': {
              width: '4px',
            },
            '::-webkit-scrollbar-track': {
              background: '#c9ccd4',
              borderRadius: '4px',
            },
            '::-webkit-scrollbar-thumb': {
              background: '#393949',
              borderRadius: '4px',
              cursor: 'pointer',
            },
            '::-webkit-scrollbar-thumb:hover': {
              background: '#393949',
            },
          }),
        }}
        classNames={{
          valueContainer: state => 'custom-select-input',
        }}
        options={options}
        isDisabled={disabled}
        required={required}
      />
      {getIn(formik.touched, name) && getIn(formik.errors, name) ? (
        <Tip text={getIn(formik.errors, name)} type='warning' />
      ) : (
        tip && <Tip text={tip} type='info' />
      )}
    </div>
  );
};

import React, { useContext } from 'react';
import { AppContext, CoverContext } from '@/context';
import { TealiumService } from '@/services';
import { PremiumCard, AddFamily } from '@/components';

export const QuickQuoteStep = () => {
  const {
    personalDetails,
    isFamilyJourney,
    setIsFamilyJourney,
    familyDetails,
  } = useContext(AppContext);
  const { setEditDetails, setFamilyFormValid, setShowQRModal } =
    useContext(CoverContext);

  const initialFamilyValues = {
    spouse: familyDetails?.spouse || [],
    child: familyDetails?.child || [],
    extended: familyDetails?.extended || [],
  };

  const handleShowModal = () => {
    TealiumService.onQuoteInteract();
    setShowQRModal(true);
  };
  const handleShowFamily = () => {
    setIsFamilyJourney(() => !isFamilyJourney);
  };
  const handleEditDetails = () => {
    setEditDetails(true);
  };

  return (
    <>
      <PremiumCard
        onClick={handleShowModal}
        showFamily={handleShowFamily}
        editDetails={handleEditDetails}
        familyCoverActive={isFamilyJourney}
        details={personalDetails}
      />
      {isFamilyJourney && (
        <AddFamily
          validForm={setFamilyFormValid}
          initialValues={initialFamilyValues}
        />
      )}
    </>
  );
};

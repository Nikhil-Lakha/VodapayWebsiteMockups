import React, {
  useState,
  useEffect,
  useRef,
  ChangeEvent,
  FocusEvent,
} from 'react';
import { FormikProps, getIn } from 'formik';
import { Calendar } from 'react-date-range';
import { DateTime } from 'luxon';
import MaskedInput from 'react-text-mask';
import classNames from 'classnames';
import { masks } from '@/utils';
import { CalendarIcon } from '@/assets';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import './date-picker.scss';

interface Props<T> {
  name: string;
  formik: FormikProps<T>;
  disabled: boolean;
  [x: string]: unknown;
}

// eslint-disable-next-line comma-spacing
export const DatePicker = <T extends object>({
  name,
  formik,
  disabled,
  ...restProps
}: Props<T>) => {
  const [calendarDate, setCalendarDate] = useState<Date>();
  const [showCalendar, setShowCalendar] = useState(false);
  const calendarRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const datePickerValue = getIn(formik.values, name);

  const datePickerIconClass = classNames('datepicker-icon', {
    'is-disabled': disabled,
  });

  useEffect(() => {
    if (calendarDate && showCalendar) {
      setShowCalendar(false);
    }
  }, [calendarDate]);

  useEffect(() => {
    if (showCalendar) {
      formik.setFieldTouched(name, true, false);
    }
  }, [datePickerValue]);

  useEffect(() => {
    const listener = (event: Event) => {
      if (
        !calendarRef.current ||
        calendarRef.current.contains(event.target as HTMLDivElement) ||
        !imageRef.current ||
        imageRef.current.contains(event.target as HTMLImageElement)
      ) {
        return;
      }
      setShowCalendar(false);
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);

    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [imageRef, calendarRef]);

  function handleSelectDate(date: Date) {
    setCalendarDate(date);
    const dateTime = DateTime.fromJSDate(date);
    const stringDate = dateTime.setLocale('en-ZA').toFormat('yyyy-MM-dd');
    formik.setFieldValue(name, stringDate);
  }

  function handleOnBlur(event: FocusEvent<HTMLInputElement>) {
    const maskedDate = DateTime.fromFormat(event.target.value, 'yyyy/MM/dd');
    if (maskedDate.isValid) {
      const jsDate = new Date(maskedDate.toLocaleString());
      setCalendarDate(jsDate);
    }
    formik.handleBlur(event);
  }

  function handleOnChange(event: ChangeEvent<HTMLInputElement>) {
    if (event.target.value === '') {
      formik.setFieldValue(name, '');
      setCalendarDate(new Date());
    }
    const maskedDate = DateTime.fromFormat(event.target.value, 'yyyy/MM/dd');
    if (maskedDate.isValid) {
      const stringDate = maskedDate.setLocale('en-ZA').toFormat('yyyy-MM-dd');
      formik.setFieldValue(name, stringDate);
    }
  }

  function getValue() {
    const formikDateValue = getIn(formik.values, name);
    const isoDate = DateTime.fromISO(formikDateValue);
    const stringDate = isoDate.setLocale('en-ZA').toLocaleString();
    return stringDate;
  }

  return (
    <>
      {showCalendar && !disabled && (
        <div ref={calendarRef}>
          <Calendar
            date={calendarDate}
            onChange={item => handleSelectDate(item)}
            maxDate={new Date()}
          />
        </div>
      )}
      <MaskedInput
        name={name}
        type='text'
        inputMode='text'
        autoComplete='bday'
        onChange={handleOnChange}
        onBlur={handleOnBlur}
        mask={masks.date}
        value={getValue()}
        placeholder='yyyy /mm /dd'
        className={`${
          getIn(formik.touched, name) &&
          getIn(formik.errors, name) &&
          'is-warning'
        }`}
        disabled={disabled}
        {...restProps}
      />
      <img
        ref={imageRef}
        className={datePickerIconClass}
        onClick={() => setShowCalendar(prev => !prev)}
        src={CalendarIcon}
        alt='calender'
      />
    </>
  );
};

import React from 'react';
import classNames from 'classnames';
import './button.scss';

interface Props {
  children: React.ReactNode;
  onClick: () => void;
  primary?: boolean;
  secondary?: boolean;
  tertiary?: boolean;
  quaternary?: boolean;
  matchInput?: boolean;
  rounded?: boolean;
  [x: string]: any;
}

export const Button = ({
  children,
  onClick,
  primary,
  secondary,
  tertiary,
  quaternary,
  rounded,
  matchInput,
  ...props
}: Props) => {
  const btnClass = classNames('custom-button', {
    'is-primary': primary,
    'is-secondary': secondary,
    'is-tertiary': tertiary,
    'is-quaternary': quaternary,
    'match-input': matchInput,
    rounded,
  });
  return (
    <button type='button' {...props} onClick={onClick} className={btnClass}>
      {children}
    </button>
  );
};

import React from 'react';
import classNames from 'classnames';
import './switch.scss';

interface Props {
  label: string;
  onClick: () => void;
  alignLeft?: boolean;
  active: boolean;
  disabled?: boolean
}

export const Switch = ({ label, onClick, alignLeft, active, disabled }: Props) => {
  const switchClass = classNames('switch-container', {
    'align-left': alignLeft && !disabled,
  });
  return (
    <section className={switchClass}>
      {!disabled &&
      <label className='switch'>
        <input
          type='checkbox'
          onClick={() => onClick()}
          defaultChecked={active}
        />
        <span className='slider' />
      </label>
      }
      <p className={classNames('label', { disabled })}>{label}</p>
    </section>
  );
};

import React from 'react';
import { Modal } from '../modal/modal';
import { Button } from '../button/button';
import { ErrorCircle, SuccessCircle } from '@/assets';
import classNames from 'classnames';
import { ICallMeBackStatus } from '@/types';

interface Props {
  status: ICallMeBackStatus;
  onClose: () => void;
  show: boolean;
}

export const CallMeBackStatus = ({ status, onClose, show }: Props) => {
  const imgClass = classNames({
    'error circle': status === ICallMeBackStatus.rejected,
    'green check mark': status === ICallMeBackStatus.accepted,
  });

  const data: {
    [key: string]: { heading: string; subtext: string; icon: string };
  } = {
    rejected: {
      heading: 'Oops...',
      subtext: 'We were unable to submit your request. Please try again later.',
      icon: ErrorCircle,
    },
    accepted: {
      heading: 'Thank you',
      subtext:
        "Your application has been submitted. We'll be in touch shortly.",
      icon: SuccessCircle,
    },
  };
  return (
    <Modal onClickClose={onClose} show={show} type='dialog'>
      <>
        <img
          src={status === ICallMeBackStatus.unset ? '' : data[status].icon}
          alt={imgClass}
        />
        <p className='dialog-heading'>
          {status === ICallMeBackStatus.unset ? '' : data[status].heading}
        </p>
        <p className='dialog-subtext'>
          {status === ICallMeBackStatus.unset ? '' : data[status].subtext}
        </p>
        <Button onClick={onClose} primary>
          Okay
        </Button>
      </>
    </Modal>
  );
};

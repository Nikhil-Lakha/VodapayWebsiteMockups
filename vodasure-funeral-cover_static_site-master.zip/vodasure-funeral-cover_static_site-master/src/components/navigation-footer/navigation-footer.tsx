/* eslint-disable react/no-multi-comp */
import React from 'react';
import { Button } from '../button/button';
import './navigation-footer.scss';

interface Props {
  onBack?: () => void;
  onNext: () => void;
  nextEnabled: boolean;
  nextButtonLabel: string;
  backButtonLabel?: string;
  hideBack?: boolean;
  hideNext?: boolean;
}

export const NavigationFooter = ({
  // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
  onBack = () => {},
  onNext,
  nextEnabled,
  nextButtonLabel,
  backButtonLabel,
  hideBack = false,
  hideNext = false,
}: Props) => (
  <footer className='NavigationFooter'>
    <section className='btn-placeholder'>
      {!hideBack && (
        <Button onClick={onBack} tertiary>
          {backButtonLabel || 'Back'}
        </Button>
      )}
    </section>
    <section className='btn-placeholder'>
      {!hideNext && (
        <Button onClick={onNext} disabled={!nextEnabled} primary>
          {nextButtonLabel || 'Next'}
        </Button>
      )}
    </section>
  </footer>
);

import React from 'react';
import './terms-and-conditions.scss';

interface Props {
  children: React.ReactNode;
}

export const TermsAndConditions = ({ children }: Props) => (
  <section className='terms-and-conditions'>{children}</section>
);

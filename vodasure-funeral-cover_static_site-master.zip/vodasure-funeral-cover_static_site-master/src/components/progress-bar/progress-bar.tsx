import React from 'react';
import { BsCheck } from 'react-icons/bs';
import classNames from 'classnames';

interface Props {
  isStart?: boolean;
  isEnd?: boolean;
  isActive?: boolean;
  isComplete?: boolean;
  progressLeft: number;
  progressRight: number;
  stepNumber?: number;
}

export const ProgressBar = ({
  isStart,
  isEnd,
  isActive,
  isComplete,
  // cumulative progress halfway to left of the step (from 0 - 100).
  progressLeft,
  // cumulative progress halfway to the right of the step (from 0 - 100).
  progressRight,
  stepNumber,
}: Props) => {
  const progressStepClass = classNames('progress-step', {
    completed: isComplete,
    active: isActive,
  });

  const progressStepInner = classNames('progress-step-inner', {
    completed: isComplete,
    active: isActive,
  });

  return (
    <div className='columns is-gapless is-vcentered'>
      <div className='column'>
        <div className='step-bar'>
          {isStart ? (
            <div className='step-spacer' style={{ width: 'calc(50}%)' }} />
          ) : (
            <>
              <div
                className='step-progress'
                style={{ width: `calc(${progressLeft}%)` }}
              />
              <div
                className='step-spacer right-side-border-radius-2px'
                style={{ width: `calc(${Math.max(0, 100 - progressLeft)}%)` }}
              />
            </>
          )}
        </div>
      </div>

      <div className='column is-narrow'>
        <div className={progressStepClass}>
          <div className={progressStepInner}>
            {isComplete && <BsCheck className='icon-check-mark' />}
            {isActive && <div className='step-number'>{stepNumber}</div>}
          </div>
        </div>
      </div>

      <div className='column'>
        <div className='step-bar'>
          {isEnd ? (
            <div className='step-spacer' style={{ width: 'calc(50}%)' }} />
          ) : (
            <>
              <div
                className='step-progress left-side-border-radius-2px'
                style={{ width: `calc(${progressRight}%)` }}
              />
              <div
                className='step-spacer'
                style={{ width: `calc(${Math.max(0, 100 - progressRight)}%)` }}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

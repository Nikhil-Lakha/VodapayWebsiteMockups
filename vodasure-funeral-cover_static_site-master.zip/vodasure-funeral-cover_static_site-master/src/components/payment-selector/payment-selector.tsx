import React, { ChangeEvent } from 'react';
import './payment-selector.scss';

interface Props {
  id: string;
  value: string;
  src: string;
  label: string;
  title: string;
  handleChange: (event: ChangeEvent<HTMLInputElement>) => void;
}

export const PaymentSelector = ({
  id,
  value,
  src,
  label,
  title,
  handleChange,
}: Props) => (
  <section className='payment-selector-group'>
    <input
      type='radio'
      id={id}
      name='paymentSelector'
      value={value}
      onChange={handleChange}
    />

    <label htmlFor={id}>
      <img src={src} alt='icon' />
      <p>
        {label} <span>{title}</span>
      </p>
    </label>
  </section>
);

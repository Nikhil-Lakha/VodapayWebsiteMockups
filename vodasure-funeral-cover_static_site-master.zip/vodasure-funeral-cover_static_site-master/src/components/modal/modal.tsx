import React, { useEffect, useRef } from 'react';
import classNames from 'classnames';
import { Overlay } from '@/components';
import { ModalCloseIcon } from '@/assets/icons';
import './modal.scss';

interface Props {
  children: React.ReactNode;
  onClickClose: () => void;
  onOpen?: () => void;
  type?: 'small' | 'large' | 'dialog' | 'xlarge';
  editModal?: boolean;
  show: boolean;
}

export const Modal = ({
  children,
  onClickClose,
  onOpen,
  type = 'small',
  editModal,
  show,
}: Props) => {
  const isMounted = useRef(false);

  const modalClass = classNames('modal-container', {
    'is-small': type === 'small',
    'is-large': type === 'large',
    'is-xlarge': type === 'xlarge',
    'is-dialog': type === 'dialog',
    show,
    'edit-modal': editModal,
  });

  useEffect(() => {
    if (isMounted.current && show) {
      const root: HTMLElement | null = document.getElementById('root');
      const scrollY = window.scrollY;
      if (root) {
        root.classList.add('modal-fix');
        root.style.top = `-${scrollY}px`;
      }
      if (onOpen) {
        onOpen();
      }
    } else {
      isMounted.current = true;
    }
  }, [show, onOpen]);

  function cleanUp() {
    const root: HTMLElement | null = document.getElementById('root');

    if (root) {
      const scrollY = root.style.top;

      root.classList.remove('modal-fix');
      root.style.top = '';

      window.scrollTo(0, parseInt(scrollY || '0', 10) * -1);
    }
  }

  useEffect(() => {
    if (!show && isMounted.current) {
      cleanUp();
    }
  }, [show]);

  return (
    <Overlay onClick={onClickClose} show={show}>
      <section className={modalClass} onClick={e => e.stopPropagation()}>
        <img
          src={ModalCloseIcon}
          alt='close'
          className='close-icon'
          onClick={onClickClose}
        />
        {children}
      </section>
    </Overlay>
  );
};

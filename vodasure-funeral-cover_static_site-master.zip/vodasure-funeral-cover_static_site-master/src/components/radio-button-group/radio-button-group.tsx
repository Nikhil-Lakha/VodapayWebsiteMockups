import React from 'react';
import { FormikProps } from 'formik';
import { RadioButton } from '@/components';
import classNames from 'classnames';
import './radio-button-group.scss';

interface Props<T> {
  buttonArray: { label: string; value: string; disabled?: boolean }[];
  name: string;
  formik: FormikProps<T>;
  complex?: boolean;
  type?: 'row' | 'column';
  column?: boolean;
}

export const RadioButtonGroup = <T extends object>({
  buttonArray,
  name,
  formik,
  type = 'row',
}: Props<T>) => {
  const radioBtnGroupClass = classNames('radio-button-group', {
    'is-column': type === 'column',
    'is-row': type === 'row',
  });

  return (
    <section className={radioBtnGroupClass}>
      {buttonArray.map(({ label, value }, index) => (
        <RadioButton
          id={`${name}-${index}`}
          key={index}
          name={name}
          value={value}
          label={label}
          formik={formik}
          disabled={buttonArray[index]?.disabled}
          type={type}
        />
      ))}
    </section>
  );
};

import React, { useEffect, useState } from 'react';
import { getIn, FormikProps } from 'formik';
import classNames from 'classnames';
import './radio-button.scss';

interface Props<T> {
  id: string;
  value: string;
  name: string;
  label: string;
  disabled?: boolean;
  formik: FormikProps<T>;
  type?: 'column' | 'row';
}

export const RadioButton = <T extends object>({
  id,
  value,
  name,
  label,
  disabled,
  formik,
  type,
}: Props<T>) => {
  const [inputProps, setInputProps] = useState({ checked: false });

  const radioFieldClass = classNames('radio-field', {
    'is-column': type === 'column',
    'is-row': type === 'row',
  });

  useEffect(() => {
    if (formik) {
      setInputProps(prevInputProps => ({
        ...prevInputProps,
        checked: getIn(formik.values, name) === value,
      }));
    } else {
      setInputProps({ checked: false });
    }
  }, [formik, name, value]);

  return (
    <section className={radioFieldClass}>
      <input
        type='radio'
        id={id}
        name={name}
        value={value}
        onChange={formik.handleChange}
        disabled={disabled}
        {...inputProps}
      />
      <label className={`${disabled && 'disabled'} `} htmlFor={id}>
        {label}
      </label>
      <span className={`checkmark ${disabled && 'disabled'}`} />
    </section>
  );
};

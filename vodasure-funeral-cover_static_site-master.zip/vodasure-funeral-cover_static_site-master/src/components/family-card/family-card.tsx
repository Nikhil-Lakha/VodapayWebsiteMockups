import React from 'react';
import './family-card.scss';

interface Props {
  memberType: string;
  label: string;
  children: React.ReactNode;
}

export const FamilyCard = ({ memberType, label, children }: Props) => (
  <article className='family-card'>
    <header>
      <h4>
        Add {memberType} <span>{label}</span>
      </h4>
    </header>
    {children}
  </article>
);

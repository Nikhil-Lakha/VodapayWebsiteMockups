import React from 'react';
import { JourneyStep } from '@/types';
import { stepGroups } from '@/utils';
import { ProgressBar } from '@/components';
import {
  BackArrowDark,
  VodaSureFuneralCoverLogo,
  VodaSureLogo,
} from '@/assets';
import './navigation-header.scss';

interface RenderStepsProps {
  section: string;
  steps: JourneyStep[];
  currentStep: JourneyStep;
}

const RenderSteps = ({ section, steps, currentStep }: RenderStepsProps) => {
  const currentGroup = currentStep?.group || currentStep?.step;
  const groups = steps
    .map(s => s.group || s.step)
    .filter((v, i, a) => a.indexOf(v) === i);
  const currentGroupIdx = groups.findIndex(g => g === currentGroup);

  switch (section) {
    case 'bars':
      return (
        <>
          {groups.map((group, idx) => (
            <div className='column' key={`step-${idx}`}>
              <ProgressBar
                isStart={idx === 0}
                isEnd={idx === groups.length - 1}
                isActive={group === currentGroup}
                isComplete={idx < currentGroupIdx}
                stepNumber={idx + 1}
                progressLeft={idx > currentGroupIdx ? 0 : 100}
                progressRight={idx > currentGroupIdx ? 0 : 100}
              />
            </div>
          ))}
        </>
      );
    case 'labels':
      return (
        <>
          {groups.map((group, idx) => (
            <div className='column ' key={`step-name-${idx}`}>
              <div
                className={`has-text-centered step-label ${
                  group === currentGroup ? 'active' : ''
                }`}
              >
                {stepGroups[group]}
              </div>
            </div>
          ))}
        </>
      );
    case 'mobile':
      return (
        <>
          <div className='has-padding-4'>
            <div className='current-step-heading-mobile'>
              {`Step ${currentGroupIdx + 1} of ${groups.length}`}
            </div>
            <div className='step-name-heading-mobile is-4 has-margin-0'>
              {stepGroups[currentGroup]}
            </div>
          </div>
          <div className='columns is-mobile is-gapless mobile-progress'>
            {groups.map((group, idx) => (
              <div className='column' key={`step-mobile-${idx}`}>
                <div
                  className={`mobile-step ${
                    idx <= currentGroupIdx ? 'completed' : ''
                  }`}
                />
              </div>
            ))}
          </div>
        </>
      );
    default:
      return <div />;
  }
};

interface NavigationHeaderProps {
  steps?: JourneyStep[];
  currentStep?: JourneyStep;
  onBack?: () => void;
  hideBack?: boolean;
}

export const NavigationHeader = ({
  steps,
  currentStep,
  onBack,
  hideBack = false,
}: NavigationHeaderProps) => (
  <header className='ProgressBar'>
    <section className='progress-block is-hidden-mobile'>
      <div className='vodapay-logo is-vcentered'>
        <img src={VodaSureFuneralCoverLogo} alt='VodaSure' />
      </div>
      <div className='progress-container'>
        {(steps && currentStep) &&
          <>
            <div className='columns is-gapless is-vcentered'>
              <RenderSteps section='bars' steps={steps} currentStep={currentStep} />
            </div>
            <div className='columns is-gapless step-label-columns'>
              <RenderSteps
                section='labels'
                steps={steps}
                currentStep={currentStep}
              />
            </div>
          </>
        }
      </div>
    </section>
    <section className='mobile-heading is-hidden-tablet'>
      {onBack && !hideBack && (
        <span className='mobile-back-arrow-button' onClick={onBack}>
          <img src={BackArrowDark} alt='Back' />
        </span>
      )}
      <span className='mobile-header-logo'>
        <img src={VodaSureLogo} alt='logo' />
      </span>
      <div className='progress-container'>
        {(steps && currentStep) && <RenderSteps section='mobile' steps={steps} currentStep={currentStep} />}
      </div>
    </section>
  </header>
);

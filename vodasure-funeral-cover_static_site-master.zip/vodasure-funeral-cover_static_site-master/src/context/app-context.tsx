/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
import React, { createContext, useState, useEffect, useRef } from 'react';
import { journeys, journeySteps, steps } from '@/utils';
import {
  PersonalDetails,
  ProductDetails,
  BeneficiaryDetails,
  PaymentDetails,
  FamilyDetails,
  Premium,
  JourneyStep,
  IAppContext,
} from '@/types';
import { Cache } from '@/services';

const initialState: IAppContext = {
  clearApplication: () => {},
  personalDetails: {},
  setPersonalDetails: () => {},
  productDetails: { coverType: 'individualCover' },
  setProductDetails: () => {},
  beneficiaryDetails: {},
  setBeneficiaryDetails: () => {},
  paymentDetails: {},
  setPaymentDetails: () => {},
  familyDetails: { spouse: [], child: [], extended: [] },
  setFamilyDetails: () => {},
  finalSteps: [],
  setFinalSteps: () => {},
  isFamilyJourney: false,
  setIsFamilyJourney: () => {},
  premiumOptions: [],
  setPremiumOptions: () => {},
  isAddToBill: false,
  setIsAddToBill: () => {},
  isVodacomCustomer: false,
  setIsVodacomCustomer: () => {},
  referralCode: '',
  setReferralCode: () => {}
};

export const AppContext = createContext(initialState);

interface AppContextProps {
  children: React.ReactNode;
}

export const AppContextProvider: React.FC<AppContextProps> = ({ children }) => {
  const [personalDetails, setPersonalDetails] = useState<PersonalDetails>({});
  const [beneficiaryDetails, setBeneficiaryDetails] =
    useState<BeneficiaryDetails>({});
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({});
  const [productDetails, setProductDetails] = useState<ProductDetails>({
    coverType: 'individualCover',
  });
  const [familyDetails, setFamilyDetails] = useState<FamilyDetails>({
    spouse: [],
    child: [],
    extended: [],
  });
  const [finalSteps, setFinalSteps] = useState<JourneyStep[]>(
    journeySteps.filter(step => step.group !== steps.family_details)
  );
  const [isFamilyJourney, setIsFamilyJourney] = useState<boolean>(false);
  const [premiumOptions, setPremiumOptions] = useState<Premium[]>([]);
  const [isAddToBill, setIsAddToBill] = useState<boolean>(false);
  const [isVodacomCustomer, setIsVodacomCustomer] = useState<boolean>(false);
  const [referralCode, setReferralCode] = useState<string>('');

  const isMounted = useRef(false);

  useEffect(() => {
    const cachedApp = Cache.fetch('application');
    if (cachedApp) {
      setPersonalDetails(cachedApp.personalDetails || {});
      setBeneficiaryDetails(cachedApp.beneficiaryDetails || {});
      setPaymentDetails(cachedApp.paymentDetails || {});
      setProductDetails(cachedApp.productDetails || {});
      setFamilyDetails(cachedApp.familyDetails || {});
      setIsFamilyJourney(
        cachedApp.productDetails.coverType === journeys.family
      );
      setPremiumOptions(cachedApp.premiumOptions || {});
      setIsAddToBill(cachedApp.isAddToBill);
      setIsVodacomCustomer(cachedApp.isVodacomCustomer);
      setReferralCode(cachedApp.referralCode);
    }
  }, []);

  useEffect(() => {
    if (isMounted.current) {
      Cache.save('application', {
        personalDetails,
        beneficiaryDetails,
        paymentDetails,
        productDetails,
        familyDetails,
        premiumOptions,
        isAddToBill,
        isVodacomCustomer,
        referralCode,
      });
    } else {
      isMounted.current = true;
    }
  }, [
    personalDetails,
    beneficiaryDetails,
    paymentDetails,
    productDetails,
    familyDetails,
    premiumOptions,
    isAddToBill,
    isVodacomCustomer,
    referralCode,
  ]);

  function clearApplication() {
    setPersonalDetails({});
    setBeneficiaryDetails({});
    setPaymentDetails({});
    setProductDetails({
      coverType: 'individualCover',
    });
    setFamilyDetails({
      spouse: [],
      child: [],
      extended: [],
    });
    setIsFamilyJourney(false);
    setPremiumOptions([]);
    setIsAddToBill(false);
    setIsVodacomCustomer(false);
    setReferralCode('');
  }

  return (
    <AppContext.Provider
      value={{
        clearApplication,
        personalDetails,
        setPersonalDetails,
        productDetails,
        setProductDetails,
        beneficiaryDetails,
        setBeneficiaryDetails,
        paymentDetails,
        setPaymentDetails,
        familyDetails,
        setFamilyDetails,
        finalSteps,
        setFinalSteps,
        isFamilyJourney,
        setIsFamilyJourney,
        premiumOptions,
        setPremiumOptions,
        isAddToBill,
        setIsAddToBill,
        isVodacomCustomer,
        setIsVodacomCustomer,
        referralCode,
        setReferralCode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

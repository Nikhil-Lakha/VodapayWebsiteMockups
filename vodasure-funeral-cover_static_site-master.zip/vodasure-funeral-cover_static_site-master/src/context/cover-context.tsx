/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
import React, { useState, createContext } from 'react';
import { Premium, PersonalDetails } from '@/types';

const initialState: {
  formValid: boolean;
  setFormValid: React.Dispatch<React.SetStateAction<boolean>>;
  formValues: PersonalDetails;
  setFormValues: React.Dispatch<React.SetStateAction<PersonalDetails>>;
  familyFormValid: boolean;
  setFamilyFormValid: React.Dispatch<React.SetStateAction<boolean>>;
  editDetails: boolean;
  setEditDetails: React.Dispatch<React.SetStateAction<boolean>>;
  showQRModal: boolean;
  setShowQRModal: React.Dispatch<React.SetStateAction<boolean>>;
  someFamilyMembers: boolean;
  setSomeFamilyMembers: React.Dispatch<React.SetStateAction<boolean>>;
  noFamilyMembers: boolean;
  setNoFamilyMembers: React.Dispatch<React.SetStateAction<boolean>>;
  premiumOptions: Premium[];
  setPremiumOptions: React.Dispatch<React.SetStateAction<Premium[]>>;
  addedOneFamilyMember: boolean;
  setAddedOneFamilyMember: React.Dispatch<React.SetStateAction<boolean>>;
} = {
  formValid: false,
  setFormValid: () => {},
  formValues: {},
  setFormValues: () => {},
  familyFormValid: false,
  setFamilyFormValid: () => {},
  editDetails: false,
  setEditDetails: () => {},
  showQRModal: false,
  setShowQRModal: () => {},
  someFamilyMembers: false,
  setSomeFamilyMembers: () => {},
  noFamilyMembers: false,
  setNoFamilyMembers: () => {},
  premiumOptions: [],
  setPremiumOptions: () => {},
  setAddedOneFamilyMember: () => {},
  addedOneFamilyMember: false,
};

export const CoverContext = createContext(initialState);

interface Props {
  children: React.ReactNode;
}

export const CoverContextProvider = ({ children }: Props) => {
  const [formValid, setFormValid] = useState<boolean>(false);
  const [formValues, setFormValues] = useState<PersonalDetails>({});
  const [familyFormValid, setFamilyFormValid] = useState<boolean>(false);
  const [editDetails, setEditDetails] = useState<boolean>(false);
  const [showQRModal, setShowQRModal] = useState<boolean>(false);
  const [someFamilyMembers, setSomeFamilyMembers] = useState<boolean>(false);
  const [noFamilyMembers, setNoFamilyMembers] = useState<boolean>(false);
  const [premiumOptions, setPremiumOptions] = useState<Premium[]>([]);
  const [addedOneFamilyMember, setAddedOneFamilyMember] = useState(false);

  return (
    <CoverContext.Provider
      value={{
        formValid,
        setFormValid,
        formValues,
        setFormValues,
        familyFormValid,
        setFamilyFormValid,
        editDetails,
        setEditDetails,
        showQRModal,
        setShowQRModal,
        someFamilyMembers,
        setSomeFamilyMembers,
        noFamilyMembers,
        setNoFamilyMembers,
        premiumOptions,
        setPremiumOptions,
        addedOneFamilyMember,
        setAddedOneFamilyMember,
      }}
    >
      {children}
    </CoverContext.Provider>
  );
};

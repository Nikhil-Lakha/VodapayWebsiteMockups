import React from 'react';
import { Outlet, ScrollRestoration } from 'react-router-dom';

export const RootOutlet = () => (
  <>
    <Outlet />
    <ScrollRestoration />
  </>
);

import React from 'react';
import { Outlet } from 'react-router-dom';
import { CoverContextProvider } from '@/context';

export const CoverOutlet = () => (
  <CoverContextProvider>
    <Outlet />
  </CoverContextProvider>
);

import { useContext, useEffect, useMemo, useState } from 'react';
import { journeySteps, steps } from '@/utils';
import { AppContext } from '@/context';
import { useLocation } from 'react-router-dom';

export const useJourneyService = () => {
  const { isFamilyJourney } = useContext(AppContext);
  const [index, setIndex] = useState(0);
  const [finalSteps, setFinalSteps] = useState(
    journeySteps.filter(step => step.group !== steps.family_details)
  );
  const location = useLocation();

  const familyJourneySteps = journeySteps;
  const individualJourneySteps = useMemo(
    () => journeySteps.filter(step => step.group !== steps.family_details),
    []
  );

  useMemo(() => {
    if (isFamilyJourney) {
      setFinalSteps(familyJourneySteps);
    } else {
      setFinalSteps(individualJourneySteps);
    }
  }, [familyJourneySteps, individualJourneySteps, isFamilyJourney]);

  useEffect(() => {
    if (isFamilyJourney) {
      setIndex(
        familyJourneySteps.findIndex(step => step.route === location.pathname)
      );
    } else {
      setIndex(
        individualJourneySteps.findIndex(
          step => step.route === location.pathname
        )
      );
    }
  }, [
    familyJourneySteps,
    individualJourneySteps,
    isFamilyJourney,
    location.pathname,
  ]);

  return {
    currentStep: finalSteps[index] || finalSteps[0],
    journeySteps: finalSteps,
  };
};

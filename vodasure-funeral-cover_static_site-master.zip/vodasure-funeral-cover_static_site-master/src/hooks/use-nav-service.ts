import { useNavigate } from 'react-router-dom';

export const useNavService = () => {
  const navigation = useNavigate();

  const navigate = {
    to: (page: string) => {
      navigation(page);
    },
    back: (delta: number = 1) => {
      navigation(-delta);
    },
    replace: (page: string) => {
      navigation(page, { replace: true });
    },
    with: (page: string, state: {}) => {
      navigation(page, { state });
    },
  };

  return navigate;
};

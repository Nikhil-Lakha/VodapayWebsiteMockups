export * from './has-min-main-life-cover-amount/has-min-main-life-cover-amount';
export * from './is-vodacom-customer/is-vodacom-customer';

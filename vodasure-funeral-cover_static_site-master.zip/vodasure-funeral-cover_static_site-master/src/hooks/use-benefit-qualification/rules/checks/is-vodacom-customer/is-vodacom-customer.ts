import { IAppContext } from '@/types';

export const isVodacomCustomer = (app: IAppContext) => app.isVodacomCustomer;

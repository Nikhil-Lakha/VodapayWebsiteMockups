import { IAppContext } from '@/types';

export const hasMinMainLifeCoverAmount = (amount: number) => (app: IAppContext) =>
  (app.productDetails.coverAmount || 0) >= amount;

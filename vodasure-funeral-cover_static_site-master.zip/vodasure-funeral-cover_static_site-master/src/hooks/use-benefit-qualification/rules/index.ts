import { AddOns, IAppContext } from '@/types';
import { hasMinMainLifeCoverAmount, isVodacomCustomer } from './checks';
import { applicationDefaults } from '@/utils';

export const rules: {
  [benefit in keyof AddOns]?: ((app: IAppContext) => boolean)[];
} = {
  dataReward: [
    isVodacomCustomer,
    hasMinMainLifeCoverAmount(
      applicationDefaults.benefitRequirements.dataReward.minCoverAmount
    ),
  ],
};

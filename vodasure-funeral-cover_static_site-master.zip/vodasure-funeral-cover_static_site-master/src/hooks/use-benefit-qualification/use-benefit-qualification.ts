import { AppContext } from '@/context';
import { AddOns, IAppContext } from '@/types';
import { useContext, useEffect, useMemo, useState } from 'react';
import { rules } from './rules';

export const useBenefitQualification = (benefit: keyof AddOns) => {
  const app = useContext(AppContext);
  const [checks, setChecks] = useState<((context: IAppContext) => boolean)[]>(
    []
  );

  useEffect(() => {
    setChecks(rules[benefit] || []);
  }, [benefit]);

  const qualifies = useMemo(
    () => checks.map(check => check(app)).every(Boolean),
    [app, checks]
  );

  return { qualifies };
};

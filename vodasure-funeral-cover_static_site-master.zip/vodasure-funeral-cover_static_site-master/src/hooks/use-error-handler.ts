import { useState, useCallback } from 'react';

export const useErrorHandler = () => {
  const [_, setError] = useState({});

  return useCallback(
    (error: Error) => {
      setError(() => {
        throw error;
      });
    },
    [setError]
  );
};

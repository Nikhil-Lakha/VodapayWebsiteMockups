#!/usr/bin/env bash

yarn coverage:clean
yarn coverage:make
# yarn coverage:move
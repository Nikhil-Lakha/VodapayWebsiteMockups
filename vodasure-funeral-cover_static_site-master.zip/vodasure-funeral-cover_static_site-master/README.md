# VodaSure - Funeral Cover

## About the project

Confluence Documentation: [Online Fulfilment: Funeral Cover](https://vodacom.atlassian.net/wiki/spaces/VODA/pages/279446031/Online+Fulfilment+Funeral+Cover)

Figma: [Funeral Cover (Web app) figma](<https://www.figma.com/file/J8R1YQW0Cu6chdKLKKa8Ix/Funeral-Cover-(Web-app)?t=snjzh9lrPWgB2qOH-0>)

## Getting started

To get a local copy up and running follow these simple example steps:

### Prerequisites

- [Nodejs](https://nodejs.org/en/download/)
- [VSCode](https://code.visualstudio.com/Download) (Recommended) / IntelliJ
- Yarn:

  ```sh
      npm install --global yarn
  ```

### Code formatting

We use prettier and eslint to handle the formatting of the code. This helps prevent massive diffs in PR's.

- [Prettier vscode extension](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
- [ESLint vscode extension](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)

### Installation

1. Clone the repository
   ```sh
   git clone https://github.com/Vodasure/vodasure-funeral-cover_static_site.git
   ```
2. Install the required packages
   ```sh
   yarn
   ```

### How to Run The Project

Open the terminal again. Here you must type

```sh
   yarn dev
```

To run the project in with debug options run

```sh
   yarn debug
```

The project will run on port 3000 and you should see the following icon on the bottom right of the page.

![Alt text](relative%20/../readme-images/debug%20icon%20image.png 'debug icon image')

this will bring up the following popup

![Alt text](relative%20/../readme-images/debug%20options.png 'debug icon image')

- API host: Allows you to choose where the backend request is made to.

  - local: This option will allow requests to be sent to local running microservices, take a look at [How to Orchestrate The Microservices Locally (without Kubernetes)] section.

  - dev: This option will send requests to the dev backend.

  - qa: This option will send request to qa backend.

  - prod: This option will send request to prod backend.

- Make API request: When false all api request will be mocked:

- Disable analytics: When true analytics will be disabled.

- Debug analytics: When true debug analytics will be enabled.

Once your choices have been made the update button will set your options without the need to restart the app.

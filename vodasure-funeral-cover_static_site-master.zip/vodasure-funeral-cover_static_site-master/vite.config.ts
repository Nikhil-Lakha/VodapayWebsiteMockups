/// <reference types="vitest" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  base: '/funeral-cover/',
  resolve: { alias: [{ find: '@', replacement: resolve(__dirname, 'src') }] },
  plugins: [react()],
  test: {
    setupFiles: ['./vitest.setup.ts'],
    globals: true,
    environment: 'jsdom',
    deps: {
      inline: ['vitest-canvas-mock'],
    },
    coverage: {
      reporter: ['text', 'json', 'html'],
    },

    reporters: ['default', ['junit', {
      suiteName: 'Vitest Unit Tests',
      outputFile: './junit-report/vitest-junit.xml',
    }]],
  },
});
